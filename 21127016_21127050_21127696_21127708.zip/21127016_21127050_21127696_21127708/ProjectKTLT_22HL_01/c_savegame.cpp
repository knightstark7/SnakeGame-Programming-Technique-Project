#include "c_savegame.h"
#include "c_mylib.h"
#include "c_Map2Mode2.h"
#include "c_Map3Mode2.h"
#include "c_menu.h"
#include <iostream>
#include <Windows.h>
#include <malloc.h>
#include <string>
#include <fstream>
using namespace std;

int select_tmp = 0;
bool getChange = false;

char* ChuyenSoThanhChu(int a)
{
	char* str = new char[10];
	int i = 0;
	while (a > 0)
	{
		int dvi = a % 10;
		str[i] = char(dvi) + 48;
		a /= 10;
		i++;
	}
	str[i] = '\0';
	return str;
}

bool KiemTraTenFileHopLe(string* data, int nData, string str)
{
	for (int i = 0; i < nData; i++)
	{
		if (str.compare(data[i]) == 0)
		{
			return false;
		}
	}
	return true;
}

void LuuManChoi(string* data, int& nData, NguoiChoi nguoiChoi, int TrangThai)
{
	if (TrangThai == -1)
	{
		TrangThai = nData;
		string str;
		nData++;
		do
		{
			int temp = 0 + rand() % (200 + 1 - 0);
			str = "LoadGame_";
			str += string(ChuyenSoThanhChu(temp));
			str += ".txt";
		} while (!KiemTraTenFileHopLe(data, nData, str));
		data[TrangThai] = str;
	}

	int BodyRan = nguoiChoi.BodyRan;
	if (BodyRan == 0)
	{
		delete (data + TrangThai - 1);
		return;
	}

	ofstream fileOut;
	fileOut.open(data[TrangThai], ios::out);
	fileOut << nguoiChoi.TenNguoiChoi << "\n";
	fileOut << nguoiChoi.diem << "\n";
	fileOut << nguoiChoi.BodyRan << " ";
	int dot = nguoiChoi.BodyRan;
	for (int j = 0; j < dot; j++)
	{
		fileOut << nguoiChoi.Ran[j].x << " ";
		fileOut << nguoiChoi.Ran[j].y << " ";
	}
	fileOut << "\n";
	fileOut << nguoiChoi.SPEED << "\n";
	fileOut << nguoiChoi.huong << "\n";
	fileOut << nguoiChoi.man;
	if (nguoiChoi.man >= 3)
	{
		fileOut << "\n" << nguoiChoi.VatCanSoO << " ";
		int SizeVatCanDiChuyen = nguoiChoi.VatCanSoO;
		for (int j = 0; j < SizeVatCanDiChuyen; j++)
		{
			fileOut << nguoiChoi.VatCanDong[j].x << " ";
			fileOut << nguoiChoi.VatCanDong[j].y << " ";
		}
		fileOut << endl;
	}
	else
	{
		fileOut << "\n" << 0;
	}
	fileOut.close();
	fileOut.open("data.txt", ios::out);
	fileOut << nData;
	for (int i = 0; i < nData; i++)
	{
		fileOut << "\n" << data[i];
	}
	fileOut.close();
}

void LuuManChoi2(string* data, int& nData, NguoiChoi nguoiChoi1, NguoiChoi nguoiChoi2, int TrangThai, int mode)
{
	if (TrangThai == -1)
	{
		TrangThai = nData;
		string str;
		nData++;
		do
		{
			int temp = 0 + rand() % (200 + 1 - 0);
			str = "LoadGame_";
			str += string(ChuyenSoThanhChu(temp));
			str += ".txt";
		} while (!KiemTraTenFileHopLe(data, nData, str));
		data[TrangThai] = str;
	}

	int BodyRan1 = nguoiChoi1.BodyRan;
	int BodyRan2 = nguoiChoi2.BodyRan;

	if (BodyRan1 == 0 && BodyRan2 == 0)
	{
		delete (data + TrangThai - 1);
		return;
	}


	ofstream fileOut;
	fileOut.open(data[TrangThai], ios::out);

	fileOut << nguoiChoi1.TenNguoiChoi << "\n";
	fileOut << nguoiChoi1.diem << "\n";
	fileOut << nguoiChoi1.BodyRan << " ";
	int dot1 = nguoiChoi1.BodyRan;

	for (int j = 0; j < dot1; j++)
	{
		fileOut << nguoiChoi1.Ran[j].x << " ";
		fileOut << nguoiChoi1.Ran[j].y << " ";
	}

	fileOut << "\n";
	fileOut << nguoiChoi1.SPEED << "\n";
	fileOut << nguoiChoi1.huong << "\n";
	fileOut << nguoiChoi1.man;

	if (nguoiChoi1.man >= 3)
	{
		fileOut << "\n" << nguoiChoi1.VatCanSoO << " ";
		int SizeVatCanDiChuyen = nguoiChoi1.VatCanSoO;
		for (int j = 0; j < SizeVatCanDiChuyen; j++)
		{
			fileOut << nguoiChoi1.VatCanDong[j].x << " ";
			fileOut << nguoiChoi1.VatCanDong[j].y << " ";
		}
		fileOut << endl;
	}

	else
	{
		fileOut << "\n" << 0 << "\n";
	}

	fileOut << nguoiChoi2.TenNguoiChoi << "\n";
	fileOut << nguoiChoi2.diem << "\n";
	fileOut << nguoiChoi2.BodyRan << " ";
	int dot2 = nguoiChoi2.BodyRan;


	for (int j = 0; j < dot2; j++)
	{
		fileOut << nguoiChoi2.Ran[j].x << " ";
		fileOut << nguoiChoi2.Ran[j].y << " ";
	}
	fileOut << "\n";
	fileOut << nguoiChoi2.SPEED << "\n";
	fileOut << nguoiChoi2.huong << "\n";
	fileOut << nguoiChoi2.man;


	if (nguoiChoi2.man >= 3)
	{
		fileOut << "\n" << nguoiChoi2.VatCanSoO << " ";
		int SizeVatCanDiChuyen = nguoiChoi2.VatCanSoO;
		for (int j = 0; j < SizeVatCanDiChuyen; j++)
		{
			fileOut << nguoiChoi2.VatCanDong[j].x << " ";
			fileOut << nguoiChoi2.VatCanDong[j].y << " ";
		}
		fileOut << endl;
	}

	else
	{
		fileOut << "\n" << 0;
	}

	fileOut.close();
	if (mode == 1) {
		//
		fileOut.open("data.txt", ios::out);
		fileOut << nData;
		for (int i = 0; i < nData; i++)
		{
			fileOut << "\n" << data[i];
		}
		fileOut.close();
	}
	if (mode == 2) {
		//
		fileOut.open("data2.txt", ios::out);
		fileOut << nData;
		for (int i = 0; i < nData; i++)
		{
			fileOut << "\n" << data[i];
		}
		fileOut.close();
	}
	if (mode == 3) {
		//
		fileOut.open("data3.txt", ios::out);
		fileOut << nData;
		for (int i = 0; i < nData; i++)
		{
			fileOut << "\n" << data[i];
		}
		fileOut.close();
	}
	if (mode == 4) {
		//
		fileOut.open("data4.txt", ios::out);
		fileOut << nData;
		for (int i = 0; i < nData; i++)
		{
			fileOut << "\n" << data[i];
		}
		fileOut.close();
	}
}

NguoiChoi* XuatDanhSachNguoiChoi(ifstream& fileIn, string* data, int nData, int& nNguoiChoi)
{
	if (nData < 1)
	{
		nNguoiChoi = 0;
		return NULL;
	}
	nNguoiChoi = nData;
	NguoiChoi* danhSachNguoiChoi = new NguoiChoi[nNguoiChoi];

	for (int i = 0; i < nNguoiChoi; i++)
	{
		fileIn.open(data[i], ios::in);
		danhSachNguoiChoi[i].TenNguoiChoi = new char[50];
		fileIn.getline(danhSachNguoiChoi[i].TenNguoiChoi, 50, '\n');
		fileIn >> danhSachNguoiChoi[i].diem;
		fileIn >> danhSachNguoiChoi[i].BodyRan;
		int dot = danhSachNguoiChoi[i].BodyRan;
		for (int j = 0; j < dot; j++)
		{
			fileIn >> danhSachNguoiChoi[i].Ran[j].x;
			fileIn >> danhSachNguoiChoi[i].Ran[j].y;
		}
		fileIn >> danhSachNguoiChoi[i].SPEED;
		fileIn >> danhSachNguoiChoi[i].huong;
		fileIn >> danhSachNguoiChoi[i].man;
		fileIn >> danhSachNguoiChoi[i].VatCanSoO;
		int SizeVatCanDiChuyen = danhSachNguoiChoi[i].VatCanSoO;
		for (int j = 0; j < SizeVatCanDiChuyen; j++)
		{
			fileIn >> danhSachNguoiChoi[i].VatCanDong[j].x;
			fileIn >> danhSachNguoiChoi[i].VatCanDong[j].y;
		}
		fileIn.close();
	}
	return danhSachNguoiChoi;
}

NguoiChoi** XuatDanhSachNguoiChoi2(ifstream& fileIn, string* data, int nData, int& nNguoiChoi)
{
	char* temp = new char[50];
	if (nData < 1)
	{
		nNguoiChoi = 0;
		return NULL;
	}
	nNguoiChoi = nData;
	NguoiChoi** danhSachNguoiChoi = new NguoiChoi * [nNguoiChoi];
	for (int i = 0; i < nNguoiChoi; i++) {
		danhSachNguoiChoi[i] = new NguoiChoi[2];
	}
	for (int i = 0; i < nNguoiChoi; i++)
	{
		fileIn.open(data[i], ios::in);
		for (int k = 0; k < 2; k++)
		{
			danhSachNguoiChoi[i][k].TenNguoiChoi = new char[50];
			fileIn.getline(danhSachNguoiChoi[i][k].TenNguoiChoi, 50, '\n');
			fileIn >> danhSachNguoiChoi[i][k].diem;
			fileIn >> danhSachNguoiChoi[i][k].BodyRan;
			int dot = danhSachNguoiChoi[i][k].BodyRan;
			for (int j = 0; j < dot; j++)
			{
				fileIn >> danhSachNguoiChoi[i][k].Ran[j].x;
				fileIn >> danhSachNguoiChoi[i][k].Ran[j].y;
			}
			fileIn >> danhSachNguoiChoi[i][k].SPEED;
			fileIn >> danhSachNguoiChoi[i][k].huong;
			fileIn >> danhSachNguoiChoi[i][k].man;
			fileIn >> danhSachNguoiChoi[i][k].VatCanSoO;
			int SizeVatCanDiChuyen = danhSachNguoiChoi[i][k].VatCanSoO;
			for (int j = 0; j < SizeVatCanDiChuyen; j++)
			{
				fileIn >> danhSachNguoiChoi[i][k].VatCanDong[j].x;
				fileIn >> danhSachNguoiChoi[i][k].VatCanDong[j].y;
			}
			fileIn.getline(temp, 50, '\n');
		}
		fileIn.close();
	}
	return danhSachNguoiChoi;
}

void HienThiChonLoadGame(int x, int y, NguoiChoi danhSachNguoiChoi[], int nNguoiChoi, int select)
{
	int khoang_cach = 19;

	TextColor(15);
	gotoXY(x + 16, y + khoang_cach + select * 2); cout << "                                                                   ";
	gotoXY(x + 19, y + khoang_cach + select * 2); cout << select + 1;
	gotoXY(x + 30, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select].TenNguoiChoi;
	gotoXY(x + 61, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select].man;
	gotoXY(x + 74, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select].diem;

	if (select > select_tmp)
	{
		getChange = true;
	}
	if (getChange == true)
	{
		TextColor(240);
		gotoXY(x + 16, y + khoang_cach + select_tmp * 2); cout << "                                                                   ";
		gotoXY(x + 19, y + khoang_cach + select_tmp * 2); cout << select_tmp + 1;
		gotoXY(x + 30, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp].TenNguoiChoi;
		gotoXY(x + 61, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp].man;
		gotoXY(x + 74, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp].diem;
	}
	select_tmp = select;
}

void HienThiChonLoadGame2(int x, int y, NguoiChoi** danhSachNguoiChoi, int nNguoiChoi, int select)
{
	int khoang_cach = 19;
	for (int i = 0; i < 2; i++) {
		TextColor(15);
		gotoXY(x + 16, y + khoang_cach + select * 2); cout << "                                                                   ";
		gotoXY(x + 19, y + khoang_cach + select * 2); cout << select + 1;
		gotoXY(x + 30, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select][i].TenNguoiChoi;
		gotoXY(x + 61, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select][i].man;
		gotoXY(x + 74, y + khoang_cach + select * 2); cout << danhSachNguoiChoi[select][i].diem;
	}


	if (select > select_tmp)
	{
		getChange = true;
	}
	if (getChange == true)
	{
		for (int i = 0; i < 2; i++) {
			TextColor(240);
			gotoXY(x + 16, y + khoang_cach + select_tmp * 2); cout << "                                                                   ";
			gotoXY(x + 19, y + khoang_cach + select_tmp * 2); cout << select_tmp + 1;
			gotoXY(x + 30, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp][i].TenNguoiChoi;
			gotoXY(x + 61, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp][i].man;
			gotoXY(x + 74, y + khoang_cach + select_tmp * 2); cout << danhSachNguoiChoi[select_tmp][i].diem;
		}

	}
	select_tmp = select;
}

void ThongTinLoadGame(int x, int y, NguoiChoi danhSachNguoiChoi[], int nNguoiChoi)
{
	int khoang_cach = 19;
	for (int i = 0; i < nNguoiChoi; i++)
	{
		gotoXY(x + 19, y + khoang_cach + i * 2); cout << i + 1;
		gotoXY(x + 30, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i].TenNguoiChoi;
		gotoXY(x + 61, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i].man;
		gotoXY(x + 74, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i].diem;
	}
}

void ThongTinLoadGame2(int x, int y, NguoiChoi** danhSachNguoiChoi, int nNguoiChoi)
{
	int khoang_cach = 19;
	for (int i = 0; i < nNguoiChoi; i++)
	{
		for (int j = 0; j < 2; j++) {
			gotoXY(x + 19, y + khoang_cach + i * 2); cout << i + 1;
			gotoXY(x + 30, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i][j].TenNguoiChoi;
			gotoXY(x + 61, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i][j].man;
			gotoXY(x + 74, y + khoang_cach + i * 2); cout << danhSachNguoiChoi[i][j].diem;
		}
	}
}


int logic_load_game(int x, int y, NguoiChoi* danhSachNguoiChoi, int nNguoiChoi, MoveKeyBoard keyboardP1, int soundEF)
{
	int select = 0;
	int res = MAXINT;
	bool inputChoice = false;
	ThongTinLoadGame(x, y, danhSachNguoiChoi, nNguoiChoi);
	HienThiChonLoadGame(x, y, danhSachNguoiChoi, nNguoiChoi, select);
	if (danhSachNguoiChoi == NULL)
	{
		return -1;
	}
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == keyboardP1.MoveDown)
			{
				select += 1;
			}
			if (phim == keyboardP1.MoveUp)
			{
				select -= 1;
			}
			if (int(phim) == 13)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = select;
				inputChoice = true;
			}
			if (select > nNguoiChoi - 1)
			{
				select = 0;
			}
			if (select < 0)
			{
				select = nNguoiChoi - 1;
			}
			HienThiChonLoadGame(x, y, danhSachNguoiChoi, nNguoiChoi, select);
		}
	}
	return res;
}

int logic_load_game2(int x, int y, NguoiChoi** danhSachNguoiChoi, int nNguoiChoi, MoveKeyBoard keyboardP1, int soundEF)
{
	int select = 0;
	int res = MAXINT;
	bool inputChoice = false;
	ThongTinLoadGame2(x, y, danhSachNguoiChoi, nNguoiChoi);
	HienThiChonLoadGame2(x, y, danhSachNguoiChoi, nNguoiChoi, select);
	if (danhSachNguoiChoi == NULL)
	{
		return -1;
	}
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == keyboardP1.MoveDown)
			{
				select += 1;
			}
			if (phim == keyboardP1.MoveUp)
			{
				select -= 1;
			}
			if (int(phim) == 13)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = select;
				inputChoice = true;
			}
			if (select > nNguoiChoi - 1)
			{
				select = 0;
			}
			if (select < 0)
			{
				select = nNguoiChoi - 1;
			}
			HienThiChonLoadGame2(x, y, danhSachNguoiChoi, nNguoiChoi, select);
		}
	}
	return res;
}

void LoadLaiGame(char*& TenNguoiChoi, int& diem, int& BodyRan, ToaDo ran[], int& SPEED, int& huong, int& man, int& KichThuocVatCan, ToaDo ChuongNgaiVat[], NguoiChoi* danhSachNguoiChoi, int nguoiChoiThuI)
{
	TenNguoiChoi = new char[50];
	strcpy_s(TenNguoiChoi, 50, danhSachNguoiChoi[nguoiChoiThuI].TenNguoiChoi);
	diem = danhSachNguoiChoi[nguoiChoiThuI].diem;
	BodyRan = danhSachNguoiChoi[nguoiChoiThuI].BodyRan;
	for (int i = 0; i < BodyRan; i++)
	{
		ran[i] = danhSachNguoiChoi[nguoiChoiThuI].Ran[i];
	}
	SPEED = danhSachNguoiChoi[nguoiChoiThuI].SPEED;
	huong = danhSachNguoiChoi[nguoiChoiThuI].huong;
	man = danhSachNguoiChoi[nguoiChoiThuI].man;
	KichThuocVatCan = danhSachNguoiChoi[nguoiChoiThuI].VatCanSoO;
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		ChuongNgaiVat[i] = danhSachNguoiChoi[nguoiChoiThuI].VatCanDong[i];
	}
}

void LoadLaiGame2(char*& TenNguoiChoi1, char*& TenNguoiChoi2, int& diem, int& diem2, int& BodyRan1, int& BodyRan2, ToaDo ran1[], ToaDo ran2[], int& SPEED, int& huong1, int& huong2, int& man, int& KichThuocVatCan, ToaDo ChuongNgaiVat[], NguoiChoi** danhSachNguoiChoi, int nguoiChoiThuI)
{
	TenNguoiChoi1 = new char[50];
	TenNguoiChoi2 = new char[50];

	strcpy_s(TenNguoiChoi1, 50, danhSachNguoiChoi[nguoiChoiThuI][0].TenNguoiChoi);
	strcpy_s(TenNguoiChoi2, 50, danhSachNguoiChoi[nguoiChoiThuI][1].TenNguoiChoi);

	diem = danhSachNguoiChoi[nguoiChoiThuI][0].diem;
	diem2 = danhSachNguoiChoi[nguoiChoiThuI][1].diem;

	BodyRan1 = danhSachNguoiChoi[nguoiChoiThuI][0].BodyRan;
	BodyRan2 = danhSachNguoiChoi[nguoiChoiThuI][1].BodyRan;
	for (int i = 0; i < BodyRan1; i++)
	{
		ran1[i] = danhSachNguoiChoi[nguoiChoiThuI][0].Ran[i];
	}
	for (int i = 0; i < BodyRan2; i++)
	{
		ran2[i] = danhSachNguoiChoi[nguoiChoiThuI][1].Ran[i];
	}
	SPEED = danhSachNguoiChoi[nguoiChoiThuI][0].SPEED;
	huong1 = danhSachNguoiChoi[nguoiChoiThuI][0].huong;
	huong2 = danhSachNguoiChoi[nguoiChoiThuI][1].huong;
	man = danhSachNguoiChoi[nguoiChoiThuI][0].man;
	KichThuocVatCan = danhSachNguoiChoi[nguoiChoiThuI][0].VatCanSoO;
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		ChuongNgaiVat[i] = danhSachNguoiChoi[nguoiChoiThuI][0].VatCanDong[i];
	}
}

void LuuGame(char* TenNguoiChoi, int diem, int BodyRan, ToaDo* ran, int SPEED, int huong, int man,
	int SizeVatCanDiChuyen, ToaDo* VatCanDiChuyen, string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int mode)
{
	if (TrangThai < 0 || TrangThai >= nData)
	{
		if (TrangThai == -1)
		{

			TextColor(244);
			gotoXY(34, 18); cout << (char)4;
			TextColor(241);
			gotoXY(36, 18); cout << "INPUT THE FILE'S NAME: ";
			TenNguoiChoi = new char[50];
			cin.getline(TenNguoiChoi, 50);
		}
	}
	nguoiChoi.TenNguoiChoi = TenNguoiChoi;
	nguoiChoi.diem = diem;
	nguoiChoi.BodyRan = BodyRan;

	for (int i = 0; i < BodyRan; i++)
	{
		nguoiChoi.Ran[i] = ran[i];
	}
	nguoiChoi.SPEED = SPEED;
	nguoiChoi.huong = huong;
	nguoiChoi.man = man;
	nguoiChoi.VatCanSoO = SizeVatCanDiChuyen;
	for (int j = 0; j < SizeVatCanDiChuyen; j++)
	{
		nguoiChoi.VatCanDong[j] = VatCanDiChuyen[j];
	}
	LuuManChoi(data, nData, nguoiChoi, TrangThai);
}

void LuuGame2(char* TenNguoiChoi1, char* TenNguoiChoi2, int diem1, int diem2, int BodyRan1, ToaDo* ran1, int BodyRan2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man,
	int SizeVatCanDiChuyen, ToaDo* VatCanDiChuyen, string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int mode)
{
	if (TrangThai < 0 || TrangThai >= nData)
	{
		if (TrangThai == -1)
		{

			TextColor(244);
			gotoXY(34, 18); cout << (char)4;
			TextColor(241);
			gotoXY(36, 18); cout << "INPUT THE FILE'S NAME: ";
			TenNguoiChoi1 = new char[50];
			cin.getline(TenNguoiChoi1, 50);
		}
	}
	nguoiChoi1.TenNguoiChoi = TenNguoiChoi1;
	nguoiChoi1.diem = diem1;
	nguoiChoi1.BodyRan = BodyRan1;

	nguoiChoi2.TenNguoiChoi = TenNguoiChoi1;
	nguoiChoi2.diem = diem2;
	nguoiChoi2.BodyRan = BodyRan2;
	for (int i = 0; i < BodyRan1; i++)
	{
		nguoiChoi1.Ran[i] = ran1[i];
	}
	for (int i = 0; i < BodyRan2; i++)
	{
		nguoiChoi2.Ran[i] = ran2[i];
	}
	nguoiChoi1.SPEED = SPEED;
	nguoiChoi1.huong = huong1;
	nguoiChoi1.man = man;
	nguoiChoi1.VatCanSoO = SizeVatCanDiChuyen;

	nguoiChoi2.SPEED = SPEED;
	nguoiChoi2.huong = huong2;
	nguoiChoi2.man = man;
	nguoiChoi2.VatCanSoO = SizeVatCanDiChuyen;
	for (int j = 0; j < SizeVatCanDiChuyen; j++)
	{
		nguoiChoi1.VatCanDong[j] = VatCanDiChuyen[j];
	}
	for (int j = 0; j < SizeVatCanDiChuyen; j++)
	{
		nguoiChoi2.VatCanDong[j] = VatCanDiChuyen[j];
	}
	LuuManChoi2(data, nData, nguoiChoi1, nguoiChoi2, TrangThai, mode);
}


void XoaFileText(string* data, int& nData, int TrangThai)
{
	if (TrangThai < 0)
	{
		return;
	}
	ofstream fileOut;
	fileOut.open(data[TrangThai], ios::out);
	fileOut << " ";
	fileOut.close();

	for (int i = TrangThai; i < nData - 1; i++)
	{
		data[i] = data[i + 1];
	}
	nData--;

	fileOut.open("data.txt", ios::out);
	fileOut << nData;
	for (int i = 0; i < nData; i++)
	{
		fileOut << "\n" << data[i];
	}
	fileOut.close();
}