#pragma once
#pragma comment(lib, "winmm.lib")
#include "c_savegame.h"
#include "c_Map2Mode2.h"

void TaoChuongNgaiVatMan4(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo vat_can[], int& vat_can_so_o);

bool KiemTraThuaVatCan4(ToaDo ran[], ToaDo vat_can[], int so_o_vat_can);

bool KiemTraThuaMan4(ToaDo ran[], int ran_dot, ToaDo vat_can[], int so_o_vat_can);

void Man4Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo vat_can[], int vat_can_so_o,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode);