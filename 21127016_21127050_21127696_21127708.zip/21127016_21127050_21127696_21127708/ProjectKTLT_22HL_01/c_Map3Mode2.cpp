﻿#include "c_Map3Mode2.h"
#include "c_mylib.h"
#include "c_savegame.h"
#include "c_scoreboard.h"
#include <iostream>
#include "c_menu.h"
#include "c_snake.h"
#include "c_music.h"
#include <Windows.h>

using namespace std;

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110

void TaoChuongNgaiVatMan3(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo vat_can_dong[], int& vat_can_dong_so_o)
{
	int chieu_dai_thanh_vat_can = 10;
	for (int i = 18; i <= 40; i++) // T?o 1 thanh v?t c?n d?c phía bên trái (4 ô)
	{
		vat_can_dong[vat_can_dong_so_o].y = 19;
		vat_can_dong[vat_can_dong_so_o].x = i;
		vat_can_dong_so_o++;
	}

	for (int i = 71; i <= 93; i++) // T?o 1 thanh v?t c?n d?c phía bên ph?i (4 ô)
	{
		vat_can_dong[vat_can_dong_so_o].y = 24;
		vat_can_dong[vat_can_dong_so_o].x = i;
		vat_can_dong_so_o++;
	}
}

void DiChuyenChuongNgaiVatMan3(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo vat_can_dong[], int vat_can_dong_so_o, bool& up)
{
	if (up)
	{
		//V?t c?n bên trái
		gotoXY(vat_can_dong[vat_can_dong_so_o / 2 - 1].x, vat_can_dong[vat_can_dong_so_o / 2 - 1].y);
		cout << " ";
		for (int i = 0; i < vat_can_dong_so_o / 2; i++)
		{
			vat_can_dong[i].x--;
		}
		gotoXY(vat_can_dong[0].x, vat_can_dong[0].y);
		cout << char(219);

		//V?t c?n bên ph?i
		gotoXY(vat_can_dong[vat_can_dong_so_o / 2].x, vat_can_dong[vat_can_dong_so_o / 2].y);
		cout << " ";
		for (int i = vat_can_dong_so_o / 2; i < vat_can_dong_so_o; i++)
		{
			vat_can_dong[i].x++;
		}
		gotoXY(vat_can_dong[vat_can_dong_so_o - 1].x, vat_can_dong[vat_can_dong_so_o - 1].y);
		cout << char(219);

		if (vat_can_dong[0].x == x + 6)
		{
			up = false;
		}
	}
	else
	{
		//V?t c?n bên trái
		gotoXY(vat_can_dong[0].x, vat_can_dong[0].y);
		cout << " ";

		for (int i = 0; i < vat_can_dong_so_o / 2; i++)
		{
			vat_can_dong[i].x++;
		}

		gotoXY(vat_can_dong[vat_can_dong_so_o / 2 - 1].x, vat_can_dong[vat_can_dong_so_o / 2 - 1].y);
		cout << char(219);

		//V?t c?n bên ph?i
		gotoXY(vat_can_dong[vat_can_dong_so_o - 1].x, vat_can_dong[vat_can_dong_so_o - 1].y);
		cout << " ";
		for (int i = vat_can_dong_so_o / 2; i < vat_can_dong_so_o; i++)
		{
			vat_can_dong[i].x--;
		}

		gotoXY(vat_can_dong[vat_can_dong_so_o / 2].x, vat_can_dong[vat_can_dong_so_o / 2].y);
		cout << char(219);


		if (vat_can_dong[vat_can_dong_so_o / 2 - 1].x == x + VungDiChuyen - 1)
		{
			up = true;
		}
	}
}

//Ki?m tra thua do ??ng v?t c?n màn 1
bool KiemTraThuaVatCan3(ToaDo ran[], ToaDo VatCan[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (ran[0].x == VatCan[i].x && ran[0].y == VatCan[i].y)
		{
			return true;
		}
	}
	return false;
}

//Ki?m tra thua màn 2
bool KiemTraThuaMan3(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan)
{
	if (RanChamThan(ran, ran_dot))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	if (KiemTraThuaVatCan3(ran, VatCan, KichThuocVatCan))
	{
		return true;
	}
	return false;
}

void Man3Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode)
{
	int temp = SPEED;
	TaoChuongNgaiVatMan3(x, y, VungDiChuyen, ChieuRong, VatCan, KichThuocVatCan);
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm v? màn 1
	SPEED = temp;

	QUA food;
	QUA A;
	food.count = 0;//Số lượng quả
	A.checkqua = false;

	bool up = false;

	bool checkPause = false;
	int ran_dot_Tam = ran_dot;
	int diemTam = diem;
	ToaDo ranTam[100];
	for (int i = 0; i < 100; i++)  ranTam[i] = ran[i];
	int huongTemp = huong;
	bool isLose = false;

	VeRan(ran, ran_dot);
	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	ToaDo CongWin[7];
	int cong_win_so_o = 0; //s? ô t?o thành 1 c?ng win

	FoodRound2(food, VatCan, KichThuocVatCan, ran, ran_dot, CongWin, cong_win_so_o);
	bool win = KiemTraDieuKienThang(diem, 1500);
	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	int option;
	while (1)
	{
		int huongTam = huong;
		noCursorType();//Xóa con tr?(d?u nháy)
		BatSuKienMode2(huong, checkPause, keyboard);//Nh?n phím
		DiChuyenChuongNgaiVatMan3(x, y, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, up);
		ToaDo dot_cuoi_cu = DiChuyen(ran, huong, ran_dot);//Di chuy?n r?n d?a trên nút ???c nh?n trên bàn phím
		HienThiRan(ran, dot_cuoi_cu, ran_dot);//Hi?n th? thân r?n m?i sau khi di chuy?n

		if (huong == -1)
		{
			int temp_1 = TrangThai;
			huong = huongTam;
			LuuGame(ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, KichThuocVatCan, VatCan, data, nData, nguoiChoi, TrangThai, mode);
			system("cls");
			man = 0;
			break;
		}

		Sleep(SPEED);//T?c ?? r?n=100
		if (!win)
			AnQua2(ran, food, A, ran_dot, SPEED, diem, x, y, ChieuRong, VatCan, KichThuocVatCan, CongWin, cong_win_so_o, soundEF, checkPause, isLose, elapsedTime, startTime);//Ki?m tra ?n qu?
		if (KiemTraThuaMan3(ran, ran_dot, VatCan, KichThuocVatCan) || (win && RanChamCongWin(ran, CongWin, cong_win_so_o)))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			XoaFileText(data, nData, TrangThai);
			int choice = MenuGameOver(soundIG, soundEF, keyboard, keyboardP2, diem, ten_nguoi_choi, data, nData, nguoiChoi, TrangThai, 2);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				SPEED = temp;
				diem = 0;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				food.count = 0;
				ran_dot = ran_dot_Tam;
				for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
				huong = huongTemp;
				TaoQuaThuong(food);
				VeQuaThuong(food);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			if (pause == 2)
			{
				option = MenuOption(x, y, VungDiChuyen, ChieuRong, checkPause, keyboard, keyboardP2, soundIG, soundEF, ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, 0, VatCan,
					data, nData, nguoiChoi, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food.count < 6)
					{
						VeQuaThuong(food);
					}
					else
					{
						gotoXY(food.SpecialFood.x, food.SpecialFood.y);
						TextColor(241);
						cout << char(5);
					}
				}
				if (option == 2)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					diem = diemTam;
					SPEED = temp;
					food.count = 0;
					ran_dot = ran_dot_Tam;
					for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
					huong = huongTemp;
					TaoQuaThuong(food);//T?o qu? ??u tiên
					VeQuaThuong(food);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			checkPause = false;
		}
		win = KiemTraDieuKienThang(diem, 1500); //?n qu? xong thì ki?m tra l?i xem ?i?m ?ã ?? ?? qua màn
		if (win)
		{
			XoaQua(food);
			food.count = 10;
			char huong_vao_cong[10] = "len";
			TaoCongWin(94, 6, CongWin, cong_win_so_o, huong_vao_cong);
			VeCongWin(CongWin, cong_win_so_o);
			if (RanQuaMan(ran, CongWin))
			{
				if (soundEF == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				man++;
				break;
			}
		}
		playMusicGame(soundIG, isLose);
	}
}