#pragma once

#ifndef text_display_h
#define text_display_h

#include <iostream>
#include "c_mylib.h"
#include <string>
using namespace std;

void PrintSymbolSnakeIdle(int row, int col);
void DeleteSymbolSnakeChoosing(int row, int col);
void PrintSymbolSnakeChoosing(int row, int col);

void print_Text(char x, int col, int row);
void print_Text_Intro(char x, int col, int row);
void print_Number(int x, int col, int row);
void print_Symbol(char x, int row, int col);
void print_Text_Menu(char x, int col, int row);

#endif // !