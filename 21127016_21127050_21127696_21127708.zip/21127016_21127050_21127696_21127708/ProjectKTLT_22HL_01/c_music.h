#pragma once
#ifndef c_music_h
#include <Windows.h>
#pragma comment(lib, "winmm.lib")

void playMusicMainMenu(int& soundBG);
void playLoseSound(int& soundIG, bool isLose);
void playMusicGame(int& soundIG, bool isLose);
void playWinMusicGame(int& soundIG, bool isStop);
#endif // !c_music_h