#include"c_text.h"

void PrintSymbolSnakeIdle(int row, int col)
{
	TextColor(240);
	string text_key[5][20] = { " " };
	text_key[0][0] = text_key[0][1] = text_key[0][2] = char(223); text_key[0][3] = char(219); text_key[1][3] = char(223);
	text_key[4][0] = text_key[4][1] = text_key[4][2] = char(220); text_key[4][3] = char(219); text_key[3][3] = char(220);
	text_key[1][4] = text_key[1][5] = char(223); text_key[1][6] = char(219); text_key[1][1] = char(220);
	text_key[3][4] = text_key[3][5] = char(220); text_key[3][6] = char(219); text_key[3][1] = char(223);
	text_key[2][6] = char(219);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(col + j, row + i);
			cout << text_key[i][j];
		}
	}
}

void DeleteSymbolSnakeChoosing(int row, int col)
{
	TextColor(15);
	string text_key[5][20] = { " " };
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			text_key[i][j] = char(219);
		}
	}
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(col + j, row + i);
			cout << text_key[i][j];
		}
	}
}

void PrintSymbolSnakeChoosing(int row, int col)
{
	TextColor(240);
	string text_key[5][20] = { " " };
	text_key[0][7] = text_key[0][8] = text_key[0][9] = char(223); text_key[0][10] = char(219); text_key[1][10] = char(223);
	text_key[4][7] = text_key[4][8] = text_key[4][9] = char(220); text_key[4][10] = char(219); text_key[3][10] = char(220);
	text_key[1][11] = text_key[1][12] = char(223); text_key[1][13] = char(219); text_key[1][8] = char(220);
	text_key[3][11] = text_key[3][12] = char(220); text_key[3][13] = char(219); text_key[3][8] = char(223);
	text_key[2][13] = text_key[2][14] = text_key[2][15] = text_key[2][16] = char(219);

	text_key[0][6] = text_key[4][6] = char(219);
	text_key[1][5] = char(219);
	text_key[3][5] = char(219);
	text_key[1][0] = text_key[1][1] = text_key[1][2] = text_key[1][3] = text_key[1][4] = char(220);
	text_key[3][0] = text_key[3][1] = text_key[3][2] = text_key[3][3] = text_key[3][4] = char(223);


	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(col + j, row + i);
			cout << text_key[i][j];
		}
	}
}

void print_Text(char x, int row, int col)
{
	string text_y[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_y[i][j] = " ";
		}
	}
	text_y[0][0] = text_y[0][2] = text_y[1][1] = text_y[2][1] = (char)219;
	text_y[1][0] = text_y[1][2] = (char)223;

	string text_o[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_o[i][j] = " ";
		}
	}
	text_o[0][0] = text_o[1][0] = text_o[2][0] = text_o[2][2] = text_o[1][2] = text_o[0][2] = (char)219;
	text_o[0][1] = (char)223;
	text_o[2][1] = (char)220;

	string text_u[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_u[i][j] = (char)219;
		}
	}
	text_u[0][1] = text_u[1][1] = " ";
	text_u[2][1] = (char)220;

	string text_c[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_c[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_c[i][0] = (char)219;
	}
	text_c[0][1] = text_c[0][2] = (char)223;
	text_c[2][1] = text_c[2][2] = (char)220;

	string text_r[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_r[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_r[i][0] = (char)219;
	}
	text_r[0][1] = (char)223;
	text_r[0][2] = (char)219;

	string text_a[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_a[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_a[i][0] = (char)219;
		text_a[i][2] = (char)219;
	}
	text_a[0][1] = (char)223;
	text_a[1][1] = (char)223;

	string text_s[3][3];
	text_s[0][0] = text_s[1][2] = text_s[2][2] = (char)219;
	text_s[1][0] = text_s[0][1] = text_s[1][1] = text_s[0][2] = (char)223;
	text_s[2][0] = text_s[2][1] = (char)220;

	string text_h[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_h[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_h[i][0] = (char)219;
		text_h[i][2] = (char)219;
	}
	text_h[1][1] = (char)223;

	string text_spcial[3][2];
	text_spcial[0][0] = text_spcial[0][1] = text_spcial[1][0] = text_spcial[1][1] = (char)219;
	text_spcial[2][0] = text_spcial[2][1] = (char)220;

	string text_n[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_n[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_n[i][0] = (char)219;
		text_n[i][2] = (char)219;
	}
	text_n[0][1] = (char)223;

	string text_m[3][5] = {" "};
	for (int i = 0; i < 3; i++)
	{
		text_m[i][0] = (char)219;
		text_m[i][4] = (char)219;
	}
	text_m[1][2] = (char)223;
	text_m[0][1] = text_m[0][3] = (char)223;
	text_m[0][2] = (char)219;

	string text_x[3][5] = { " " };
	text_x[1][2] = text_x[0][1] = text_x[0][3] = text_x[2][1] = text_x[2][3] = char(219);
	text_x[0][0] = text_x[0][4] = char(223);
	text_x[2][0] = text_x[2][4] = char(220);

	string textx[3][3] = { " " };
	textx[1][1] = char(219);
	textx[0][0] = textx[0][2] = char(223);
	textx[2][0] = textx[2][2] = char(220);

	string text_w[3][5] = { " "};
	text_w[0][0] = text_w[1][0] = text_w[0][4] = text_w[1][4] = (char)219;
	text_w[2][0] = text_w[2][4] = (char)223;
	text_w[2][1] = text_w[2][3] = text_w[1][2] = (char)220;
	text_w[2][2] = (char)219;

	string text_v[3][4] = { " " };
	text_v[0][0] = text_v[1][0] = text_v[0][3] = text_v[1][3] = (char)219;
	text_v[2][0] = text_v[2][3] = (char)223;
	text_v[2][1] = text_v[2][2] = (char)220;


	string text_return[3][7] = { " " };
	text_return[0][1] = text_return[0][2] = text_return[0][3] = text_return[0][4] = text_return[0][5] = char(223);
	text_return[0][6] = text_return[1][6] = text_return[2][6] = char(219);
	text_return[2][2] = text_return[2][3] = text_return[2][4] = text_return[2][5] = char(220);
	text_return[2][1] = text_return[1][1] = char(219);
	text_return[1][2] = text_return[1][3] = char(223);
	text_return[1][4] = char(219);

	string text_e[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_e[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_e[i][0] = (char)219;
	}
	text_e[0][1] = text_e[0][2] = text_e[1][1] = text_e[1][2] = (char)223;
	text_e[2][1] = text_e[2][2] = (char)220;

	string text_g[3][4];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			text_g[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_g[i][0] = (char)219;
	}
	text_g[0][1] = text_g[0][2] = text_g[0][3] = (char)223;
	text_g[1][2] = text_g[1][3] = text_g[2][1] = text_g[2][2] = (char)220;
	text_g[2][3] = (char)219;

	string text_i[3][1];
	text_i[0][0] = text_i[1][0] = text_i[2][0] = (char)219;

	string text_p[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_p[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_p[i][0] = (char)219;
	}
	text_p[0][1] = (char)223;
	text_p[1][1] = text_p[1][2] = (char)223;
	text_p[0][2] = (char)219;

	string text_l[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_l[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_l[i][0] = (char)219;
	}
	text_l[2][1] = text_l[2][2] = (char)220;

	string text_t[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_t[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_t[i][1] = (char)219;
	}
	text_t[0][0] = text_t[0][2] = (char)223;

	string text_d[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_d[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_d[i][0] = (char)219;
	}
	text_d[0][1] = (char)223;
	text_d[2][1] = (char)220;
	text_d[0][2] = (char)220;
	text_d[2][2] = (char)223;
	text_d[1][2] = (char)219;


	string text_b[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_b[i][0] = (char)219;
	}
	text_b[0][1] = text_b[2][2] = text_b[1][1] = (char)223;
	text_b[2][1] = text_b[0][2] = (char)220;
	text_b[1][2] = (char)219;

	string text_k[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_k[i][0] = (char)219;
	}
	text_k[1][1] = char(219);
	text_k[0][2] = text_k[2][2] = char(219);

	string text_f[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_f[i][0] = (char)219;
	}
	text_f[0][1] = text_f[0][2] = (char)223;
	text_f[1][1] = text_f[1][2] = (char)223;


	string Redlight[3][3] = { " " };
	Redlight[0][0] = Redlight[0][1] = Redlight[0][2] = char(220);
	Redlight[1][0] = Redlight[1][1] = Redlight[1][2] = char(219);
	Redlight[2][0] = Redlight[2][1] = Redlight[2][2] = char(223);

	string text_q[3][5];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_q[i][j] = " ";
		}
	}
	for (int i = 0; i < 3; i++)
	{
		text_q[i][0] = (char)219;
		text_q[i][4] = (char)219;
	}
	text_q[0][1] = text_q[0][2] = text_q[0][3] = (char)223;
	text_q[2][1] = text_q[2][3] = (char)220;
	text_q[2][2] = (char)219;

	string text_twodots[3][1];
	text_twodots[0][0] = (char)220;
	text_twodots[1][0] = ' ';
	text_twodots[2][0] = (char)223;

	string text_null[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			text_null[i][j] = " ";
		}
	}
	switch (x)
	{
	case 'y':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_y[i][j];
			}
		}
		break;
	}
	case 'o':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_o[i][j];
			}
		}
		break;
	}
	case 'u':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_u[i][j];
			}
		}
		break;
	}
	case 'b':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_b[i][j];
			}
		}
		break;
	}
	case 'c':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_c[i][j];
			}
		}
		break;
	}
	case 'r':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_r[i][j];
			}
		}
		break;
	}
	case 'a':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_a[i][j];
			}
		}
		break;
	}
	case 's':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_s[i][j];
			}
		}
		break;
	}
	case 'h':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_h[i][j];
			}
		}
		break;
	}
	case 'X':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << textx[i][j];
			}
		}
		break;
	}
	case 'z':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_spcial[i][j];
			}
		}
		break;
	}
	case 'm':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_m[i][j];
			}
		}
		break;
	}
	case '?':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_return[i][j];
			}
		}
		break;
	}
	case 'w':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_w[i][j];
			}
		}
		break;
	}
	case 'x':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_x[i][j];
			}
		}
		break;
	}
	case 'v':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_v[i][j];
			}
		}
		break;
	}
	case 'e':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_e[i][j];
			}
		}
		break;
	}
	case 'n':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_n[i][j];
			}
		}
		break;
	}
	case 'g':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_g[i][j];
			}
		}
		break;
	}
	case 'i':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 1; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_i[i][j];
			}
		}
		break;
	}
	case 'p':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_p[i][j];
			}
		}
		break;
	}
	case 'l':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_l[i][j];
			}
		}
		break;
	}
	case 't':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_t[i][j];
			}
		}
		break;
	}
	case 'd':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_d[i][j];
			}
		}
		break;
	}
	case 'k':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_k[i][j];
			}
		}
		break;
	}
	case 'q':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_q[i][j];
			}
		}
		break;
	}
	case 'f':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_f[i][j];
			}
		}
		break;
	}
	case ':':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 1; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_twodots[i][j];
			}
		}
		break;
	}
	case 'j':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_null[i][j];
			}
		}
		break;
	}
	case '<':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				gotoXY(col + j, row + i);
				cout << Redlight[i][j];
			}
		}
		break;
	}
	}
}

void print_Symbol(char x, int col, int row)
{
	char Cup[3][5] = { " " };
	Cup[0][0] = Cup[0][4] = char(223);
	Cup[0][1] = Cup[0][2] = Cup[0][3] = char(219);
	Cup[1][1] = Cup[1][2] = Cup[1][3] = Cup[2][2] = char(219);
	Cup[2][1] = Cup[2][3] = char(220);

	char chamThang[3][1] = { ' ' };
	chamThang[0][0] = char(219);
	chamThang[1][0] = char(219);
	chamThang[2][0] = char(220);

	char haiCham[3][1] = { ' ' };
	haiCham[0][0] = char(220);
	haiCham[2][0] = char(223);

	char gachngang[16] = { " " };
	for (int i = 0; i < 16; i++)
	{
		gachngang[i] = char(219);
	}
	switch (x)
	{
	case '-':
	{
		for (int i = 0; i < 16; i++)
		{
			gotoXY(row + i, col);
			cout << gachngang[i];
		}
		break;
	}
	case '!':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 1; j++)
			{
				gotoXY(col + j, row + i);
				cout << chamThang[i][j];
			}
		}
		break;
	}
	case '@':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				gotoXY(col + j, row + i);
				cout << Cup[i][j];
			}
		}
		break;
	}
	case ':':
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 1; j++)
			{
				gotoXY(col + j, row + i);
				cout << haiCham[i][j];
			}
		}
		break;
	}
	default:
	{
		break;
	}
	}
}

void print_Number(int x, int row, int col)
{
	string text_0[3][3] = { " " };
	text_0[0][0] = text_0[1][0] = text_0[2][0] = text_0[2][2] = text_0[1][2] = text_0[0][2] = (char)219;
	text_0[0][1] = (char)223;
	text_0[2][1] = (char)220;

	string text_1[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_1[i][1] = (char)219;
	}
	text_1[2][0] = text_1[2][2] = (char)220;
	text_1[1][0] = (char)223;

	string text_2[3][3];
	text_2[0][0] = text_2[0][1] = text_2[1][2] = text_2[1][1] = (char)223;
	text_2[2][2] = text_2[2][1] = (char)220;
	text_2[0][2] = text_2[2][0] = text_2[1][0] = (char)219;

	string text_3[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_3[i][2] = (char)219;
	}
	text_3[0][0] = text_3[0][1] = (char)223;
	text_3[1][0] = text_3[1][1] = (char)223;
	text_3[2][0] = text_3[2][1] = (char)220;

	string text_4[3][3] = { " " };
	text_4[0][0] = text_4[1][0] = (char)219;
	text_4[1][1] = (char)220;
	text_4[1][2] = text_4[2][2] = (char)219;

	string text_5[3][3] = { " " };
	text_5[0][0] = (char)219;
	text_5[0][1] = text_5[0][2] = (char)223;
	text_5[1][0] = text_5[1][1] = (char)223;
	text_5[1][2] = text_5[2][2] = (char)219;
	text_5[2][0] = text_5[2][1] = (char)220;

	string text_6[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_6[i][0] = (char)219;
	}
	text_6[0][1] = text_6[0][2] = text_6[1][1] = (char)223;
	text_6[1][2] = text_6[2][2] = (char)219;
	text_6[2][1] = (char)220;

	string text_7[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_7[i][2] = (char)219;
	}
	text_7[0][0] = text_7[0][1] = (char)223;
	text_7[1][1] = (char)223;

	string text_8[3][3] = { " " };
	text_8[0][0] = text_8[1][0] = text_8[2][0] = text_8[2][2] = text_8[1][2] = text_8[0][2] = (char)219;
	text_8[0][1] = text_8[1][1] = (char)223;
	text_8[2][1] = (char)220;

	string text_9[3][3] = { " " };
	for (int i = 0; i < 3; i++)
	{
		text_9[i][2] = (char)219;
	}
	text_9[0][0] = (char)219;
	text_9[0][1] = text_9[1][0] = text_9[1][1] = text_9[0][1] = (char)223;
	text_9[2][0] = text_9[2][1] = (char)220;

	switch (x)
	{
		case 0:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_0[i][j];
				}
			}
			break;
		}
		case 1:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_1[i][j];
				}
			}
			break;
		}
		case 2:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_2[i][j];
				}
			}
			break;
		}
		case 3:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_3[i][j];
				}
			}
			break;
		}
		case 4:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_4[i][j];
				}
			}
			break;
		}
		case 5:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_5[i][j];
				}
			}
			break;
		}
		case 6:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_6[i][j];
				}
			}
			break;
		}
		case 7:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_7[i][j];
				}
			}
			break;
		}
		case 8:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_8[i][j];
				}
			}
			break;
		}
		case 9:
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					gotoXY(col + j, row + i);
					cout << text_9[i][j];
				}
			}
			break;
		}
	}
}

void print_Text_Menu(char x, int col, int row)
{
	char c[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			c[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		c[0][i] = (char)219;
		c[6][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		c[i][0] = (char)219;
		c[i][1] = (char)219;
	}

	char C[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			C[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		C[0][i] = (char)205;
		C[6][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		C[i][0] = (char)186;
		C[i][1] = (char)186;
	}
	C[0][0] = C[0][1] = (char)201;
	C[6][0] = C[6][1] = (char)200;

	char r[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			r[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		r[0][i] = (char)219;
		r[3][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		r[i][0] = (char)219;
		r[i][1] = (char)219;
	}
	for (int i = 0; i < 3; i++)
	{
		r[i][5] = (char)219;
		r[i][6] = (char)219;
	}
	r[4][3] = r[4][4] = (char)219;
	r[5][4] = r[5][5] = (char)219;
	r[6][5] = r[6][6] = (char)219;

	char R[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			R[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		R[0][i] = (char)205;
		R[3][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		R[i][0] = (char)186;
		R[i][1] = (char)186;
	}
	for (int i = 0; i < 3; i++)
	{
		R[i][5] = (char)186;
		R[i][6] = (char)186;
	}
	R[0][0] = R[0][1] = (char)201;
	R[0][5] = R[0][6] = (char)187;
	R[6][0] = R[6][1] = (char)200;
	R[3][5] = R[3][6] = (char)188;
	R[4][3] = R[4][4] = (char)186;
	R[5][4] = R[5][5] = (char)186;
	R[6][5] = (char)200;
	R[6][6] = (char)188;

	char o[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			o[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		o[0][i] = (char)219;
		o[6][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		o[i][0] = (char)219;
		o[i][1] = (char)219;
		o[i][5] = (char)219;
		o[i][6] = (char)219;
	}

	char O[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			O[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		O[0][i] = (char)205;
		O[6][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		O[i][0] = (char)186;
		O[i][1] = (char)186;
		O[i][5] = (char)186;
		O[i][6] = (char)186;
	}
	O[0][0] = O[0][1] = (char)201;
	O[0][5] = O[0][6] = (char)187;
	O[6][0] = O[6][1] = (char)200;
	O[6][5] = O[6][6] = (char)188;

	char s[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			s[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		s[0][i] = (char)219;
		s[3][i] = (char)219;
		s[6][i] = (char)219;
	}
	for (int i = 0; i < 3; i++)
	{
		s[i][0] = (char)219;
		s[i][1] = (char)219;
	}
	for (int i = 3; i < 6; i++)
	{
		s[i][5] = (char)219;
		s[i][6] = (char)219;
	}

	char S[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			S[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		S[0][i] = (char)205;
		S[3][i] = (char)205;
		S[6][i] = (char)205;
	}
	for (int i = 0; i < 3; i++)
	{
		S[i][0] = (char)186;
		S[i][1] = (char)186;
	}
	for (int i = 3; i < 6; i++)
	{
		S[i][5] = (char)186;
		S[i][6] = (char)186;
	}
	S[0][0] = S[0][1] = (char)201;
	S[3][0] = S[3][1] = (char)200;
	S[3][5] = S[3][6] = (char)187;
	S[6][5] = S[6][6] = (char)188;

	char t[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			t[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		t[0][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		t[i][2] = (char)219;
		t[i][3] = (char)219;
		t[i][4] = (char)219;
	}

	char T[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			T[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		T[0][i] = (char)205;
	}
	for (int i = 1; i < 7; i++)
	{
		T[i][3] = (char)186;
	}
	T[6][3] = (char)200;

	char h[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			h[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		h[3][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		h[i][0] = (char)219;
		h[i][1] = (char)219;
		h[i][5] = (char)219;
		h[i][6] = (char)219;
	}

	char H[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			H[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		H[3][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		H[i][0] = (char)186;
		H[i][1] = (char)186;
		H[i][5] = (char)186;
		H[i][6] = (char)186;
	}
	H[0][0] = H[0][5] = (char)201;
	H[0][1] = H[0][6] = (char)187;
	H[6][0] = H[6][5] = (char)200;
	H[6][1] = H[6][6] = (char)188;

	char e[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			e[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		e[0][i] = (char)219;
		e[3][i] = (char)219;
		e[6][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		e[i][0] = (char)219;
		e[i][1] = (char)219;
	}

	char E[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			E[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		E[0][i] = (char)205;
		E[3][i] = (char)205;
		E[6][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		E[i][0] = (char)186;
		E[i][1] = (char)186;
	}
	E[0][0] = E[0][1] = (char)201;
	E[6][0] = E[6][1] = (char)200;

	char a[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			a[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		a[0][i] = (char)219;
		a[3][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		a[i][0] = (char)219;
		a[i][1] = (char)219;
		a[i][5] = (char)219;
		a[i][6] = (char)219;
	}

	char A[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			A[i][j] = ' ';
		}
	}
	for (int i = 0; i < 7; i++)
	{
		A[0][i] = (char)205;
		A[3][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		A[i][0] = (char)186;
		A[i][1] = (char)186;
		A[i][5] = (char)186;
		A[i][6] = (char)186;
	}
	A[0][0] = A[0][1] = (char)201;
	A[0][5] = A[0][6] = (char)187;
	A[6][0] = A[6][5] = (char)200;
	A[6][1] = A[6][6] = (char)188;

	char d[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			d[i][j] = ' ';
		}
	}
	for (int i = 0; i < 5; i++)
	{
		d[0][i] = (char)219;
		d[6][i] = (char)219;
	}
	for (int i = 0; i < 7; i++)
	{
		d[i][0] = (char)219;
		d[i][1] = (char)219;
	}
	for (int i = 1; i < 6; i++)
	{
		d[i][5] = (char)219;
		d[i][6] = (char)219;
	}

	char D[7][7];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			D[i][j] = ' ';
		}
	}
	for (int i = 0; i < 5; i++)
	{
		D[0][i] = (char)205;
		D[6][i] = (char)205;
	}
	for (int i = 0; i < 7; i++)
	{
		D[i][0] = (char)186;
		D[i][1] = (char)186;
	}
	for (int i = 1; i < 6; i++)
	{
		D[i][5] = (char)186;
		D[i][6] = (char)186;
	}
	D[0][0] = D[0][1] = (char)201;
	D[6][0] = D[6][1] = (char)200;

	switch (x)
	{
	case 'c':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << c[i][j];
			}
		}
		break;
	}
	case 'C':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << C[i][j];
			}
		}
		break;
	}
	case 'r':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << r[i][j];
			}
		}
		break;
	}
	case 'R':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << R[i][j];
			}
		}
		break;
	}
	case 'o':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << o[i][j];
			}
		}
		break;
	}
	case 'O':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << O[i][j];
			}
		}
		break;
	}
	case 's':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << s[i][j];
			}
		}
		break;
	}
	case 'S':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << S[i][j];
			}
		}
		break;
	}
	case 't':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << t[i][j];
			}
		}
		break;
	}
	case 'T':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << T[i][j];
			}
		}
		break;
	}
	case 'h':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << h[i][j];
			}
		}
		break;
	}
	case 'H':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << H[i][j];
			}
		}
		break;
	}
	case 'e':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << e[i][j];
			}
		}
		break;
	}
	case 'E':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << E[i][j];
			}
		}
		break;
	}
	case 'a':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << a[i][j];
			}
		}
		break;
	}
	case 'A':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << A[i][j];
			}
		}
		break;
	}
	case 'd':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << d[i][j];
			}
		}
		break;
	}
	case 'D':
	{
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				gotoXY(j + col, i + row);
				cout << D[i][j];
			}
		}
		break;
	}
	default:
	{
		break;
	}
	}
}

void print_Text_Intro(char x, int col, int row)
{
	char B[14][14];
	for (int i = 0; i < 14; i++)
	{
		for (int j = 0; j < 14; j++)
		{
			B[i][j] = ' ';
		}
	}
	for (int i = 0; i < 13; i++) // hang ngang
	{
		B[0][i] = (char)219;
	}
	for (int i = 2; i < 13; i++) // hang ngang 2
	{
		B[6][i] = (char)219;
	}
	for (int i = 2; i < 13; i++) // hang ngang 3
	{
		B[3][i] = (char)219;
	}
	for (int i = 0; i < 8; i++) // hang doc 1
	{

		B[i][2] = (char)219;
		B[i][3] = (char)219;
	}
	for (int i = 0; i < 7; i++) // hang doc 1
	{

		B[i][11] = (char)219;
		B[i][12] = (char)219;
	}

	char R[11][11];
	for (int i = 0; i < 11; i++)
	{
		for (int j = 0; j < 11; j++)
		{
			R[i][j] = ' ';
		}
	}
	for (int i = 0; i < 10; i++) // hang ngang
	{
		R[0][i] = (char)219;
		R[3][i] = (char)219;
	}
	for (int i = 0; i < 7; i++) // hang doc
	{
		R[i][0] = (char)219;
		R[i][1] = (char)219;
	}
	for (int i = 0; i < 3; i++) // hang doc
	{
		R[i][8] = (char)219;
		R[i][9] = (char)219;
	}
	R[4][2] = (char)219;
	R[4][3] = (char)219;

	R[5][4] = (char)219;
	R[5][5] = (char)219;

	R[6][6] = (char)219;
	R[6][7] = (char)219;

	char O[10][10];
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			O[i][j] = ' ';
		}
	}
	for (int i = 0; i < 10; i++) // hang ngang
	{
		O[0][i] = (char)219;
		O[6][i] = (char)219;
	}
	for (int i = 0; i < 6; i++) // hang doc
	{
		O[i][0] = (char)219;
		O[i][1] = (char)219;

		O[i][8] = (char)219;
		O[i][9] = (char)219;
	}

	O[1][4] = (char)219;
	O[1][5] = (char)219;

	O[5][4] = (char)219;
	O[5][5] = (char)219;

	char F[10][10];
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			F[i][j] = ' ';
		}
	}
	for (int i = 0; i < 10; i++) // hang ngang
	{
		F[0][i] = (char)219;
	}
	for (int i = 2; i < 8; i++) // hang ngang
	{
		F[3][i] = (char)219;
	}
	for (int i = 0; i < 7; i++) // hang doc
	{
		F[i][2] = (char)219;
		F[i][3] = (char)219;
	}

	char C[10][10];
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			C[i][j] = ' ';
		}
	}
	for (int i = 0; i < 10; i++) // hang ngang
	{
		C[0][i] = (char)219;
		C[6][i] = (char)219;
	}
	for (int i = 0; i < 6; i++) // hang doc
	{
		C[i][0] = (char)219;
		C[i][1] = (char)219;
	}
	C[1][8] = (char)219;
	C[1][9] = (char)219;

	C[5][8] = (char)219;
	C[5][9] = (char)219;

	char E[10][10] = { ' ' };
	for (int i = 0; i < 10; i++) // hang ngang
	{
		E[0][i] = (char)219;
		E[6][i] = (char)219;
	}
	for (int i = 0; i < 8; i++) // hang ngang
	{
		E[3][i] = (char)219;
	}
	for (int i = 0; i < 6; i++) // hang doc
	{
		E[i][0] = (char)219;
		E[i][1] = (char)219;
	}

	char text_NULL[20][20] = {' '};

	switch (x)
	{
	case 'B':
	{
		for (int i = 0; i < 14; i++)
		{
			for (int j = 0; j < 14; j++)
			{
				gotoXY(col + j, row + i);
				cout << B[i][j];
			}
		}
		break;
	}
	case 'R':
	{
		for (int i = 0; i < 11; i++)
		{
			for (int j = 0; j < 11; j++)
			{
				gotoXY(col + j, row + i);
				cout << R[i][j];
			}
		}
		break;
	}
	case 'O':
	{
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				gotoXY(col + j, row + i);
				cout << O[i][j];
			}
		}
		break;
	}
	case 'F':
	{
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				gotoXY(col + j, row + i);
				cout << F[i][j];
			}
		}
		break;
	}
	case 'C':
	{
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				gotoXY(col + j, row + i);
				cout << C[i][j];
			}
		}
		break;
	}
	case 'E':
	{
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				gotoXY(col + j, row + i);
				cout << E[i][j];
			}
		}
		break;
	}
	case 'Q':
	{
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				gotoXY(col + j, row + i);
				cout << text_NULL[i][j];
			}
		}
		break;
	}
	default:
	{
		break;
	}
	}
}