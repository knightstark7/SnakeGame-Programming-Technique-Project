#include "c_music.h"

void playMusicMainMenu(int& soundBG)
{
	mciSendString(L"open \"BGMusic.mp3\" type mpegvideo alias mp3", NULL, 0, NULL); //open music file
	if (soundBG == 1)
		mciSendString(L"play mp3 repeat", NULL, 0, NULL);
	else if (soundBG == 0)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
		mciSendString(L"close mp3", NULL, 0, NULL);
	}
}

void playLoseSound(int& soundIG, bool isLose)
{
	mciSendString(L"open \"LoseSound.mp3\" type mpegvideo alias mp3", NULL, 0, NULL); //open music file
	if (soundIG == 1)
		mciSendString(L"play mp3", NULL, 0, NULL);
	else if (soundIG == 0)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
		mciSendString(L"close mp3", NULL, 0, NULL);
	}
	if (isLose == false)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
		mciSendString(L"close mp3", NULL, 0, NULL);
	}
}

void playMusicGame(int& soundIG, bool isLose)
{
	mciSendString(L"open \"IGMusic.mp3\" type mpegvideo alias mp3", NULL, 0, NULL); //open music file
	if (soundIG == 1)
		mciSendString(L"play mp3 repeat", NULL, 0, NULL);
	else if (soundIG == 0)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
	}
	if (isLose == true)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
		mciSendString(L"close mp3", NULL, 0, NULL);
	}
}

void playWinMusicGame(int& soundIG, bool isStop)
{
	mciSendString(L"open \"WinMusic.mp3\" type mpegvideo alias mp3", NULL, 0, NULL); //open music file
	if (soundIG == 1)
		mciSendString(L"play mp3 repeat", NULL, 0, NULL);
	else if (soundIG == 0)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
	}
	if (isStop == true)
	{
		mciSendString(L"stop mp3", NULL, 0, NULL);
		mciSendString(L"close mp3", NULL, 0, NULL);
	}
}