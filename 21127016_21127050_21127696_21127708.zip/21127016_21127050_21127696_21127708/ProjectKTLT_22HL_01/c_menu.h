#include <Windows.h>
#include "c_snake.h"
#pragma comment(lib, "winmm.lib")
#pragma once

void printIntro();
int MenuPause(bool Paused, int soundIG, int soundEF);
int MenuSelectModeGame(int soundBG, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2);
int MainMenu(int soundBG, int soundIG, int soundEF);
void HuongDanChoi(int x, int y, int VungDiChuyen, int ChieuRong, MoveKeyBoard keyboardP1, MoveKeyBoard keyboardP2);
int MenuOption(int x, int y, int VungDiChuyen, int ChieuRong, bool Paused, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundIG, int& soundEF,
	char* ten_nguoi_choi, int diem, int ran_dot, ToaDo* ran, int SPEED, int huong, int man, int vat_can_dong_so_o, ToaDo* vat_can_dong,
	string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int mode);
int MenuOption2(int x, int y, int VungDiChuyen, int ChieuRong, bool Paused, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundIG, int& soundEF,
	char* ten_nguoi_choi1, char* ten_nguoi_choi2, int diem1, int diem2, int ran_dot1, ToaDo* ran1, int ran_dot2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man, int vat_can, ToaDo* vat_can_dong,
	string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int mode);
void MenuConfig(int x, int y, int VungDiChuyen, int ChieuRong, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundBG, int& soundEF);
int MenuGameOver(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int& diem, char* ten_nguoi_choi, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int mode);
int MenuGameOverMode4(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int diem, int diem2, int whoWin);
int About(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2);
int LoadGame(char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, NguoiChoi* danhSachNguoiChoi, NguoiChoi** danhSachNguoiChoi2);
int SaveGame(char* ten_nguoi_choi, int diem, int ran_dot, ToaDo* ran, int SPEED, int huong, int man, int vat_can_dong_so_o,
	ToaDo vat_can[], string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode);
int SaveGame2(char* ten_nguoi_choi, char* ten_nguoi_choi2, int diem1, int diem2, int ran_dot1, ToaDo* ran1, int ran_dot2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man, int vat_can_dong_so_o,
	ToaDo vat_can[], string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode);
int LeaderBoard(int soundBG, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2);
int MenuWinning(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int& diem, char* ten_nguoi_choi, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int mode);
