﻿#include "c_snake.h"
#include "c_mylib.h"
#include "c_text.h"
#include <iostream>
using namespace std;

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 45
#define TUONG_TRAI 5
#define TUONG_PHAI 102

void VeVien(int x, int y, int VungDiChuyen, int ChieuRong)
{
	TextColor(0); //17 - 187
	for (int i = x - 4; i <= VungDiChuyen + 8; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y - 2); std::cout << char(219);
		//Vẽ cạnh dưới
		gotoXY(i, y + ChieuRong + 8); std::cout << char(219);
	}
	for (int i = y - 2; i <= ChieuRong + 9; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x - 3, i); std::cout << char(219);
		gotoXY(x - 4, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen + 3, i); std::cout << char(219);
		gotoXY(x + VungDiChuyen + 4, i); std::cout << char(219);
	}
	TextColor(134); //187
	for (int i = x - 2; i <= VungDiChuyen + 6; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y - 1); std::cout << char(219);
		//Vẽ cạnh dưới
		gotoXY(i, y + ChieuRong + 7); std::cout << char(219);
	}
	for (int i = y; i <= ChieuRong + 8; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x - 1, i); std::cout << char(219);
		gotoXY(x - 2, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen + 1, i); std::cout << char(219);
		gotoXY(x + VungDiChuyen + 2, i); std::cout << char(219);
	}
	TextColor(240);
}

void VeVungRanDiChuyen(int x, int y, int VungDiChuyen, int ChieuRong)
{
	TextColor(240);
	//Vẽ cạnh trên và dưới
	for (int i = x; i <= VungDiChuyen + 3; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y); std::cout << char(219);
	}
	//Vẽ cạnh trái - cạnh phải - cạnh phân chia vùng rắn di chuyển và bảng điểm
	for (int i = y; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen, i); std::cout << char(219);
	}
}
//||||||||||||||||||||||||||||||||||||||||||||||VẼ THANH BẢNG ĐIỂM||||||||||||||||||||||||||||||||||||||||||||||||||||||

void Nut_Return(int x, int y, int VungBangDiem, int ChieuRong, int man)
{
	//KHUNG RETURN 
	TextColor(240);
	//2 THANH NGANG
	for (int i = x; i <= VungBangDiem - 86; i++)
	{
		gotoXY(i, ChieuRong + 2); std::cout << char(219);
		gotoXY(i, ChieuRong + 8); std::cout << char(219);
	}
	//2 THANH DOC
	for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
	{
		gotoXY(x, i); std::cout << char(219);
		gotoXY(x + 9, i); std::cout << char(219);
	}
	//NEN TRONG
	TextColor(136);
	for (int i = x; i <= x + 7; i++) //x + 29
	{
		for (int j = ChieuRong; j <= ChieuRong + 4; j++)
		{
			gotoXY(i + 1, j + 3); std::cout << char(219);
		}
	}
	TextColor(139);
	char symbol[1] = { '?' };
	print_Text(symbol[0], 48, 5);
}

void Nut_Option(int x, int y, int VungBangDiem, int ChieuRong, int man)
{
	//KHUNG OPTION
	//Vẽ 2 thanh ngang
	TextColor(240);
	for (int i = x + 9; i <= VungBangDiem - 62; i++)
	{
		gotoXY(i, ChieuRong + 2); std::cout << char(219);
		gotoXY(i, ChieuRong + 8); std::cout << char(219);
	}
	//Vẽ 2 thanh dọc
	TextColor(240);
	for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
	{
		gotoXY(x + 9, i); std::cout << char(219);
		gotoXY(x + 33, i); std::cout << char(219);
	}
	TextColor(204);
	for (int i = x + 1; i <= x + 23; i++) //x + 29
	{
		for (int j = ChieuRong + 3; j <= ChieuRong + 7; j++)
		{
			gotoXY(i + 9, j); std::cout << char(219);
		}
	}
	TextColor(199);
	char option[6] = { 'o', 'p', 't', 'i', 'o', 'n' };
	print_Text(option[0], 48, 15);
	print_Text(option[1], 48, 19);
	print_Text(option[2], 48, 23);
	print_Text(option[3], 48, 27);
	print_Text(option[4], 48, 29);
	print_Text(option[5], 48, 33);
}

void Nut_Guide(int x, int y, int VungBangDiem, int ChieuRong, int man)
{
	//KHUNG GUIDE
	TextColor(240);
	// Vẽ 2 thanh ngang
	for (int i = x + 34; i <= VungBangDiem - 41; i++)
	{
		gotoXY(i, ChieuRong + 2); std::cout << char(219);
		gotoXY(i, ChieuRong + 8); std::cout << char(219);
	}
	//Vẽ 2 thanh dọc
	for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
	{
		gotoXY(x + 33, i); std::cout << char(219);
		gotoXY(x + 54, i); std::cout << char(219);
	}
	TextColor(221);
	for (int i = x + 34; i <= VungBangDiem - 41; i++) //x + 29
	{
		for (int j = ChieuRong + 3; j <= ChieuRong + 7; j++)
		{
			gotoXY(i, j); std::cout << char(219);
		}
	}
	TextColor(219);
	char guide[5] = { 'g', 'u', 'i', 'd', 'e' };
	print_Text(guide[0], 48, 39);
	print_Text(guide[1], 48, 44);
	print_Text(guide[2], 48, 48);
	print_Text(guide[3], 48, 50);
	print_Text(guide[4], 48, 54);
}

void VeBangDiem(int x, int y, int VungBangDiem, int ChieuRong, int man)
{
	//VACH NGAN CACH BANG DIEM
	TextColor(240);
	for (int i = x; i <= VungBangDiem + 4; i++)
	{
		gotoXY(i, ChieuRong + 2); std::cout << char(219);
		gotoXY(i, ChieuRong + 8); std::cout << char(219);
	}
	for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
	{
		gotoXY(x, i); std::cout << char(219);
		gotoXY(VungBangDiem + 4, i); std::cout << char(219);
	}

	Nut_Return(x, y, VungBangDiem, ChieuRong, man);
	Nut_Option(x, y, VungBangDiem, ChieuRong, man);
	Nut_Guide(x, y, VungBangDiem, ChieuRong, man);
}

bool CapNhatDiem(int& diemtmp, int& diem)
{
	if (diem > diemtmp)
	{
		diemtmp = diem;
		return true;
	}
	else
	{
		return false;
	}
}

void VeDiem(int x, int y, int ChieuRong, int& diem, bool checkPause, bool IsLose)
{
	int soDonVi = 0;
	int soHangChuc = 0;
	int soHangTram = 0;
	int soHangNghin = 0;
	int soChucNghin = 0;

	soDonVi = diem % 10;
	soHangChuc = diem / 10 % 10;
	soHangTram = diem / 100 % 10;
	soHangNghin = diem / 1000 % 10;
	soChucNghin = diem / 10000 % 10;

	TextColor(17);
	for (int i = x; i <= x + 42; i++) //x + 29
	{
		for (int j = ChieuRong; j <= ChieuRong + 4; j++)
		{
			gotoXY(i + 55, j + 3); std::cout << char(219);
		}
	}
	TextColor(30);
	char score[6] = { 's', 'c', 'o', 'r', 'e', ':' };
	print_Text(score[0], 48, 60);
	print_Text(score[1], 48, 64);
	print_Text(score[2], 48, 68);
	print_Text(score[3], 48, 72);
	print_Text(score[4], 48, 76);
	print_Text(score[5], 48, 80);

	print_Number(soChucNghin, 48, 82);
	print_Number(soHangNghin, 48, 86);
	print_Number(soHangTram, 48, 90);
	print_Number(soHangChuc, 48, 94);
	print_Number(soDonVi, 48, 98);
}

void VeDiemMode4(int x, int y, int ChieuRong, int& diem, int& diem2, bool checkPause, bool IsLose)
{
	int soDonVi = 0;
	int soHangChuc = 0;
	int soHangTram = 0;

	soDonVi = diem % 10;
	soHangChuc = diem / 10 % 10;
	soHangTram = diem / 100 % 10;

	int soDonVi2 = 0;
	int soHangChuc2 = 0;
	int soHangTram2 = 0;

	soDonVi2 = diem2 % 10;
	soHangChuc2 = diem2 / 10 % 10;
	soHangTram2 = diem2 / 100 % 10;

	TextColor(17);
	for (int i = x; i <= x + 21; i++) //x + 29
	{
		for (int j = ChieuRong; j <= ChieuRong + 4; j++)
		{
			gotoXY(i + 55, j + 3); std::cout << char(219);
		}
	}

	TextColor(170);
	for (int i = x + 21; i <= x + 42; i++) //x + 29
	{
		for (int j = ChieuRong; j <= ChieuRong + 4; j++)
		{
			gotoXY(i + 55, j + 3); std::cout << char(219);
		}
	}
	TextColor(30);
	char score[3] = { 'a','b',':'};
	print_Text(score[0], 48, 61);
	print_Text(score[2], 48, 65);
	print_Number(soHangTram, 48, 67);
	print_Number(soHangChuc, 48, 71);
	print_Number(soDonVi, 48, 75);

	TextColor(174);
	print_Text(score[1], 48, 83);
	print_Text(score[2], 48, 87);
	print_Number(soHangTram2, 48, 89);
	print_Number(soHangChuc2, 48, 93);
	print_Number(soDonVi2, 48, 97);
}

void VeVatCan(ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		gotoXY(ChuongNgaiVat[i].x, ChuongNgaiVat[i].y);
		std::cout << char(219);
	}
}

void VeManChoi(int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, ToaDo ChuongNgaiVat[], int KichThuocVatCan, int man)
{
	system("color F0");
	//vẽ vùng rắn di chuyển
	VeVungRanDiChuyen(x, y, VungDiChuyen, ChieuRong);
	//vẽ bảng điểm
	VeBangDiem(x, y, VungBangDiem, ChieuRong, man);
	//vẽ viền màn chơi
	VeVien(x, y, VungDiChuyen, ChieuRong);
	//vẽ vật cản màn 2
	VeVatCan(ChuongNgaiVat, KichThuocVatCan);
}

//Ve ran
void VeRan(ToaDo ran[], int BodyRan)
{
	//MSSV: 21127016 - 21127050 - 21127696 - 21127708
	int a[100] = { 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8, 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8};
	for (int i = 0; i < BodyRan; i++)
	{
		gotoXY(ran[i].x, ran[i].y);
		cout << a[i];
	}
}

void HienThiRan(ToaDo ran[], ToaDo dot_cuoi_cu, int BodyRan)
{
	//MSSV: 21127016 - 21127050 - 21127696 - 21127708
	int a[100] = { 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8, 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8 };
	TextColor(78); gotoXY(ran[0].x, ran[0].y); cout << a[0];
	for (int i = 1; i < BodyRan; i++)
	{
		gotoXY(ran[i].x, ran[i].y);
		TextColor(112);
		cout << a[i];
	}
	gotoXY(dot_cuoi_cu.x, dot_cuoi_cu.y);
	TextColor(240); cout << " ";
}

void HienThiRan2(ToaDo ran[], ToaDo dot_cuoi_cu, int BodyRan)
{
	//MSSV: 21127016 - 21127050 - 21127696 - 21127708
	int a[100] = { 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8, 2, 1, 1, 2, 7, 0, 1, 6, 2, 1, 1, 2, 7, 0, 5, 0, 2, 1, 1, 2, 7, 6, 9, 6, 2, 1, 1, 2, 7, 7, 0, 8 };
	TextColor(30); gotoXY(ran[0].x, ran[0].y); cout << a[0];
	for (int i = 1; i < BodyRan; i++)
	{
		gotoXY(ran[i].x, ran[i].y);
		TextColor(112);
		cout << a[i];
	}
	gotoXY(dot_cuoi_cu.x, dot_cuoi_cu.y);
	TextColor(240); cout << " ";
}

void BatSuKienMode1(int& huong, bool& checkPause, MoveKeyBoard& KeyBoardP1, bool TrungDoc)
{
	int key = inputKey();
	if (key == 'p' || key == 'P')
	{
		checkPause = true;
		return;
	}
	if (huong == 3)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			if (TrungDoc == 1) {
				huong = XUONG;
			}
			else {
				huong = LEN;
			}
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			if (TrungDoc == 1) {
				huong = LEN;
			}
			else {
				huong = XUONG;
			}
		}
	}
	else if (huong == 1)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			if (TrungDoc == 1) {
				huong = PHAI;
			}
			else {
				huong = TRAI;
			}
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			if (TrungDoc == 1) {
				huong = TRAI;
			}
			else {
				huong = PHAI;
			}
		}
	}
	else if (huong == 4)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			if (TrungDoc == 1) {
				huong = XUONG;
			}
			else {
				huong = LEN;
			}
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			if (TrungDoc == 1) {
				huong = LEN;
			}
			else {
				huong = XUONG;
			}
		}
	}
	else if (huong == 2)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			if (TrungDoc == 1) {
				huong = PHAI;
			}
			else {
				huong = TRAI;
			}
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			if (TrungDoc == 1) {
				huong = TRAI;
			}
			else {
				huong = PHAI;
			}
		}
	}
}

void BatSuKienMode2(int& huong, bool& checkPause, MoveKeyBoard& KeyBoardP1)
{
	int key = inputKey();
	if (key == 'p' || key == 'P')
	{
		checkPause = true;
		return;
	}
	if (huong == 3)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			huong = LEN;
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			huong = XUONG;
		}
	}
	else if (huong == 1)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			huong = TRAI;
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			huong = PHAI;
		}
	}
	else if (huong == 4)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			huong = LEN;
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			huong = XUONG;
		}
	}
	else if (huong == 2)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			huong = TRAI;
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			huong = PHAI;
		}
	}
}

void BatSuKienMode3(int& huong1, int& huong2, bool& checkPause, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, bool TrungDoc1, bool TrungDoc2)
{
	int key = inputKey();
	if (key == 'p' || key == 'P')
	{
		checkPause = true;
		return;
	}

	if (huong1 == 3)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			if (TrungDoc1 == 1) {
				huong1 = XUONG;
			}
			else {
				huong1= LEN;
			}
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			if (TrungDoc1 == 1) {
				huong1 = LEN;
			}
			else {
				huong1 = XUONG;
			}
		}
	}
	else if (huong1 == 1)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			if (TrungDoc1 == 1) {
				huong1 = PHAI;
			}
			else {
				huong1 = TRAI;
			}
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			if (TrungDoc1 == 1) {
				huong1 = TRAI;
			}
			else {
				huong1 = PHAI;
			}
		}
	}
	else if (huong1 == 4)
	{
		if (key == KeyBoardP1.MoveUp)
		{
			if (TrungDoc1 == 1) {
				huong1 = XUONG;
			}
			else {
				huong1 = LEN;
			}
		}
		else if (key == KeyBoardP1.MoveDown)
		{
			if (TrungDoc1 == 1) {
				huong1 = LEN;
			}
			else {
				huong1 = XUONG;
			}
		}
	}
	else if (huong1 == 2)
	{
		if (key == KeyBoardP1.MoveLeft)
		{
			if (TrungDoc1 == 1) {
				huong1 = PHAI;
			}
			else {
				huong1 = TRAI;
			}
		}
		else if (key == KeyBoardP1.MoveRight)
		{
			if (TrungDoc1 == 1) {
				huong1 = TRAI;
			}
			else {
				huong1 = PHAI;
			}
		}
	}

	if (huong2 == 3)
	{
		if (key == KeyBoardP2.MoveUp)
		{
			if (TrungDoc2 == 1) {
				huong2 = XUONG;
			}
			else {
				huong2 = LEN;
			}
		}
		else if (key == KeyBoardP2.MoveDown)
		{
			if (TrungDoc2 == 1) {
				huong2 = LEN;
			}
			else {
				huong2 = XUONG;
			}
		}
	}
	else if (huong2 == 1)
	{
		if (key == KeyBoardP2.MoveLeft)
		{
			if (TrungDoc2 == 1) {
				huong2 = PHAI;
			}
			else {
				huong2 = TRAI;
			}
		}
		else if (key == KeyBoardP2.MoveRight)
		{
			if (TrungDoc2 == 1) {
				huong2 = TRAI;
			}
			else {
				huong2 = PHAI;
			}
		}
	}
	else if (huong2 == 4)
	{
		if (key == KeyBoardP2.MoveUp)
		{
			if (TrungDoc2 == 1) {
				huong2 = XUONG;
			}
			else {
				huong2 = LEN;
			}
		}
		else if (key == KeyBoardP2.MoveDown)
		{
			if (TrungDoc2 == 1) {
				huong2 = LEN;
			}
			else {
				huong2 = XUONG;
			}
		}
	}
	else if (huong2 == 2)
	{
		if (key == KeyBoardP2.MoveLeft)
		{
			if (TrungDoc2 == 1) {
				huong2 = PHAI;
			}
			else {
				huong2 = TRAI;
			}
		}
		else if (key == KeyBoardP2.MoveRight)
		{
			if (TrungDoc2 == 1) {
				huong2 = TRAI;
			}
			else {
				huong2 = PHAI;
			}
		}
	}
}

ToaDo DiChuyen(ToaDo ran[], int huong, int BodyRan)
{
	ToaDo dot_cuoi_cu = ran[BodyRan - 1];
	for (int i = BodyRan - 1; i >= 1; i--)
	{
		ran[i] = ran[i - 1];
	}
	switch (huong)
	{
	case 1:
	{
		ran[0].y--;
		break;
	}
	case 2:
	{
		ran[0].y++;
		break;
	}
	case 3:
	{
		ran[0].x--;
		break;
	}
	case 4:
	{
		ran[0].x++;
		break;
	}
	}
	return dot_cuoi_cu;
}

//ran cham than
bool RanChamThan(ToaDo ran[], int BodyRan)
{
	for (int i = 1; i < BodyRan; i++)
	{
		if (ran[0].x == ran[i].x && ran[0].y == ran[i].y)
		{
			return true;
		}
	}
	return false;
}

//Kiem tra thua khi ran cham vao khung tro choi
bool RanChamTuong(ToaDo ran[])
{
	if (ran[0].y == TUONG_TREN)
	{
		return true;
	}
	if (ran[0].y == TUONG_DUOI)
	{
		return true;
	}
	if (ran[0].x == TUONG_TRAI)
	{
		return true;
	}
	if (ran[0].x == TUONG_PHAI)
	{
		return true;
	}
	return false;
}

bool KiemTraToaDoQuaKhaThi(int x, int y, ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (abs(x - ChuongNgaiVat[i].x) <= 5 && abs(y - ChuongNgaiVat[i].y) <= 5 && x <= TUONG_PHAI - 10)
		{
			return false;
		}
	}
	return true;
}

//Kiem tra an qua
bool KiemTraAnQua(ToaDo ran[], QUA food)
{
	if (ran[0].x == food.NormalFood.x && ran[0].y == food.NormalFood.y)
	{
		return true;
	}
	else if (ran[0].x - 1 == food.NormalFood.x && ran[0].y == food.NormalFood.y)
	{
		return true;
	}
	else if (ran[0].x + 1 == food.NormalFood.x && ran[0].y == food.NormalFood.y)
	{
		return true;
	}
	else if (ran[0].x == food.NormalFood.x && ran[0].y - 1 == food.NormalFood.y)
	{
		return true;
	}
	else if (ran[0].x == food.NormalFood.x && ran[0].y + 1 == food.NormalFood.y)
	{
		return true;
	}
	return false;
}

bool KiemTraAnQuaDacBiet(ToaDo ran[], QUA food)
{
	if (ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y)
	{
		return true;
	}
	else if (ran[0].x - 1 == food.SpecialFood.x && ran[0].y == food.SpecialFood.y)
	{
		return true;
	}
	else if (ran[0].x + 1 == food.SpecialFood.x && ran[0].y == food.SpecialFood.y)
	{
		return true;
	}
	else if (ran[0].x == food.SpecialFood.x && ran[0].y - 1 == food.SpecialFood.y)
	{
		return true;
	}
	else if (ran[0].x == food.SpecialFood.x && ran[0].y + 1 == food.SpecialFood.y)
	{
		return true;
	}
	return false;
}


//Tao qua 1
void TaoQuaThuong(QUA& food)  //  4 < xqua < 110;  3 < yqua < 35
{
	food.NormalFood.x = rand() % 95 + 10;
	food.NormalFood.y = rand() % 34 + 8;
}

//Ve qua 1
void VeQuaThuong(QUA& food)
{
	string NormalFood[3][3] = { " " };
	NormalFood[0][1] =  char(220);
	NormalFood[1][0] = NormalFood[1][2] = char(219); 
	NormalFood[1][1] = char(4);
	NormalFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.NormalFood.x + j, food.NormalFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(78);
			}
			else
			{
				TextColor(244);
			}
			cout << NormalFood[i + 1][j + 1];
		}
	}
}

//Tao qua 10
void TaoQuaDacBiet(QUA& food)  //  4 < xqua < 110;  3 < yqua < 35
{
	food.SpecialFood.x = rand() % 63 + 10;
	food.SpecialFood.y = rand() % 34 + 4;
}

void TaoQuaDacBiet1(QUA& food)  //  4 < xqua < 110;  3 < yqua < 35
{
	food.SpecialFood.x = rand() % 63 + 10;
	food.SpecialFood.y = rand() % 34 + 4;
}

//Ve qua 10
void VeQuaDacBiet(QUA& food)
{
	//Vẽ quả đặc biệt màu tím 500 điểm
	string BigFood[5][5] = { " " };
	BigFood[1][1] = char(201);
	BigFood[3][1] = char(200);
	BigFood[1][3] = char(187);
	BigFood[3][3] = char(188);

	BigFood[1][2] = char(219);
	BigFood[2][1] = char(219);
	BigFood[2][2] = char(4);
	BigFood[2][3] = char(219);
	BigFood[3][2] = char(219);

	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(222);
			}
			else
			{
				TextColor(253);
			}
			cout << BigFood[i + 2][j + 2];
		}
	}
}

void VeQuaDacBiet1(QUA& food)
{
	//vẽ quả tăng tốc
	string BigFood[3][3] = { " " };
	BigFood[0][1] = char(219);
	BigFood[0][2] = char(223);

	BigFood[1][0] = char(222);
	BigFood[1][1] = char(234);
	BigFood[1][2] = char(221);

	BigFood[2][0] = char(220);
	BigFood[2][1] = char(219);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(110);
			}
			else
			{
				TextColor(246);
			}
			cout << BigFood[i + 1][j + 1];
		}
	}
}

void VeQuaDacBiet2(QUA& food)
{
	string BigFood[5][5] = { " " };
	BigFood[1][1] = char(201);
	BigFood[3][1] = char(200);
	BigFood[1][3] = char(187);
	BigFood[3][3] = char(188);

	BigFood[1][2] = char(219);
	BigFood[2][1] = char(219);
	BigFood[2][2] = char(4);
	BigFood[2][3] = char(219);
	BigFood[3][2] = char(219);

	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(78);
			}
			else
			{
				TextColor(244);
			}
			cout << BigFood[i + 2][j + 2];
		}
	}
}

void VeQuaDacBiet3(QUA& food)
{
	string BigFood[5][5] = { " " };
	BigFood[1][1] = char(201);
	BigFood[3][1] = char(200);
	BigFood[1][3] = char(187);
	BigFood[3][3] = char(188);

	BigFood[1][2] = char(219);
	BigFood[2][1] = char(219);
	BigFood[2][2] = char(4);
	BigFood[2][3] = char(219);
	BigFood[3][2] = char(219);


	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(78);
			}
			else
			{
				TextColor(244);
			}
			cout << BigFood[i + 2][j + 2];
		}
	}
}

void VeQuaDacBiet4(QUA& food)
{
	string BigFood[5][5] = { " " };
	BigFood[1][1] = char(201);
	BigFood[3][1] = char(200);
	BigFood[1][3] = char(187);
	BigFood[3][3] = char(188);

	BigFood[1][2] = char(219);
	BigFood[2][1] = char(219);
	BigFood[2][2] = char(4);
	BigFood[2][3] = char(219);
	BigFood[3][2] = char(219);


	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(62);
			}
			else
			{
				TextColor(243);
			}
			cout << BigFood[i + 2][j + 2];
		}
	}
}

void VeQuaDacBiet5(QUA& food)
{
	string BigFood[5][5] = { " " };
	BigFood[1][1] = char(201);
	BigFood[3][1] = char(200);
	BigFood[1][3] = char(187);
	BigFood[3][3] = char(188);

	BigFood[1][2] = char(219);
	BigFood[2][1] = char(219);
	BigFood[2][2] = char(4);
	BigFood[2][3] = char(219);
	BigFood[3][2] = char(219);

	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(62);
			}
			else
			{
				TextColor(243);
			}
			cout << BigFood[i + 2][j + 2];
		}
	}
}


//Tao qua doc
void TaoQuaDoc(QUA& food)
{
	food.PoisonFood.x = rand() % 83 + 10;
	food.PoisonFood.y = rand() % 34 + 4;
}

void TaoQuaDoc1(QUA& food)
{
	food.PoisonFood.x = rand() % 83 + 10;
	food.PoisonFood.y = rand() % 34 + 4;
}

//Ve qua doc
void VeQuaDoc(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][1] = char(220);
	PoisonFood[1][0] = char(222); PoisonFood[1][2] = char(221);
	PoisonFood[1][1] = char(254);
	PoisonFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(174);
			}
			else
			{
				TextColor(242);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}

// Tao qua giam dot
void VeQuaDoc1(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][0] = char(220);
	PoisonFood[0][1] = char(220);
	PoisonFood[0][2] = char(220);

	PoisonFood[1][0] = char(222);
	PoisonFood[1][1] = char(6);
	PoisonFood[1][2] = char(221);

	PoisonFood[2][0] = char(223);
	PoisonFood[2][1] = char(223);
	PoisonFood[2][2] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if ((i == 0 && j == 0))
			{
				TextColor(43);
			}
			else
			{
				TextColor(242);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}

void VeQuaDoc2(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][1] = char(220);
	PoisonFood[1][0] = char(222); PoisonFood[1][2] = char(221);
	PoisonFood[1][1] = char(254);
	PoisonFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(174);
			}
			else
			{
				TextColor(244);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}


void VeQuaDoc3(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][1] = char(220);
	PoisonFood[1][0] = char(222); PoisonFood[1][2] = char(221);
	PoisonFood[1][1] = char(254);
	PoisonFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(174);
			}
			else
			{
				TextColor(244);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}

void VeQuaDoc4(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][1] = char(220);
	PoisonFood[1][0] = char(222); PoisonFood[1][2] = char(221);
	PoisonFood[1][1] = char(254);
	PoisonFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(174);
			}
			else
			{
				TextColor(243);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}

void VeQuaDoc5(QUA& food)
{
	string PoisonFood[3][3] = { " " };
	PoisonFood[0][1] = char(220);
	PoisonFood[1][0] = char(222); PoisonFood[1][2] = char(221);
	PoisonFood[1][1] = char(254);
	PoisonFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(174);
			}
			else
			{
				TextColor(243);
			}
			cout << PoisonFood[i + 1][j + 1];
		}
	}
}


void XoaQua(QUA food)
{
	if (food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8))
	{
		for (int i = -1; i < 2; i++)
		{
			for (int j = -1; j < 2; j++)
			{
				gotoXY(food.NormalFood.x + j, food.NormalFood.y + i);
				cout << " ";
			}
		}
	}
	else if (food.count == 5 || food.count == 10)
	{
		for (int i = -1; i < 2; i++)
		{
			for (int j = -1; j < 2; j++)
			{
				gotoXY(food.SpecialFood.x + j, food.SpecialFood.y + i);
				cout << " ";
			}
		}
		food.checkqua = false;
	}
	else if (food.count == 6 || food.count == 8)
	{
		for (int i = -1; i < 2; i++)
		{
			for (int j = -1; j < 2; j++)
			{
				gotoXY(food.PoisonFood.x + j, food.PoisonFood.y + i);
				cout << " ";
			}
		}
	}
}

//Khoi tao ran cho nguoi choi 1
void KhoiTaoRan(ToaDo ran[])
{
	ran[0].x = 7;
	ran[0].y = 15;
}

//Khoi tao ran cho nguoi choi 2
void KhoiTaoRan2(ToaDo ran[])
{
	ran[0].x = 10;
	ran[0].y = 18;
}

int  DoDaiCuaSo(int so)
{
	if (so == 0)
	{
		return 1;
	}
	int count = 0;
	while (so > 0)
	{
		so /= 10;
		count++;
	}
	return count;
}

void TaoCongWin(int x, int y, ToaDo CongWin[], int& KichThuocCongWin, char* HinhDangCong)
{
	KichThuocCongWin = 0;
	if (strcmp(HinhDangCong, "doc") == 0)
	{
		for (int i = -1; i <= 1; i++)
		{
			CongWin[KichThuocCongWin].x = x + i;
			CongWin[KichThuocCongWin].y = y;
			KichThuocCongWin++;
		}
		for (int i = 1; i < 3; i++)
		{
			CongWin[KichThuocCongWin].x = x - 1;
			CongWin[KichThuocCongWin].y = y + i;
			KichThuocCongWin++;

			CongWin[KichThuocCongWin].x = x + 1;
			CongWin[KichThuocCongWin].y = y + i;
			KichThuocCongWin++;
		}

	}
	else if (strcmp(HinhDangCong, "ngang") == 0)
	{
		for (int i = 0; i < 2; i++)
		{
			CongWin[KichThuocCongWin].x = x + i;
			CongWin[KichThuocCongWin].y = y;
			KichThuocCongWin++;

			CongWin[KichThuocCongWin].x = x + i;
			CongWin[KichThuocCongWin].y = y + 2;
			KichThuocCongWin++;
		}

		for (int i = 0; i < 3; i++)
		{
			CongWin[KichThuocCongWin].x = x + 2;
			CongWin[KichThuocCongWin].y = y + i;
			KichThuocCongWin++;
		}
	}
}

bool RanChamCongWin(ToaDo ran[], ToaDo CongWin[], int KichThuocCongWin)
{
	for (int i = 0; i < KichThuocCongWin; i++)
	{
		if (CongWin[i].x == ran[0].x && CongWin[i].y == ran[0].y)
		{
			return true;
		}
	}
	return false;
}

bool RanChamCongWin2(ToaDo ran[], ToaDo CongWin[], int KichThuocCongWin)
{
	for (int i = 0; i < KichThuocCongWin; i++)
	{
		if (CongWin[i == 0].x + 2 == ran[0].x && CongWin[i == 0].y + 1 == ran[0].y) {
			continue;
		}
		if (CongWin[i].x == ran[0].x && CongWin[i].y == ran[0].y)
		{
			return true;
		}
	}
	return false;
}

void VeCongWin(ToaDo CongWin[], int KichThuocCongWin)
{
	for (int i = 0; i < KichThuocCongWin; i++)
	{
		gotoXY(CongWin[i].x, CongWin[i].y);
		cout << char(219);
	}
}
bool RanQuaMan(ToaDo ran[], ToaDo CongWin[])
{
	return (ran[0].x == CongWin[0].x + 1 && ran[0].y == CongWin[0].y + 1);
}

bool KiemTraDieuKienThang(int diem, int diem_man)
{
	if (diem >= diem_man)
	{
		return true;
	}
	return false;
}

//FUNCTIONS FOR TWO PLAYERS
void DiXuyenQua1(ToaDo ran[], QUA food, int huong) {
	if (KiemTraAnQua(ran, food)) {
		switch (huong)
		{
		case 1:
		{
			ran->y = ran->y - 3;
			break;
		}
		case 2:
		{
			ran->y = ran->y + 3;
			break;
		}
		case 3:
		{
			ran->x = ran->x - 3;
			break;
		}
		case 4:
		{
			ran->x = ran->x + 3;
			break;
		}
		}
		VeQuaThuong(food);
	}
}

void DiXuyenQua2(ToaDo ran[], QUA food, int huong) {
	if (KiemTraAnQua(ran, food)) {
		switch (huong)
		{
		case 1:
		{
			ran->y = ran->y - 3;
			break;
		}
		case 2:
		{
			ran->y = ran->y + 3;
			break;
		}
		case 3:
		{
			ran->x = ran->x - 3;
			break;
		}
		case 4:
		{
			ran->x = ran->x + 3;
			break;
		}
		}
		VeQuaThuong2(food);
	}
}

void TaoQuaThuong2(QUA& food)  //  4 < xqua < 110;  3 < yqua < 35
{
	food.NormalFood.x = rand() % (80 - 30 + 1) + 5;
	food.NormalFood.y = rand() % (30 - 8 + 1) + 8;
}

void VeQuaThuong2(QUA& food)
{
	string NormalFood[3][3] = { " " };
	NormalFood[0][1] = char(220);
	NormalFood[1][0] = NormalFood[1][2] = char(219);
	NormalFood[1][1] = char(4);
	NormalFood[2][1] = char(223);

	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			gotoXY(food.NormalFood.x + j, food.NormalFood.y + i);
			if (i == 0 && j == 0)
			{
				TextColor(78);
			}
			else
			{
				TextColor(243);
			}
			cout << NormalFood[i + 1][j + 1];
		}
	}
}

bool RanChamNhau(ToaDo ran1[], ToaDo ran2[], int so_dot1, int so_dot2)
{ //kiem tra 2 ran cham nhau
	for (int i = 0; i < so_dot1; i++) {
		for (int j = 0; j < so_dot2; j++) {
			if (ran1[i].x == ran2[j].x && ran1[i].y == ran2[j].y) {
				return true;
			}
		}
	}
	return false;
}

void XoaRan(ToaDo ran[], int BodyRan) {
	for (int i = 0; i < BodyRan; i++) {
		gotoXY(ran[i].x, ran[i].y);
		TextColor(240); cout << " ";
	}
}

void VeCongWin2(ToaDo CongWin[], int KichThuocCongWin)
{
	for (int i = 0; i < KichThuocCongWin; i++)
	{
		gotoXY(CongWin[i].x, CongWin[i].y);
		TextColor(243);
		cout << char(219);
		TextColor(15);
	}
}

bool RanQuaMan2(ToaDo ran[], ToaDo CongWin[], int BodyRan)
{
	if (ran[0].x == CongWin[0].x + 1 && ran[0].y == CongWin[0].y + 1)
	{
		ran[0].x = CongWin[0].x + 2;
		gotoXY(CongWin[0].x + 1, CongWin[0].y + 1);
		TextColor(240); cout << " ";
		XoaRan(ran, BodyRan); //qua cong thi xoa ran
		return true;
	}
	return false;
}