﻿#pragma once 
#include <iostream>
#include <chrono>
using namespace std;

struct ToaDo
{
	int x;
	int y;
};

struct NguoiChoi
{
	char* TenNguoiChoi;
	int diem;
	int BodyRan;
	ToaDo Ran[50];
	int SPEED;
	int huong;
	int man;
	int VatCanSoO;
	char point[5];
	ToaDo VatCanDong[50];
};

struct MoveKeyBoard
{
	char MoveLeft;
	char MoveRight;
	char MoveUp;
	char MoveDown;
};

struct QUA
{
	int count;
	bool checkqua = false;
	ToaDo NormalFood{};
	ToaDo SpecialFood{};
	ToaDo PoisonFood{};
	ToaDo qua{};
};

void VeVungRanDiChuyen(int x, int y, int VungDiChuyen, int ChieuRong);
void VeBangDiem(int x, int y, int VungBangDiem, int ChieuRong, int man);
void VeVatCan(ToaDo ChuongNgaiVat[], int KichThuocVatCan);
void VeVien(int x, int y, int VungDiChuyen, int ChieuRong);
void BatSuKienMode1(int& huong, bool& checkPause, MoveKeyBoard& KeyBoardP1, bool TrungDoc);
void BatSuKienMode2(int& huong, bool& checkPause, MoveKeyBoard& KeyBoardP1);
void BatSuKienMode3(int& huong1, int& huong2, bool& checkPause, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, bool TrungDoc1, bool TrungDoc2);
ToaDo DiChuyen(ToaDo ran[], int huong, int BodyRan);
void HienThiRan(ToaDo ran[], ToaDo dot_cuoi_cu, int BodyRan);
void HienThiRan2(ToaDo ran[], ToaDo dot_cuoi_cu, int BodyRan);
void VeRan(ToaDo ran[], int BodyRan);
bool RanChamThan(ToaDo ran[], int BodyRan);
bool RanChamTuong(ToaDo ran[]);
bool KiemTraToaDoQuaKhaThi(int x, int y, ToaDo ChuongNgaiVat[], int KichThuocVatCan);
bool KiemTraAnQua(ToaDo ran[], QUA food);
bool KiemTraAnQuaDacBiet(ToaDo ran[], QUA food);
void TaoQuaThuong(QUA& food);
void VeQuaThuong(QUA& food);
void VeQuaThuong2(QUA& food);
void TaoQuaThuong2(QUA& food);  //  4 < xqua < 110;  3 < yqua < 35
void TaoQuaDacBiet(QUA& food);
void TaoQuaDacBiet1(QUA& food);
void VeQuaDacBiet(QUA& food);
void VeQuaDacBiet1(QUA& food);
void VeQuaDacBiet2(QUA& food);
void VeQuaDacBiet3(QUA& food);
void VeQuaDacBiet4(QUA& food);
void VeQuaDacBiet5(QUA& food);
void TaoQuaDoc(QUA& food);
void TaoQuaDoc1(QUA& food);
void VeQuaDoc(QUA& food);
void VeQuaDoc1(QUA& food);
void VeQuaDoc2(QUA& food);
void VeQuaDoc3(QUA& food);
void VeQuaDoc4(QUA& food);
void VeQuaDoc5(QUA& food);
void XoaQua(QUA food);
void DiXuyenQua1(ToaDo ran[], QUA food, int huong);
void DiXuyenQua2(ToaDo ran[], QUA food, int huong);
bool RanChamNhau(ToaDo ran1[], ToaDo ran2[], int so_dot1, int so_dot2);
bool CapNhatDiem(int& diemtmp, int& diem);
void VeDiem(int x, int y, int ChieuRong, int& diem, bool checkPause, bool IsLose);
void VeDiemMode4(int x, int y, int ChieuRong, int& diem, int& diem2, bool checkPause, bool IsLose);
void KhoiTaoRan(ToaDo ran[]);
void KhoiTaoRan2(ToaDo ran[]);
void VeManChoi(int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, ToaDo ChuongNgaiVat[], int KichThuocVatCan, int man);
int  DoDaiCuaSo(int so);
void TaoCongWin(int x, int y, ToaDo CongWin[], int& KichThuocCongWin, char* HinhDangCong);
void VeCongWin(ToaDo CongWin[], int KichThuocCongWin);
void VeCongWin2(ToaDo CongWin[], int KichThuocCongWin);
bool RanChamCongWin(ToaDo ran[], ToaDo CongWin[], int KichThuocCongWin);
bool RanChamCongWin2(ToaDo ran[], ToaDo CongWin[], int KichThuocCongWin);
bool RanQuaMan(ToaDo ran[], ToaDo CongWin[]);
bool RanQuaMan2(ToaDo ran[], ToaDo CongWin[], int BodyRan);
bool KiemTraDieuKienThang(int diem, int diem_man);
void Nut_Return(int x, int y, int VungBangDiem, int ChieuRong, int man);
void Nut_Option(int x, int y, int VungBangDiem, int ChieuRong, int man);
void Nut_Guide(int x, int y, int VungBangDiem, int ChieuRong, int man);