﻿#include "c_music.h"
#include "c_Map1Mode3.h"
#include "c_Map2Mode2.h"
#include "c_mylib.h"
#include "c_snake.h"
#include "c_scoreboard.h"
#include "c_menu.h"

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110


void AnQuaThuongMapMode4(ToaDo ran[], QUA & food, QUA & A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int & diem2, int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, int soundEF, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>&startTime, double& elapsedTime1, chrono::time_point<std::chrono::high_resolution_clock>&startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>&startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>&startTime3)
{

	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}
	auto currentTime = std::chrono::high_resolution_clock::now();
	chrono::duration<double> duration = currentTime - startTime;
	elapsedTime = duration.count();

	chrono::duration<double> duration1 = currentTime - startTime1;
	elapsedTime1 = duration1.count();

	chrono::duration<double> duration2 = currentTime - startTime2;
	elapsedTime2 = duration2.count();

	chrono::duration<double> duration3 = currentTime - startTime3;
	elapsedTime3 = duration3.count();
	if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);
		ran_dot++;
		diem += 1;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 8) {
			do
			{
				TaoQuaDoc(A);
			} while (A.PoisonFood.x == 38 || A.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.PoisonFood.x, A.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc3(A);
			A.count = 8;

		}
		else if (food.count == 10) {
			do
			{
				TaoQuaDacBiet(A);
			} while (A.SpecialFood.x == 38 || A.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet3(A);
			A.count = 10;

		}
	}
	else if (food.count == 5 && KiemTraAnQuaDacBiet(ran, food) && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 5;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		ran_dot++;
		diem += 1;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6)))
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}

	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if ((food.count == 6) && ran[0].x == food.PoisonFood.x && ran[0].y == food.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		startTime1 = chrono::high_resolution_clock::now();
		XoaQua(food);
		TrungDoc = 1;
		diem -= 2;
		SPEED -= 2;
		food.count++;


		ThayDiem = CapNhatDiem(diemtmp, diem);
		VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (elapsedTime1 >= 5 && TrungDoc == 1) {
		TrungDoc = 0;
		elapsedTime1 = 0.0;
	}
	else if (elapsedTime3 >= 7 && SPEED % 2 != 0) {
		SPEED = temp1;
		elapsedTime3 = 0.0;
	}
	else if (food.count == 6 && elapsedTime2 >= 10) {
		XoaQua(food);
		elapsedTime2 = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if ((A.count == 8) && ran[0].x == A.PoisonFood.x && ran[0].y == A.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		XoaQua(A);
		diem -= 200;
		gotoXY(ran[ran_dot - 4].x, ran[ran_dot - 4].y); cout << " ";
		gotoXY(ran[ran_dot - 3].x, ran[ran_dot - 3].y); cout << " ";
		gotoXY(ran[ran_dot - 2].x, ran[ran_dot - 2].y); cout << " ";
		gotoXY(ran[ran_dot - 1].x, ran[ran_dot - 1].y); cout << " ";
		ran_dot -= 4;
		SPEED -= 2;
		A.count = 0;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (food.count == 10 && KiemTraAnQuaDacBiet(ran, A)) // tắng tốc
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(A);
		ran_dot++;
		startTime3 = chrono::high_resolution_clock::now();
		if (SPEED > 51)
			SPEED = 51;
		food.count = 0;
		A.count = 0;

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet2(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc2(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
}

void AnQua2ThuongMapMode4(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int& diem2, int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, int soundEF, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime, double& elapsedTime1, chrono::time_point<std::chrono::high_resolution_clock>& startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>& startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>& startTime3)
{

	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}
	auto currentTime = std::chrono::high_resolution_clock::now();
	chrono::duration<double> duration = currentTime - startTime;
	elapsedTime = duration.count();

	chrono::duration<double> duration1 = currentTime - startTime1;
	elapsedTime1 = duration1.count();

	chrono::duration<double> duration2 = currentTime - startTime2;
	elapsedTime2 = duration2.count();

	chrono::duration<double> duration3 = currentTime - startTime3;
	elapsedTime3 = duration3.count();
	if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);
		ran_dot++;
		diem2 += 1;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem2);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 8) {
			do
			{
				TaoQuaDoc1(A);
			} while (A.PoisonFood.x == 38 || A.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.PoisonFood.x, A.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc5(A);
			A.count = 8;

		}
		else if (food.count == 10) {
			do
			{
				TaoQuaDacBiet1(A);
			} while (A.SpecialFood.x == 38 || A.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet5(A);
			A.count = 10;

		}
	}
	else if (food.count == 5 && KiemTraAnQuaDacBiet(ran, food) && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem2 += 5;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem2);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		ran_dot++;
		diem2 += 1;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem2);
		if (ThayDiem == true)
		{
			VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6)))
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}

	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
	else if ((food.count == 6) && ran[0].x == food.PoisonFood.x && ran[0].y == food.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		startTime1 = chrono::high_resolution_clock::now();
		XoaQua(food);
		TrungDoc = 1;
		diem2 -= 2;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem2);
		VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
	else if (elapsedTime1 >= 5 && TrungDoc == 1) {
		TrungDoc = 0;
		elapsedTime1 = 0.0;
	}
	else if (elapsedTime3 >= 7 && SPEED % 2 != 0) {
		SPEED = temp1;
		elapsedTime3 = 0.0;
	}
	else if (food.count == 6 && elapsedTime2 >= 10) {
		XoaQua(food);
		elapsedTime2 = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
	else if ((A.count == 8) && ran[0].x == A.PoisonFood.x && ran[0].y == A.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		XoaQua(A);
		diem -= 2;
		gotoXY(ran[ran_dot - 4].x, ran[ran_dot - 4].y); cout << " ";
		gotoXY(ran[ran_dot - 3].x, ran[ran_dot - 3].y); cout << " ";
		gotoXY(ran[ran_dot - 2].x, ran[ran_dot - 2].y); cout << " ";
		gotoXY(ran[ran_dot - 1].x, ran[ran_dot - 1].y); cout << " ";
		ran_dot -= 4;
		SPEED -= 2;
		A.count = 0;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem2);
		VeDiemMode4(x, y, ChieuRong, diem, diem2, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
	else if (food.count == 10 && KiemTraAnQuaDacBiet(ran, A)) // tắng tốc
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(A);
		ran_dot++;
		startTime3 = chrono::high_resolution_clock::now();
		if (SPEED > 51)
			SPEED = 51;
		food.count = 0;
		A.count = 0;

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet1(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet4(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong2(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc1(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc4(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong2(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong2(A);
				A.checkqua = true;
			}
		}
	}
}


//Ki?m tra thua màn 1
bool KiemTraThuaManMode4(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan)
{
	if (RanChamThan(ran, ran_dot))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	return false;
}

void ManMode4(char* ten_nguoi_choi1, char* ten_nguoi_choi2, ToaDo ran1[], ToaDo ran2[], int& BodyRan1, int& BodyRan2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem1, int& diem2, int& SPEED, int& huong1, int& huong2, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode)
{
	HuongDanChoi(x, y, VungDiChuyen, ChieuRong, KeyBoardP1, KeyBoardP2);
	system("cls");

	char huong_vao_cong[] = "len";
	int temp = SPEED;
	int temp1 = SPEED;
	int temp2 = SPEED;
	SPEED = temp;

	QUA food1;
	QUA food2;
	QUA A1;
	QUA A2;

	food1.count = 0;//Số lượng quả
	food2.count = 0;

	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man); //Hàm vẽ màn 1

	bool checkPause = false;
	int diemTam = diem1;

	int ran_dot_Tam1 = BodyRan1;
	int ran_dot_Tam2 = BodyRan2;

	ToaDo ranTam1[100];
	ToaDo ranTam2[100];

	for (int i = 0; i < 100; i++)
	{
		ranTam1[i] = ran1[i];
		ranTam2[i] = ran2[i];
	}

	int huongTemp1 = huong1;
	int huongTemp2 = huong2;
	bool isLose = false;
	bool TrungDoc1 = 0;
	bool TrungDoc2 = 0;

	TaoQuaThuong(food1);//Tao qua dau tiên
	VeQuaThuong(food1);

	TaoQuaThuong2(food2);//Tao qua thu hai
	VeQuaThuong2(food2);

	VeRan(ran1, BodyRan1);
	VeRan(ran2, BodyRan2);

	VeDiemMode4(x, y, ChieuRong, diem1, diem2, checkPause, isLose);

	ToaDo CongWin[7];
	ToaDo cong_win2[7];
	int cong_win_so_o = 0; //so o tao thanh 1 cong win

	bool snake1IsLive = true; //kiem tra ran qua cong chua
	bool snake2IsLive = true;

	bool win = KiemTraDieuKienThang(diem1, 200 * man);
	int option = 0;

	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime1;
	double elapsedTime1 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime2;
	double elapsedTime2 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime3;
	double elapsedTime3 = 0.0;

	chrono::time_point<std::chrono::high_resolution_clock> startTime4;
	double elapsedTime4 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime5;
	double elapsedTime5 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime6;
	double elapsedTime6 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime7;
	double elapsedTime7 = 0.0;
	while (1)
	{
		int huongTam1 = huong1;
		int huongTam2 = huong2;

		noCursorType();
		BatSuKienMode3(huong1, huong2, checkPause, KeyBoardP1, KeyBoardP2, TrungDoc1, TrungDoc2);

		DiXuyenQua2(ran1, food2, huong1); //ran1 di xuyen qua qua 2
		DiXuyenQua1(ran2, food1, huong2); //ran2 di xuyen qua qua 1

		if (snake1IsLive) {
			ToaDo dot_cuoi_cu = DiChuyen(ran1, huong1, BodyRan1);
			HienThiRan(ran1, dot_cuoi_cu, BodyRan1);
		}

		if (snake2IsLive) {
			ToaDo dot_cuoi_cu2 = DiChuyen(ran2, huong2, BodyRan2);
			HienThiRan2(ran2, dot_cuoi_cu2, BodyRan2);
		}
		Sleep(SPEED);//Tốc độ rắn = 150
		AnQuaThuongMapMode4(ran1, food1, A1, BodyRan1, temp1, TrungDoc1, SPEED, huong1,diem1, diem2, x, y, ChieuRong, VatCan, KichThuocVatCan, CongWin, cong_win_so_o, soundIG, soundEF, checkPause, isLose, elapsedTime, startTime, elapsedTime1, startTime1, elapsedTime2, startTime2, elapsedTime3, startTime3);//Ki?m tra ?n qu?
		AnQua2ThuongMapMode4(ran2, food2, A2, BodyRan2, temp2, TrungDoc2, SPEED, huong2, diem1, diem2, x, y, ChieuRong, VatCan, KichThuocVatCan, cong_win2, cong_win_so_o, soundIG, soundEF, checkPause, isLose, elapsedTime4, startTime4, elapsedTime5, startTime5, elapsedTime6, startTime6, elapsedTime7, startTime7);//Ki?m tra ?n qu?

		if (KiemTraThuaManMode4(ran1, BodyRan1, VatCan, KichThuocVatCan) || KiemTraThuaManMode4(ran2, BodyRan2, VatCan, KichThuocVatCan) || RanChamNhau(ran1, ran2, BodyRan1, BodyRan2) || (win && RanChamCongWin2(ran1, CongWin, cong_win_so_o)) || (win && RanChamCongWin2(ran2, CongWin, cong_win_so_o)) || (win && RanChamCongWin2(ran1, cong_win2, cong_win_so_o)) || (win && RanChamCongWin2(ran2, cong_win2, cong_win_so_o)) || RanQuaMan(ran1, cong_win2) || RanQuaMan(ran2, CongWin))//Hàm ki?m tra thua
		{
			int whoWin = MAXINT; // 0: Player 1 wins, 1: Player 2 wins, 2: Draw
			if (RanChamNhau(ran1, ran2, BodyRan1, BodyRan2))
			{
				if (diem1 > diem2)
				{
					whoWin = 0;
				}
				else if (diem2 > diem1)
				{
					whoWin = 1;
				}
				else if (diem1 == diem2)
				{
					whoWin = 2;
				}
			}
			if (KiemTraThuaManMode4(ran1, BodyRan1, VatCan, KichThuocVatCan))
			{
				whoWin = 1;
			}
			else if (KiemTraThuaManMode4(ran2, BodyRan2, VatCan, KichThuocVatCan))
			{
				whoWin = 0;
			}

			isLose = true;
			playMusicGame(soundIG, isLose);
			isLose = false;
			playLoseSound(soundIG, isLose);
			system("cls");
			int choice = MenuGameOverMode4(soundIG, soundEF, KeyBoardP1, KeyBoardP2, diem1, diem2, whoWin);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				diem1 = 0;
				diem2 = 0;
				SPEED = temp;
				food1.count = 0;
				food2.count = 0;
				A1.count = 0;
				A2.count = 0;
				while (food1.count <= 10) {
					XoaQua(food1);
					XoaQua(A1);
					food1.count++;
				}
				while (food2.count <= 10) {
					XoaQua(food2);
					XoaQua(A2);
					food2.count++;
				}
				food2.count = 0;
				food1.count = 0;
				BodyRan1 = ran_dot_Tam1;
				BodyRan2 = ran_dot_Tam2;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiemMode4(x, y, ChieuRong, diem1, diem2, checkPause, isLose);
				for (int i = 0; i < 100; i++)
				{
					ran1[i] = ranTam1[i];
					ran2[i] = ranTam2[i];
				}
				huong1 = huongTemp1;
				huong2 = huongTemp2;
				TaoQuaThuong(food1);
				VeQuaThuong(food1);
				TaoQuaThuong2(food2);
				VeQuaThuong2(food2);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiemMode4(x, y, ChieuRong, diem1, diem2, checkPause, isLose);
				if ((food1.count < 5 || (food1.count < 10 && food1.count > 6 && food1.count != 8)) && A1.checkqua == false)
				{
					VeQuaThuong(food1);
				}
				else if (food1.count == 5)
				{
					VeQuaDacBiet2(food1);
					if (A1.checkqua == true)
						VeQuaThuong(A1);
				}
				else if (food1.count == 6)
				{
					VeQuaDoc2(food1);
					if (A1.checkqua == true)
						VeQuaThuong(A1);
				}
				else if (food1.count == 8)
				{
					VeQuaDoc3(A1);
				}
				else if (food1.count == 10)
				{
					VeQuaDacBiet3(A1);
				}
				else if (A1.checkqua == true) {
					VeQuaThuong(A1);
				}

				if ((food2.count < 5 || (food2.count < 10 && food2.count > 6 && food2.count != 8)) && A2.checkqua == false)
				{
					VeQuaThuong2(food2);
				}
				else if (food2.count == 5)
				{
					VeQuaDacBiet4(food2);
					if (A2.checkqua == true)
						VeQuaThuong2(A2);
				}
				else if (food2.count == 6)
				{
					VeQuaDoc4(food2);
					if (A2.checkqua == true)
						VeQuaThuong2(A2);
				}
				else if (food2.count == 8)
				{
					VeQuaDoc5(A2);
				}
				else if (food2.count == 10)
				{
					VeQuaDacBiet5(A2);
				}
				else if (A2.checkqua == true) {
					VeQuaThuong2(A2);
				}
			}
			if (pause == 2)
			{
				option = MenuOption2(x, y, VungDiChuyen, ChieuRong, checkPause, KeyBoardP1, KeyBoardP2, soundIG, soundEF, ten_nguoi_choi1, ten_nguoi_choi2, diem1, diem2, BodyRan1, ran1, BodyRan2, ran2, SPEED, huong1, huong2, man, 0, VatCan,
					data, nData, nguoiChoi1, nguoiChoi2, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem1, checkPause, isLose);
					if ((food1.count < 5 || (food1.count < 10 && food1.count > 6 && food1.count != 8)) && A1.checkqua == false)
					{
						VeQuaThuong(food1);
					}
					else if (food1.count == 5)
					{
						VeQuaDacBiet2(food1);
						if (A1.checkqua == true)
							VeQuaThuong(A1);
					}
					else if (food1.count == 6)
					{
						VeQuaDoc2(food1);
						if (A1.checkqua == true)
							VeQuaThuong(A1);
					}
					else if (food1.count == 8)
					{
						VeQuaDoc3(A1);
					}
					else if (food1.count == 10)
					{
						VeQuaDacBiet3(A1);
					}
					else if (A1.checkqua == true) {
						VeQuaThuong(A1);
					}

					if ((food2.count < 5 || (food2.count < 10 && food2.count > 6 && food2.count != 8)) && A2.checkqua == false)
					{
						VeQuaThuong2(food2);
					}
					else if (food2.count == 5)
					{
						VeQuaDacBiet4(food2);
						if (A2.checkqua == true)
							VeQuaThuong2(A2);
					}
					else if (food2.count == 6)
					{
						VeQuaDoc4(food2);
						if (A2.checkqua == true)
							VeQuaThuong2(A2);
					}
					else if (food2.count == 8)
					{
						VeQuaDoc5(A2);
					}
					else if (food2.count == 10)
					{
						VeQuaDacBiet5(A2);
					}
					else if (A2.checkqua == true) {
						VeQuaThuong2(A2);
					}
				}
				if (option == 2)
				{
					system("cls");
					diem1 = 0;
					diem2 = 0;
					SPEED = temp;
					food1.count = 0;
					food2.count = 0;
					A1.count = 0;
					A2.count = 0;
					while (food1.count <= 10) {
						XoaQua(food1);
						XoaQua(A1);
						food1.count++;
					}
					while (food2.count <= 10) {
						XoaQua(food2);
						XoaQua(A2);
						food2.count++;
					}
					food2.count = 0;
					food1.count = 0;
					BodyRan1 = ran_dot_Tam1;
					BodyRan2 = ran_dot_Tam2;
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiemMode4(x, y, ChieuRong, diem1, diem2, checkPause, isLose);
					for (int i = 0; i < 100; i++)
					{
						ran1[i] = ranTam1[i];
						ran2[i] = ranTam2[i];
					}
					huong1 = huongTemp1;
					huong2 = huongTemp2;
					TaoQuaThuong(food1);
					VeQuaThuong(food1);
					TaoQuaThuong2(food2);
					VeQuaThuong2(food2);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, KeyBoardP1, KeyBoardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem1, checkPause, isLose);
				if ((food1.count < 5 || (food1.count < 10 && food1.count > 6 && food1.count != 8)) && A1.checkqua == false)
				{
					VeQuaThuong(food1);
				}
				else if (food1.count == 5)
				{
					VeQuaDacBiet2(food1);
					if (A1.checkqua == true)
						VeQuaThuong(A1);
				}
				else if (food1.count == 6)
				{
					VeQuaDoc2(food1);
					if (A1.checkqua == true)
						VeQuaThuong(A1);
				}
				else if (food1.count == 8)
				{
					VeQuaDoc3(A1);
				}
				else if (food1.count == 10)
				{
					VeQuaDacBiet3(A1);
				}
				else if (A1.checkqua == true) {
					VeQuaThuong(A1);
				}

				if ((food2.count < 5 || (food2.count < 10 && food2.count > 6 && food2.count != 8)) && A2.checkqua == false)
				{
					VeQuaThuong2(food2);
				}
				else if (food2.count == 5)
				{
					VeQuaDacBiet4(food2);
					if (A2.checkqua == true)
						VeQuaThuong2(A2);
				}
				else if (food2.count == 6)
				{
					VeQuaDoc4(food2);
					if (A2.checkqua == true)
						VeQuaThuong2(A2);
				}
				else if (food2.count == 8)
				{
					VeQuaDoc5(A2);
				}
				else if (food2.count == 10)
				{
					VeQuaDacBiet5(A2);
				}
				else if (A2.checkqua == true) {
					VeQuaThuong2(A2);
				}
			}
			checkPause = false;
			startTime = chrono::high_resolution_clock::now();
			startTime1 = chrono::high_resolution_clock::now();
			startTime2 = chrono::high_resolution_clock::now();
			startTime3 = chrono::high_resolution_clock::now();
			startTime4 = chrono::high_resolution_clock::now();
			startTime5 = chrono::high_resolution_clock::now();
			startTime6 = chrono::high_resolution_clock::now();
			startTime7 = chrono::high_resolution_clock::now();

		}
		playMusicGame(soundIG, isLose);
	}
}