﻿#include "c_music.h"
#include "c_MapMode1.h"
#include "c_Map2Mode2.h"
#include "c_mylib.h"
#include "c_snake.h"
#include "c_scoreboard.h"
#include "c_menu.h"

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110
void AnQuaMode1(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime, double& elapsedTime1, chrono::time_point<std::chrono::high_resolution_clock>& startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>& startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>& startTime3)
{
	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}

	auto currentTime = std::chrono::high_resolution_clock::now();
	chrono::duration<double> duration = currentTime - startTime;
	elapsedTime = duration.count();

	chrono::duration<double> duration1 = currentTime - startTime1;
	elapsedTime1 = duration1.count();

	chrono::duration<double> duration2 = currentTime - startTime2;
	elapsedTime2 = duration2.count();

	chrono::duration<double> duration3 = currentTime - startTime3;
	elapsedTime3 = duration3.count();

	if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);
		ran_dot++;
		diem += 100;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 8) {
			do
			{
				TaoQuaDoc(A);
			} while (A.PoisonFood.x == 38 || A.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.PoisonFood.x, A.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc1(A);
			A.count = 8;

		}
		else if (food.count == 10) {
			do
			{
				TaoQuaDacBiet(A);
			} while (A.SpecialFood.x == 38 || A.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.SpecialFood.x, A.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet1(A);
			A.count = 10;

		}
	}
	else if (food.count == 5 && KiemTraAnQuaDacBiet(ran, food) && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		ran_dot++;
		diem += 100;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if ((food.count < 5 || (food.count < 10 && food.count > 6)))
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}

	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if ((food.count == 6) && ran[0].x == food.PoisonFood.x && ran[0].y == food.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		startTime1 = chrono::high_resolution_clock::now();
		XoaQua(food);
		TrungDoc = 1;
		diem -= 200;
		SPEED -= 2;
		food.count++;



		ThayDiem = CapNhatDiem(diemtmp, diem);
		VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (elapsedTime1 >= 5 && TrungDoc == 1) {
		TrungDoc = 0;
		elapsedTime1 = 0.0;
	}
	else if (elapsedTime3 >= 7 && SPEED % 2 != 0) {
		SPEED = temp1;
		elapsedTime3 = 0.0;
	}
	else if (food.count == 6 && elapsedTime2 >= 10) {
		XoaQua(food);
		elapsedTime2 = 0.0;
		food.count++;
		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if ((A.count == 8) && ran[0].x == A.PoisonFood.x && ran[0].y == A.PoisonFood.y)
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}
		XoaQua(A);
		diem -= 200;
		gotoXY(ran[ran_dot - 4].x, ran[ran_dot - 4].y); cout << " ";
		gotoXY(ran[ran_dot - 3].x, ran[ran_dot - 3].y); cout << " ";
		gotoXY(ran[ran_dot - 2].x, ran[ran_dot - 2].y); cout << " ";
		gotoXY(ran[ran_dot - 1].x, ran[ran_dot - 1].y); cout << " ";
		ran_dot -= 4;
		SPEED -= 2;
		A.count = 0;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false) {
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}
	else if (food.count == 10 && KiemTraAnQuaDacBiet(ran, A)) // tắng tốc
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(A);
		ran_dot++;
		startTime3 = chrono::high_resolution_clock::now();
		if (SPEED > 51)
			SPEED = 51;
		food.count = 0;
		A.count = 0;

		if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
			startTime2 = chrono::high_resolution_clock::now();
			if (A.checkqua == false)
			{
				do
				{
					TaoQuaThuong(A);
				} while ((A.NormalFood.x == food.PoisonFood.x && A.NormalFood.y == food.PoisonFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
				VeQuaThuong(A);
				A.checkqua = true;
			}
		}
	}

}

void ManMode1(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& exitgame, int mode)
{
	HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
	system("cls");

	char huong_vao_cong[] = "len";
	int temp = SPEED;
	int temp1 = SPEED;
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man); //Hàm vẽ màn 1
	SPEED = temp;

	QUA food;
	QUA A;
	food.count = 0;//Số lượng quả

	bool checkPause = false;
	int ran_dot_Tam = ran_dot;
	ToaDo ranTam[100];
	for (int i = 0; i < 100; i++)  ranTam[i] = ran[i];
	int huongTemp = huong;
	bool isLose = false;
	bool TrungDoc = 0;

	TaoQuaThuong(food);//T?o qu? ??u tiên
	VeQuaThuong(food);
	VeRan(ran, ran_dot);
	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	ToaDo CongWin[7];
	int cong_win_so_o = 0; //s? ô t?o thành 1 c?ng win

	bool win = KiemTraDieuKienThang(diem, 200 * man);

	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime1;
	double elapsedTime1 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime2;
	double elapsedTime2 = 0.0;
	chrono::time_point<std::chrono::high_resolution_clock> startTime3;
	double elapsedTime3 = 0.0;
	int option;
	int dot = ran_dot;
	while (1)
	{
		int huongTam = huong;
		noCursorType();
		BatSuKienMode1(huong, checkPause, keyboard, TrungDoc);
		ToaDo dot_cuoi_cu = DiChuyen(ran, huong, ran_dot);
		HienThiRan(ran, dot_cuoi_cu, ran_dot);
		Sleep(SPEED);//Tốc độ rắn = 150
		AnQuaMode1(ran, food, A, ran_dot, temp1, TrungDoc, SPEED, huong, diem, x, y, ChieuRong, VatCan, KichThuocVatCan, CongWin, cong_win_so_o, soundIG, checkPause, isLose, elapsedTime, startTime, elapsedTime1, startTime1, elapsedTime2, startTime2, elapsedTime3, startTime3);
		if (KiemTraThuaMan1(ran, ran_dot, VatCan, KichThuocVatCan) || (win && RanChamCongWin(ran, CongWin, cong_win_so_o)))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			XoaFileText(data, nData, TrangThai);
			int choice = MenuGameOver(soundIG, soundEF, keyboard, keyboardP2, diem, ten_nguoi_choi, data, nData, nguoiChoi, TrangThai, mode);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				SPEED = temp;
				diem = 0;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				food.count = 0;
				ran_dot = ran_dot_Tam;
				for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
				huong = huongTemp;
				TaoQuaThuong(food);
				VeQuaThuong(food);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
				{
					VeQuaThuong(food);
				}
				else if (food.count == 5)
				{
					VeQuaDacBiet(food);
					if (A.checkqua == true)
						VeQuaThuong(A);
				}
				else if (food.count == 6)
				{
					VeQuaDoc(food);
					if (A.checkqua == true)
						VeQuaThuong(A);
				}
				else if (food.count == 8)
				{
					VeQuaDoc(A);
				}
				else if (food.count == 10)
				{
					VeQuaDacBiet(A);
				}
				else if (A.checkqua == true) {
					VeQuaThuong(A);
				}
			}
			if (pause == 2)
			{
				option = MenuOption(x, y, VungDiChuyen, ChieuRong, checkPause, keyboard, keyboardP2, soundIG, soundEF, ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, 0, VatCan,
					data, nData, nguoiChoi, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food.count < 6)
					{
						VeQuaThuong(food);
					}
					else
					{
						VeQuaDacBiet(food);
					}
				}
				if (option == 2)
				{
					system("cls");
					diem = 0;
					SPEED = temp;
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					food.count = 0;
					A.count = 0;
					// xoa het tat ca vi tri qua con sot lai trong man choi
					while (food.count <= 10) {
						XoaQua(food);
						XoaQua(A);
						food.count++;
					}
					food.count = 0;
					ran_dot = ran_dot_Tam;
					for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
					huong = huongTemp;
					TaoQuaThuong(food);
					VeQuaThuong(food);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if ((food.count < 5 || (food.count < 10 && food.count > 6 && food.count != 8)) && A.checkqua == false)
				{
					VeQuaThuong(food);
				}
				else if (food.count == 5)
				{
					VeQuaDacBiet(food);
					if (A.checkqua == true)
						VeQuaThuong(A);
				}
				else if (food.count == 6)
				{
					VeQuaDoc(food);
					if (A.checkqua == true)
						VeQuaThuong(A);
				}
				else if (food.count == 8)
				{
					VeQuaDoc(A);
				}
				else if (food.count == 10)
				{
					VeQuaDacBiet(A);
				}
				else if (A.checkqua == true) {
					VeQuaThuong(A);
				}
			}
			checkPause = false;
			startTime = chrono::high_resolution_clock::now();
			startTime1 = chrono::high_resolution_clock::now();
			startTime2 = chrono::high_resolution_clock::now();
			startTime3 = chrono::high_resolution_clock::now();
		}
		playMusicGame(soundIG, isLose);
	}
}