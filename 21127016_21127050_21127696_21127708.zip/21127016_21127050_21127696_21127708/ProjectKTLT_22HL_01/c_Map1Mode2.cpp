﻿#include "c_music.h"
#include "c_Map1Mode2.h"
#include "c_Map2Mode2.h"
#include "c_mylib.h"
#include "c_snake.h"
#include "c_scoreboard.h"
#include "c_menu.h"

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110

void AnQuaThuongMode2(ToaDo ran[], QUA& food, QUA& A, int& BodyRan, int& SPEED, int& diem, int x, int y, int ChieuRong,
	ToaDo ChuongNgaiVat[], int KichThuocVatCan, ToaDo CongWin[], int KichThuocCongWin, int soundIG, int soundEF, bool checkPause,
	bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime) 
{
	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}

	if (food.checkqua == true)
	{
		auto currentTime = std::chrono::high_resolution_clock::now();
		chrono::duration<double> duration = currentTime - startTime;
		elapsedTime = duration.count();
	}
	if (food.count < 5 && KiemTraAnQua(ran, food) == true)
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);
		BodyRan++;
		diem += 100;
		SPEED -= 2;
		food.count++;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} 
			while (ran[0].x == food.NormalFood.x && ran[0].y == food.NormalFood.y || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, KichThuocCongWin));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} 
			while (ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, KichThuocCongWin));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} 
			while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, KichThuocCongWin));
			VeQuaThuong(A);
			A.checkqua = true;
		}
	}
	else if (food.count == 5 && KiemTraAnQuaDacBiet(ran, food) && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		BodyRan++;
		diem += 500;
		SPEED -= 2;
		food.count = 0;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} 
			while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, KichThuocCongWin));
			VeQuaThuong(food);
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		BodyRan++;
		diem += 100;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count != 5)
		{
			do
			{
				TaoQuaThuong(food);
			}
			while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, KichThuocCongWin));
			VeQuaThuong(food);
		}
	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count = 0;
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			}
			while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, BodyRan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, KichThuocCongWin));
			VeQuaThuong(food);
		}
	}
}

void TaoChuongNgaiVatMan1(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo ChuongNgaiVat[], int& KichThuocVatCan)
{
	for (int i = x + 20; i <= x + VungDiChuyen - 20; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 12;
		KichThuocVatCan++;

		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 13;
		KichThuocVatCan++;
	}

	for (int i = x + 1; i <= x + VungDiChuyen - 65; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 24;
		KichThuocVatCan++;

		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 25;
		KichThuocVatCan++;
	}

	for (int i = x + VungDiChuyen - 32; i <= x + VungDiChuyen - 1; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 24;
		KichThuocVatCan++;

		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 25;
		KichThuocVatCan++;
	}

	for (int i = x + 20; i <= x + VungDiChuyen - 20; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 36;
		KichThuocVatCan++;

		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 37;
		KichThuocVatCan++;
	}
}

bool KiemTraThuaVatCan1(ToaDo ran[], ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (ran[0].x == ChuongNgaiVat[i].x && ran[0].y == ChuongNgaiVat[i].y)
		{
			return true;
		}
	}
	return false;
}

//Ki?m tra thua màn 2
bool KiemTraThuaMan1(ToaDo ran[], int BodyRan, ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	if (RanChamThan(ran, BodyRan))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	if (KiemTraThuaVatCan1(ran, ChuongNgaiVat, KichThuocVatCan))
	{
		return true;
	}
	return false;
}

void Man1Mode2(char* TenNguoiChoi, ToaDo ran[], int& BodyRan, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem,   int& SPEED, int& huong, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode)
{
	HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
	system("cls");

	char HinhDangCong[] = "doc";
	int temp = SPEED;
	TaoChuongNgaiVatMan1(x, y, VungDiChuyen, ChieuRong, ChuongNgaiVat, KichThuocVatCan);
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man); //Hàm vẽ màn 1
	SPEED = temp;

	QUA food;
	QUA A;
	food.count = 0;//Số lượng quả
	A.checkqua = false;

	bool checkPause = false;
	int diemTam = diem;
	int BodyRanTemp = BodyRan;
	ToaDo ranTam[100];
	for (int i = 0; i < 100; i++)  ranTam[i] = ran[i];
	int huongTemp = huong;
	bool isLose = false;

	TaoQuaThuong(food);
	VeQuaThuong(food);  
	VeRan(ran, BodyRan);
	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	ToaDo CongWin[7];
	int KichThuocCongWin = 0;

	bool win = KiemTraDieuKienThang(diem, 1 * man);
	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	int option;
	while (1)
	{
		int huongTam = huong;
		noCursorType();
		BatSuKienMode2(huong, checkPause, keyboard);
		ToaDo dot_cuoi_cu = DiChuyen(ran, huong, BodyRan);
		HienThiRan(ran, dot_cuoi_cu, BodyRan);
		Sleep(SPEED);
		if (!win) {
			AnQuaThuongMode2(ran, food, A, BodyRan, SPEED, diem,  x, y, ChieuRong, ChuongNgaiVat, KichThuocVatCan, CongWin, KichThuocCongWin, soundIG, soundEF, checkPause, isLose, elapsedTime, startTime);//Ki?m tra ?n qu?

		}
		if (KiemTraThuaMan1(ran, BodyRan, ChuongNgaiVat, KichThuocVatCan) || (win && RanChamCongWin(ran, CongWin, KichThuocCongWin)))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			XoaFileText(data, nData, TrangThai);
			int choice = MenuGameOver(soundIG, soundEF, keyboard, keyboardP2, diem, TenNguoiChoi, data, nData, nguoiChoi, TrangThai, 2);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				SPEED = temp;
				diem = 0;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				food.count = 0;
				BodyRan = BodyRanTemp;
				for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
				huong = huongTemp;
				TaoQuaThuong(food);
				VeQuaThuong(food);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			if (pause == 2)
			{
				option = MenuOption(x, y, VungDiChuyen, ChieuRong, checkPause, keyboard, keyboardP2, soundIG, soundEF, TenNguoiChoi, diem, BodyRan, ran, SPEED, huong, man, 0, ChuongNgaiVat,
									data, nData, nguoiChoi, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food.count < 6)
					{
						VeQuaThuong(food);
					}
					else
					{
						gotoXY(food.SpecialFood.x, food.SpecialFood.y);
						TextColor(241);
						cout << char(5);
					}
				}
				if (option == 2)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					diem = diemTam;
					SPEED = temp;
					food.count = 0;
					BodyRan = BodyRanTemp;
					for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
					huong = huongTemp;
					TaoQuaThuong(food);//T?o qu? ??u tiên
					VeQuaThuong(food);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			checkPause = false;
		}
		win = KiemTraDieuKienThang(diem, 1); //?n qu? xong thì ki?m tra l?i xem ?i?m ?ã ?? ?? qua màn
		if (win)
		{
			XoaQua(food);
			char HinhDangCong[10] = "doc";
			TaoCongWin(55, 18, CongWin, KichThuocCongWin, HinhDangCong);
			VeCongWin(CongWin, KichThuocCongWin);
			if (RanQuaMan(ran, CongWin))
			{
				if (soundIG == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				man++;
				break;
			}
		}
		playMusicGame(soundIG, isLose);
	}
}