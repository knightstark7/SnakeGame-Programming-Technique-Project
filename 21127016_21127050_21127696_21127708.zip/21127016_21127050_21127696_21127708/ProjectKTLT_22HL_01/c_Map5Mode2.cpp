﻿#include "c_Map5Mode2.h"
#include "c_mylib.h"
#include "c_menu.h"
#include "c_scoreboard.h"
#include "c_music.h"
#include <iostream>
using namespace std;

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110

void FoodRound3(QUA& food, ToaDo VatCan[], int KichThuocVatCan, ToaDo ran[], int ran_dot, ToaDo CongWin[], int cong_win_so_o)
{
	if (food.count == 5)
	{
		do
		{
			TaoQuaDacBiet(food);
		} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot)
			|| food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
		VeQuaDacBiet(food);
	}
	else if (food.count == 6)
	{
		do
		{
			TaoQuaDoc(food);
		} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
			|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
		VeQuaDoc(food);
	}
	else
	{
		do
		{
			TaoQuaThuong(food);
		} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot)
			|| food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
		VeQuaThuong(food);
	}
}

void TaoChuongNgaiVatMan5(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo VatCan[], int& KichThuocVatCan)
{
	for (int i = x + 1; i <= x + VungDiChuyen - 1; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		if (i != 24 && i != 25 && i != 26)
		{
			VatCan[KichThuocVatCan].x = i;
			VatCan[KichThuocVatCan].y = 13;
			KichThuocVatCan++;
		}
	}
	for (int i = y + 7; i <= y + 10; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 23;
		KichThuocVatCan++;
	}
	for (int i = y + 9; i <= y + 10; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 27;
		KichThuocVatCan++;
	}
	for (int i = y + 16; i <= y + 29; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 92;
		KichThuocVatCan++;
	}
	for (int i = y + 18; i <= y + 29; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 23;
		KichThuocVatCan++;
	}
	for (int i = x + 19; i <= x + VungDiChuyen - 58; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 9;
		KichThuocVatCan++;
	}
	for (int i = x + 19; i <= x + VungDiChuyen - 58; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 19;
		KichThuocVatCan++;
	}
	for (int i = x + 19; i <= x + VungDiChuyen - 1; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 34;
		KichThuocVatCan++;
	}
	for (int i = x + 19; i <= x + VungDiChuyen - 10; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 32;
		KichThuocVatCan++;
	}
	for (int i = y + 1; i <= y + 7; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 48;
		KichThuocVatCan++;
	}
	for (int i = y + 3; i <= y + 9; i++)
	{
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 52;
		KichThuocVatCan++;
	}
	for (int i = x + 49; i <= x + VungDiChuyen - 26; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 5;
		KichThuocVatCan++;
	}
	for (int i = x + 23; i <= x + VungDiChuyen - 50; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 11;
		KichThuocVatCan++;
	}
	for (int i = x + 1; i <= x + VungDiChuyen - 10; i++)
	{
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 17;
		KichThuocVatCan++;
	}
}

//Ki?m tra thua do ??ng v?t c?n màn 1
bool KiemTraThuaVatCan5(ToaDo ran[], ToaDo VatCan[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (ran[0].x == VatCan[i].x && ran[0].y == VatCan[i].y)
		{
			return true;
		}
	}
	return false;
}

//Ki?m tra thua màn 2
bool KiemTraThuaMan5(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan)
{
	if (RanChamThan(ran, ran_dot))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	if (KiemTraThuaVatCan5(ran, VatCan, KichThuocVatCan))
	{
		return true;
	}
	return false;
}

void AnQua3(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& trung_doc, int& SPEED, int& diem,   int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime)
{
	int diemtmp = 0;

	bool ThayDiem = false;

	if (isLose == true)
	{
		diemtmp = 0;
	}

	if (food.checkqua == true) {
		auto currentTime = std::chrono::high_resolution_clock::now();
		chrono::duration<double> duration = currentTime - startTime;
		elapsedTime = duration.count();
	}

	if (food.count < 5 && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(food);

		ran_dot++;
		diem += 100;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}

		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
	}
	else if (food.count == 5 && ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		ran_dot++;
		diem += 100;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count != 5)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}

	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count++;
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
		}
	}
	else if (food.count == 5 && ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
		}
	}
	else if (food.count == 6 && ran[0].x == food.PoisonFood.x && ran[0].y == food.PoisonFood.y) 
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		trung_doc = 1;
		diem -= 500;
		SPEED -= 2;
		food.count = 0;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (food.NormalFood.x == 38 || food.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (food.SpecialFood.x == 38 || food.SpecialFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || A.NormalFood.x == 38 || A.NormalFood.x == 73 || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
		else if (food.count == 6)
		{
			do
			{
				TaoQuaDoc(food);
			} while (!KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, ran, ran_dot)
				|| food.PoisonFood.x == 38 || food.PoisonFood.x == 73 || !KiemTraToaDoQuaKhaThi(food.PoisonFood.x, food.PoisonFood.y, CongWin, cong_win_so_o));
			VeQuaDoc(food);
		}
	}
}

//R?n trúng ??c- b? gi?m ??t
void TrungDoc(ToaDo ran[], int& ran_dot, int& thoi_gian_mat_dot)
{
	if (thoi_gian_mat_dot == 10)
	{
		gotoXY(ran[ran_dot - 1].x, ran[ran_dot - 1].y);
		cout << " ";
		ran_dot--;
		thoi_gian_mat_dot = 0;
	}
	else
	{
		thoi_gian_mat_dot++;
	}
}

void Man5Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int& KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode)
{
	int temp = SPEED;
	TaoChuongNgaiVatMan5(x, y, VungDiChuyen, ChieuRong, VatCan, KichThuocVatCan);
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm v? màn 2
	SPEED = temp;

	bool up = false;
	int trung_doc = 0;
	int thoi_gian_mat_dot = 0;

	bool checkPause = false;
	int diemTam = diem;
	int ran_dot_Tam = ran_dot;
	ToaDo ranTam[100];
	for (int i = 0; i < 100; i++)  ranTam[i] = ran[i];
	int huongTemp = huong;
	bool isLose = false;

	QUA food;
	QUA A;
	food.count = 0;//Số lượng quả
	A.checkqua = false;

	ToaDo CongWin[7];
	int cong_win_so_o = 0; //s? ô t?o thành 1 c?ng win
	FoodRound3(food, VatCan, KichThuocVatCan, ran, ran_dot, CongWin, cong_win_so_o);

	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	bool win = KiemTraDieuKienThang(diem, 5000);
	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	int option;
	while (1)
	{
		int huongTam = huong;
		noCursorType();//Xóa con tr?(d?u nháy)
		BatSuKienMode2(huong, checkPause, keyboard);//Nh?n phím
		ToaDo dot_cuoi_cu = DiChuyen(ran, huong, ran_dot);//Di chuy?n r?n d?a trên nút ???c nh?n trên bàn phím
		HienThiRan(ran, dot_cuoi_cu, ran_dot);//Hi?n th? thân r?n m?i sau khi di chuy?n

		Sleep(SPEED);
		if (!win)
			AnQua3(ran, food, A, ran_dot, trung_doc, SPEED, diem, x, y, ChieuRong, VatCan, KichThuocVatCan, CongWin, cong_win_so_o, soundIG, checkPause, isLose, elapsedTime, startTime);
		if (KiemTraThuaMan5(ran, ran_dot, VatCan, KichThuocVatCan) || (win && RanChamCongWin(ran, CongWin, cong_win_so_o)))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			XoaFileText(data, nData, TrangThai);
			int choice = MenuGameOver(soundIG, soundEF, keyboard, keyboardP2, diem, ten_nguoi_choi, data, nData, nguoiChoi, TrangThai, 2);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				SPEED = temp;
				diem = 0;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				food.count = 0;
				ran_dot = ran_dot_Tam;
				for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
				huong = huongTemp;
				TaoQuaThuong(food);
				VeQuaThuong(food);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			if (pause == 2)
			{
				option = MenuOption(x, y, VungDiChuyen, ChieuRong, checkPause, keyboard, keyboardP2, soundIG, soundEF, ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, 0, VatCan,
					data, nData, nguoiChoi, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food.count < 6)
					{
						VeQuaThuong(food);
					}
					else
					{
						gotoXY(food.SpecialFood.x, food.SpecialFood.y);
						TextColor(241);
						cout << char(5);
					}
				}
				if (option == 2)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					diem = diemTam;
					SPEED = temp;
					food.count = 0;
					ran_dot = ran_dot_Tam;
					for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
					huong = huongTemp;
					TaoQuaThuong(food);//T?o qu? ??u tiên
					VeQuaThuong(food);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			checkPause = false;
		}
		win = KiemTraDieuKienThang(diem, 1); //?n qu? xong thì ki?m tra l?i xem ?i?m ?ã ?? ?? qua màn
		if (win)
		{
			XoaQua(food);
			char huong_vao_cong[10] = "len";
			TaoCongWin(94, 6, CongWin, cong_win_so_o, huong_vao_cong);
			VeCongWin(CongWin, cong_win_so_o);
			if (RanQuaMan(ran, CongWin))
			{
				if (soundEF == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				man++;
				break;
			}
		}
		playMusicGame(soundIG, isLose);
	}
}