﻿#include "c_music.h"
#include "c_Map1Mode3.h"
#include "c_Map2Mode2.h"
#include "c_mylib.h"
#include "c_snake.h"
#include "c_scoreboard.h"
#include "c_menu.h"

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110

void AnQuaThuongMap4Mode3(ToaDo ran[], QUA& food, int& ran_dot, int& SPEED, int& diem, int x, int y, int ChieuRong, ToaDo ChuongNgaiVat[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundIG, int soundEF, bool checkPause, bool isLose)
{
	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}
	if (food.count < 5 && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);

		ran_dot++;
		diem += 100;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}

		if (food.count < 5)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
		}
	}
	else if (food.count == 5 && ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y) // +10 points, +1 dot
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count = 0;
		if (food.count < 5)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
		}
	}
}

void AnQua2ThuongMap4Mode3(ToaDo ran[], QUA& food, int& ran_dot, int& SPEED, int& diem, int x, int y, int ChieuRong, ToaDo ChuongNgaiVat[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundIG, int soundEF, bool checkPause, bool isLose)
{
	int diemtmp = 0;
	bool ThayDiem = false;
	if (isLose == true)
	{
		diemtmp = 0;
	}
	if (food.count < 5 && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}
		XoaQua(food);

		ran_dot++;
		diem += 100;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}

		if (food.count < 5)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
		}
	}
	else if (food.count == 5 && ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y) // +10 points, +1 dot
	{
		if (soundEF == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count = 0;
		if (food.count < 5)
		{
			do
			{
				TaoQuaThuong2(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong2(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ChuongNgaiVat, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
		}
	}
}

//Ki?m tra thua do ??ng v?t c?n màn 1
bool KiemTraThuaVatCan4Mode3(ToaDo ran[], ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (ran[0].x == ChuongNgaiVat[i].x && ran[0].y == ChuongNgaiVat[i].y)
		{
			return true;
		}
	}
	return false;
}

bool KiemTraThuaMan4Mode3(ToaDo ran[], int ran_dot, ToaDo ChuongNgaiVat[], int KichThuocVatCan)
{
	if (RanChamThan(ran, ran_dot))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	if (KiemTraThuaVatCan4Mode3(ran, ChuongNgaiVat, KichThuocVatCan))
	{
		return true;
	}
	return false;
}

void TaoChuongNgaiVatMan4Mode3(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo ChuongNgaiVat[], int& KichThuocVatCan)
{

	for (int i = x + 1; i <= x + VungDiChuyen - 25; i++)
	{
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 10;
		KichThuocVatCan++;
	}

	for (int i = y + 9; i <= y + ChieuRong - 9; i++)
	{
		ChuongNgaiVat[KichThuocVatCan].y = i;
		ChuongNgaiVat[KichThuocVatCan].x = 27;
		KichThuocVatCan++;
	}

	for (int i = x + 29; i <= x + VungDiChuyen - 25; i++)
	{
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 16;
		KichThuocVatCan++;
	}

	for (int i = x + 23; i <= x + VungDiChuyen - 25; i++)
	{
		ChuongNgaiVat[KichThuocVatCan].x = i;
		ChuongNgaiVat[KichThuocVatCan].y = 37;
		KichThuocVatCan++;
	}


	for (int i = y + 14; i <= y + ChieuRong - 9; i++)
	{
		ChuongNgaiVat[KichThuocVatCan].y = i;
		ChuongNgaiVat[KichThuocVatCan].x = 77;
		KichThuocVatCan++;
	}
}

void Man4Mode3(char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], ToaDo ran2[], int& BodyRan1, int& BodyRan2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong1, int& huong2, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode)
{
	char HinhDangCong[] = "doc";
	int temp = SPEED;
	SPEED = temp;

	QUA food1;
	QUA food2;

	food1.count = 0;//Số lượng quả
	food2.count = 0;

	TaoChuongNgaiVatMan4Mode3(x, y, VungDiChuyen, ChieuRong, ChuongNgaiVat, KichThuocVatCan);
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man); //Hàm vẽ màn 1


	bool checkPause = false;
	int diemTam = diem;

	int ran_dot_Tam1 = BodyRan1;
	int ran_dot_Tam2 = BodyRan2;

	ToaDo ranTam1[100];
	ToaDo ranTam2[100];

	for (int i = 0; i < 100; i++)
	{
		ranTam1[i] = ran1[i];
		ranTam2[i] = ran2[i];
	}
	int huongTemp1 = huong1;
	int huongTemp2 = huong2;
	bool isLose = false;

	TaoQuaThuong(food1);//Tao qua dau tiên
	VeQuaThuong(food1);

	TaoQuaThuong2(food2);//Tao qua thu hai
	VeQuaThuong2(food2);

	VeRan(ran1, BodyRan1);
	VeRan(ran2, BodyRan2);

	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	ToaDo CongWin[7];
	ToaDo cong_win2[7];
	int cong_win_so_o = 0; //so o tao thanh 1 cong win

	bool snake1IsLive = true; //kiem tra ran qua cong chua
	bool snake2IsLive = true;

	bool win = KiemTraDieuKienThang(diem, 200 * man);
	int option = 0;
	while (1)
	{
		int huongTam1 = huong1;
		int huongTam2 = huong2;

		noCursorType();
		BatSuKienMode3(huong1, huong2, checkPause, KeyBoardP1, KeyBoardP2, 0,0);

		DiXuyenQua2(ran1, food2, huong1); //ran1 di xuyen qua qua 2
		DiXuyenQua1(ran2, food1, huong2); //ran2 di xuyen qua qua 1

		if (snake1IsLive) {
			ToaDo dot_cuoi_cu = DiChuyen(ran1, huong1, BodyRan1);
			HienThiRan(ran1, dot_cuoi_cu, BodyRan1);
		}

		if (snake2IsLive) {
			ToaDo dot_cuoi_cu2 = DiChuyen(ran2, huong2, BodyRan2);
			HienThiRan2(ran2, dot_cuoi_cu2, BodyRan2);
		}

		Sleep(SPEED);//Tốc độ rắn = 150
		AnQuaThuongMap4Mode3(ran1, food1, BodyRan1, SPEED, diem, x, y, ChieuRong, ChuongNgaiVat, KichThuocVatCan, CongWin, cong_win_so_o, soundIG, soundEF, checkPause, isLose);//Ki?m tra ?n qu?
		AnQua2ThuongMap4Mode3(ran2, food2, BodyRan2, SPEED, diem, x, y, ChieuRong, ChuongNgaiVat, KichThuocVatCan, cong_win2, cong_win_so_o, soundIG, soundEF, checkPause, isLose);//Ki?m tra ?n qua

		if (KiemTraThuaMan4Mode3(ran1, BodyRan1, ChuongNgaiVat, KichThuocVatCan) || KiemTraThuaMan4Mode3(ran2, BodyRan2, ChuongNgaiVat, KichThuocVatCan) || RanChamNhau(ran1, ran2, BodyRan1, BodyRan2) || (win && RanChamCongWin(ran1, CongWin, cong_win_so_o)) || (win && RanChamCongWin(ran2, CongWin, cong_win_so_o)) || (win && RanChamCongWin(ran1, cong_win2, cong_win_so_o)) || (win && RanChamCongWin(ran2, cong_win2, cong_win_so_o)) || RanQuaMan(ran1, cong_win2) || RanQuaMan(ran2, CongWin))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			int choice = MenuGameOver(soundIG, soundEF, KeyBoardP1, KeyBoardP2, diem, ten_nguoi_choi, data, nData, nguoiChoi, TrangThai, 3);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				diem = 0;
				SPEED = temp;
				food1.count = 0;
				food2.count = 0;
				BodyRan1 = ran_dot_Tam1;
				BodyRan2 = ran_dot_Tam2;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				for (int i = 0; i < 100; i++)
				{
					ran1[i] = ranTam1[i];
					ran2[i] = ranTam2[i];
				}
				huong1 = huongTemp1;
				huong2 = huongTemp2;
				TaoQuaThuong(food1);
				VeQuaThuong(food1);
				TaoQuaThuong2(food2);
				VeQuaThuong2(food2);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food1.count < 6)
				{
					VeQuaThuong(food1);
				}
				if (food2.count < 6) {
					VeQuaThuong2(food2);
				}
				else if (food1.count > 6)
				{
					gotoXY(food1.SpecialFood.x, food1.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
				else if (food2.count > 6)
				{
					gotoXY(food2.SpecialFood.x, food2.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			if (pause == 2)
			{
				option = MenuOption2(x, y, VungDiChuyen, ChieuRong, checkPause, KeyBoardP1, KeyBoardP2, soundIG, soundEF, ten_nguoi_choi, ten_nguoi_choi2, diem, diem, BodyRan1, ran1, BodyRan2, ran2, SPEED, huong1, huong2, man, 0, ChuongNgaiVat,
					data, nData, nguoiChoi, nguoiChoi2, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food1.count < 6)
					{
						VeQuaThuong(food1);
					}
					if (food2.count < 6) {
						VeQuaThuong2(food2);
					}
					else if (food1.count > 6)
					{
						VeQuaDacBiet(food1);
					}
					else if (food2.count > 6)
					{
						VeQuaDacBiet(food2);
					}
				}
				if (option == 2)
				{
					system("cls");
					diem = 0;
					SPEED = temp;
					food1.count = 0;
					food2.count = 0;
					BodyRan1 = ran_dot_Tam1;
					BodyRan2 = ran_dot_Tam2;
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					for (int i = 0; i < 100; i++)
					{
						ran1[i] = ranTam1[i];
						ran2[i] = ranTam2[i];
					}
					huong1 = huongTemp1;
					huong2 = huongTemp2;
					TaoQuaThuong(food1);
					VeQuaThuong(food1);
					TaoQuaThuong2(food2);
					VeQuaThuong2(food2);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, KeyBoardP1, KeyBoardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, ChuongNgaiVat, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food1.count < 6)
				{
					VeQuaThuong(food1);
				}
				if (food2.count < 6) {
					VeQuaThuong2(food2);
				}
				else if (food1.count > 6)
				{
					gotoXY(food1.SpecialFood.x, food1.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
				else if (food2.count > 6)
				{
					gotoXY(food2.SpecialFood.x, food2.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			checkPause = false;
		}
		win = KiemTraDieuKienThang(diem, 5 * man);
		if (win)
		{
			XoaQua(food1);
			XoaQua(food2);

			char HinhDangCong[10] = "doc";
			TaoCongWin(55, 18, CongWin, cong_win_so_o, HinhDangCong);
			VeCongWin(CongWin, cong_win_so_o);

			char huong_vao_cong2[10] = "doc";
			TaoCongWin(30, 10, cong_win2, cong_win_so_o, huong_vao_cong2);
			VeCongWin2(cong_win2, cong_win_so_o);
			if (RanQuaMan2(ran1, CongWin, BodyRan1))
			{
				if (soundIG == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				snake1IsLive = false;
			}
			if (RanQuaMan2(ran2, cong_win2, BodyRan2))
			{
				if (soundIG == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				snake2IsLive = false;
			}
			if (snake1IsLive == false && snake2IsLive == false)
			{
				man++;
				break;
			}
		}
		playMusicGame(soundIG, isLose);
	}
}