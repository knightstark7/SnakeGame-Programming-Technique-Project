#pragma once
#pragma comment(lib, "winmm.lib")
#include <cstdlib>
#include "c_snake.h"

void AnQuaThuongMapMode4(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int& diem2, int x, int y, int ChieuRong, ToaDo vat_can[], int so_o_vat_can, ToaDo cong_win[], int cong_win_so_o, int soundBG, int soundEF, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime, double& elapsedTime1, chrono::time_point<std::chrono::high_resolution_clock>& startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>& startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>& startTime3);

void AnQua2ThuongMapMode4(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int& diem2, int x, int y, int ChieuRong, ToaDo vat_can[], int so_o_vat_can, ToaDo cong_win[], int cong_win_so_o, int soundBG, int soundEF, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime, double& elapsedTime1, chrono::time_point<std::chrono::high_resolution_clock>& startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>& startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>& startTime3);

void ManMode4(char* ten_nguoi_choi1, char* ten_nguoi_choi2, ToaDo ran1[], ToaDo ran2[], int& ran_dot1, int& ran_dot2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int& man, ToaDo vat_can[], int vat_can_so_o,
	string* data, int& nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode);