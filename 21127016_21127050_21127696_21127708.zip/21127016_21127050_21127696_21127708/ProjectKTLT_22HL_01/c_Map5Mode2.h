#pragma once
#include "c_snake.h"
#include "c_savegame.h"
#pragma comment(lib, "winmm.lib")

void FoodRound3(QUA& food, ToaDo VatCan[], int KichThuocVatCan, ToaDo ran[], int ran_dot, ToaDo CongWin[], int cong_win_so_o);

bool KiemTraThuaVatCan5(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan);

bool KiemTraThuaMan5(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan);

void AnQua3(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& trung_doc, int& SPEED, int& diem,   int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime);

void TrungDoc(ToaDo ran[], int& ran_dot, int& thoi_gian_mat_dot);

void Man5Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int& KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode);