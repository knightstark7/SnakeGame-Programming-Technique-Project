﻿#include "c_menu.h"
#include "c_mylib.h"
#include "c_snake.h"
#include "c_text.h"
#include "c_savegame.h"
#include "c_scoreboard.h"
#include <iostream>
#include <string.h>
#include <conio.h>
#include "c_music.h"
using namespace std;

void printIntro()
{
	char text_index[10] = { 'a', 'l', 'p', 'h', 'a', 'k', 'i', 'd', 's', 'j'};
	// fade in
	system("color F");
	Sleep(50);
	print_Text(text_index[0], 24, 36);
	Sleep(50);
	print_Text(text_index[1], 24, 40);
	Sleep(50);
	print_Text(text_index[2], 24, 44);
	Sleep(50);
	print_Text(text_index[3], 24, 48);
	Sleep(50);
	print_Text(text_index[4], 24, 52);
	Sleep(50);
	print_Text(text_index[5], 24, 58);
	Sleep(50);
	print_Text(text_index[6], 24, 62);
	Sleep(50);
	print_Text(text_index[7], 24, 64);
	Sleep(50);
	print_Text(text_index[8], 24, 68);
	Sleep(1000);
	gotoXY(50, 29); cout << "PRESENTS";
	Sleep(4000);

	//fade out
	system("color 8F");
	Sleep(50);
	system("color 7F");
	Sleep(50);
	system("color FF");
	TextColor(119);
	print_Text(text_index[9], 24, 36); // cout text null
	print_Text(text_index[9], 24, 40);
	print_Text(text_index[9], 24, 44);
	print_Text(text_index[9], 24, 48);
	print_Text(text_index[9], 24, 52);
	print_Text(text_index[9], 24, 58);
	print_Text(text_index[9], 24, 62);
	print_Text(text_index[9], 24, 64);
	print_Text(text_index[9], 24, 68);
	gotoXY(50, 29); cout << "        ";
	system("color F0");
}


void VeTieuDeOption(int x, int y, int VungDiChuyen, int ChieuRong)
{
	//Tiêu đề: Option
	TextColor(204);
	for (int i = x + 29; i <= VungDiChuyen - 24; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 30; i <= VungDiChuyen - 25; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(33, 6); cout << char(201);
	gotoXY(74, 6); cout << char(187);
	gotoXY(33, 10); cout << char(200);
	gotoXY(74, 10); cout << char(188);

	char option[6] = { 'o', 'p', 't', 'i', 'o', 'n' };
	TextColor(206);
	print_Text(option[0], 7, 44);
	print_Text(option[1], 7, 48);
	print_Text(option[2], 7, 52);
	print_Text(option[3], 7, 56);
	print_Text(option[4], 7, 58);
	print_Text(option[5], 7, 62);
}

void HienThiSound(int select_main)
{
	char sound[6] = { 's', 'o', 'u', 'n', 'd' };
	if (select_main == 1)
	{
		TextColor(244);
		print_Text(sound[0], 14, 23);
		print_Text(sound[1], 14, 27);
		print_Text(sound[2], 14, 31);
		print_Text(sound[3], 14, 35);
		print_Text(sound[4], 14, 39);
		print_Text(sound[5], 14, 43);
	}
	else
	{
		TextColor(246);
		print_Text(sound[0], 14, 23);
		print_Text(sound[1], 14, 27);
		print_Text(sound[2], 14, 31);
		print_Text(sound[3], 14, 35);
		print_Text(sound[4], 14, 39);
		print_Text(sound[5], 14, 43);
	}
}

void HienThiControlKey(int select_main)
{
	char Controlkey[10] = { 'h', 'o', 't', 'k', 'e', 'y' };
	if (select_main == 2)
	{
		TextColor(244);
		print_Text(Controlkey[0], 21, 21);
		print_Text(Controlkey[1], 21, 25);
		print_Text(Controlkey[2], 21, 29);
		print_Text(Controlkey[3], 21, 33);
		print_Text(Controlkey[4], 21, 37);
		print_Text(Controlkey[5], 21, 41);
	}
	else
	{
		TextColor(246);
		print_Text(Controlkey[0], 21, 21);
		print_Text(Controlkey[1], 21, 25);
		print_Text(Controlkey[2], 21, 29);
		print_Text(Controlkey[3], 21, 33);
		print_Text(Controlkey[4], 21, 37);
		print_Text(Controlkey[5], 21, 41);
	}
}

void HienThiChonEffect(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subA)
{
	if (select_main == 1 && select_subA == 1)
	{
		TextColor(244);
		for (int i = y + 12; i <= ChieuRong - 30; i++)
		{
			//Cạnh trên
			gotoXY(47, i); cout << char(186);
			//Cạnh dưới
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			gotoXY(i, 13); cout << char(205);
			gotoXY(i, 15); cout << char(205);
		}
		gotoXY(47, 13); cout << char(201);
		gotoXY(64, 13); cout << char(187);
		gotoXY(47, 15); cout << char(200);
		gotoXY(64, 15); cout << char(188);

		gotoXY(48, 14);  cout << "EFFECT SOUND";
	}
	else
	{
		TextColor(240);
		for (int i = y + 12; i <= ChieuRong - 30; i++)
		{
			//Cạnh trên
			gotoXY(47, i); cout << char(186);
			//Cạnh dưới
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			gotoXY(i, 13); cout << char(205);
			gotoXY(i, 15); cout << char(205);
		}
		gotoXY(47, 13); cout << char(201);
		gotoXY(64, 13); cout << char(187);
		gotoXY(47, 15); cout << char(200);
		gotoXY(64, 15); cout << char(188);

		TextColor(241);
		gotoXY(48, 14);  cout << "EFFECT SOUND";
	}
}

void HienThiChonSoundBG(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subA)
{
	if (select_main == 1 && select_subA == 2)
	{
		TextColor(244);
		for (int i = y + 15; i <= ChieuRong - 27; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 16); cout << char(205);
			//cạnh dưới
			gotoXY(i, 18); cout << char(205);
		}
		gotoXY(47, 16); cout << char(201);
		gotoXY(64, 16); cout << char(187);
		gotoXY(47, 18); cout << char(200);
		gotoXY(64, 18); cout << char(188);

		gotoXY(48, 17);  cout << "BACKGROUND SOUND";
	}
	else
	{
		TextColor(240);
		for (int i = y + 15; i <= ChieuRong - 27; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 16); cout << char(205);
			//cạnh dưới
			gotoXY(i, 18); cout << char(205);
		}
		gotoXY(47, 16); cout << char(201);
		gotoXY(64, 16); cout << char(187);
		gotoXY(47, 18); cout << char(200);
		gotoXY(64, 18); cout << char(188);
		
		TextColor(241);
		gotoXY(48, 17);  cout << "BACKGROUND SOUND";
	}
}

void HienThiP2MoveLeft(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboardP2)
{
	if (select_main == 2 && select_subB == 5)
	{
		TextColor(244);
		for (int i = y + 26; i <= ChieuRong - 16; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 27); cout << char(205);
			//cạnh dưới
			gotoXY(i, 29); cout << char(205);
		}
		gotoXY(47, 27); cout << char(201);
		gotoXY(64, 27); cout << char(187);
		gotoXY(47, 29); cout << char(200);
		gotoXY(64, 29); cout << char(188);

		gotoXY(48, 28); cout << "P2 MOVE LEFT: " << (char)toupper(keyboardP2.MoveLeft);
	}
	else
	{
		TextColor(240);
		for (int i = y + 26; i <= ChieuRong - 16; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 27); cout << char(205);
			//cạnh dưới
			gotoXY(i, 29); cout << char(205);
		}
		gotoXY(47, 27); cout << char(201);
		gotoXY(64, 27); cout << char(187);
		gotoXY(47, 29); cout << char(200);
		gotoXY(64, 29); cout << char(188);

		TextColor(241);
		gotoXY(48, 28); cout << "P2 MOVE LEFT: " << (char)toupper(keyboardP2.MoveLeft);
	}
}

void HienThiP2MoveRight(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboardP2)
{
	if (select_main == 2 && select_subB == 6)
	{
		TextColor(244);
		for (int i = y + 29; i <= ChieuRong - 13; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 30); cout << char(205);
			//cạnh dưới
			gotoXY(i, 32); cout << char(205);
		}
		gotoXY(47, 30); cout << char(201);
		gotoXY(64, 30); cout << char(187);
		gotoXY(47, 32); cout << char(200);
		gotoXY(64, 32); cout << char(188);

		gotoXY(48, 31); cout << "P2 MOVE RIGHT:" << (char)toupper(keyboardP2.MoveRight);
	}
	else
	{
		TextColor(240);
		for (int i = y + 29; i <= ChieuRong - 13; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 30); cout << char(205);
			//cạnh dưới
			gotoXY(i, 32); cout << char(205);
		}
		gotoXY(47, 30); cout << char(201);
		gotoXY(64, 30); cout << char(187);
		gotoXY(47, 32); cout << char(200);
		gotoXY(64, 32); cout << char(188);

		TextColor(241);
		gotoXY(48, 31); cout << "P2 MOVE RIGHT:" << (char)toupper(keyboardP2.MoveRight);
	}
}

void HienThiP2MoveUp(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboardP2)
{
	if (select_main == 2 && select_subB == 7)
	{
		TextColor(244);
		for (int i = y + 26; i <= ChieuRong - 14; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 27); cout << char(205);
			//cạnh dưới
			gotoXY(i, 29); cout << char(205);
		}
		gotoXY(67, 27); cout << char(201);
		gotoXY(84, 27); cout << char(187);
		gotoXY(67, 29); cout << char(200);
		gotoXY(84, 29); cout << char(188);

		gotoXY(68, 28); cout << "P2 MOVE UP: " << (char)toupper(keyboardP2.MoveUp);
	}
	else
	{
		TextColor(240);
		for (int i = y + 26; i <= ChieuRong - 16; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 27); cout << char(205);
			//cạnh dưới
			gotoXY(i, 29); cout << char(205);
		}
		gotoXY(67, 27); cout << char(201);
		gotoXY(84, 27); cout << char(187);
		gotoXY(67, 29); cout << char(200);
		gotoXY(84, 29); cout << char(188);

		TextColor(241);
		gotoXY(68, 28); cout << "P2 MOVE UP: " << (char)toupper(keyboardP2.MoveUp);
	}
}

void HienThiP2MoveDown(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboardP2)
{
	if (select_main == 2 && select_subB == 8)
	{
		TextColor(244);
		for (int i = y + 29; i <= ChieuRong - 13; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 30); cout << char(205);
			//cạnh dưới
			gotoXY(i, 32); cout << char(205);
		}
		gotoXY(67, 30); cout << char(201);
		gotoXY(84, 30); cout << char(187);
		gotoXY(67, 32); cout << char(200);
		gotoXY(84, 32); cout << char(188);

		gotoXY(68, 31); cout << "P2 MOVE DOWN:" << (char)toupper(keyboardP2.MoveDown);
	}
	else
	{
		TextColor(240);
		for (int i = y + 29; i <= ChieuRong - 13; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 30); cout << char(205);
			//cạnh dưới
			gotoXY(i, 32); cout << char(205);
		}
		gotoXY(67, 30); cout << char(201);
		gotoXY(84, 30); cout << char(187);
		gotoXY(67, 32); cout << char(200);
		gotoXY(84, 32); cout << char(188);

		TextColor(241);
		gotoXY(68, 31); cout << "P2 MOVE DOWN:" << (char)toupper(keyboardP2.MoveDown);
	}
}

void HienThiP1MoveLeft(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboard)
{
	if (select_main == 2 && select_subB == 1)
	{
		TextColor(244);
		for (int i = y + 19; i <= ChieuRong - 23; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 20); cout << char(205);
			//cạnh dưới
			gotoXY(i, 22); cout << char(205);
		}
		gotoXY(47, 20); cout << char(201);
		gotoXY(64, 20); cout << char(187);
		gotoXY(47, 22); cout << char(200);
		gotoXY(64, 22); cout << char(188);

		gotoXY(48, 21); cout << "P1 MOVE LEFT: " << (char) toupper(keyboard.MoveLeft);
	}
	else
	{
		TextColor(240);
		for (int i = y + 19; i <= ChieuRong - 23; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 20); cout << char(205);
			//cạnh dưới
			gotoXY(i, 22); cout << char(205);
		}
		gotoXY(47, 20); cout << char(201);
		gotoXY(64, 20); cout << char(187);
		gotoXY(47, 22); cout << char(200);
		gotoXY(64, 22); cout << char(188);

		TextColor(241);
		gotoXY(48, 21); cout << "P1 MOVE LEFT: " << (char) toupper(keyboard.MoveLeft);
	}
}

void HienThiP1MoveRight(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboard)
{
	if (select_main == 2 && select_subB == 2)
	{
		TextColor(244);
		for (int i = y + 22; i <= ChieuRong - 20; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 23); cout << char(205);
			//cạnh dưới
			gotoXY(i, 25); cout << char(205);
		}
		gotoXY(47, 23); cout << char(201);
		gotoXY(64, 23); cout << char(187);
		gotoXY(47, 25); cout << char(200);
		gotoXY(64, 25); cout << char(188);

		gotoXY(48, 24); cout << "P1 MOVE RIGHT:" << (char)toupper(keyboard.MoveRight);
	}
	else
	{
		TextColor(240);
		for (int i = y + 22; i <= ChieuRong - 20; i++)
		{
			//Cạnh trái
			gotoXY(47, i); cout << char(186);
			//Cạnh phải
			gotoXY(64, i); cout << char(186);
		}
		for (int i = x + 44; i <= VungDiChuyen - 35; i++)
		{
			//cạnh trên
			gotoXY(i, 23); cout << char(205);
			//cạnh dưới
			gotoXY(i, 25); cout << char(205);
		}
		gotoXY(47, 23); cout << char(201);
		gotoXY(64, 23); cout << char(187);
		gotoXY(47, 25); cout << char(200);
		gotoXY(64, 25); cout << char(188);

		TextColor(241);
		gotoXY(48, 24); cout << "P1 MOVE RIGHT:" << (char)toupper(keyboard.MoveRight);
	}
}

void HienThiP1MoveUp(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboard)
{
	if (select_main == 2 && select_subB == 3)
	{
		TextColor(244);
		for (int i = y + 19; i <= ChieuRong - 23; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 20); cout << char(205);
			//cạnh dưới
			gotoXY(i, 22); cout << char(205);
		}
		gotoXY(67, 20); cout << char(201);
		gotoXY(84, 20); cout << char(187);
		gotoXY(67, 22); cout << char(200);
		gotoXY(84, 22); cout << char(188);

		gotoXY(68, 21); cout << "P1 MOVE UP:" << (char)toupper(keyboard.MoveUp);
	}
	else
	{
		TextColor(240);
		for (int i = y + 19; i <= ChieuRong - 23; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 20); cout << char(205);
			//cạnh dưới
			gotoXY(i, 22); cout << char(205);
		}
		gotoXY(67, 20); cout << char(201);
		gotoXY(84, 20); cout << char(187);
		gotoXY(67, 22); cout << char(200);
		gotoXY(84, 22); cout << char(188);

		TextColor(241);
		gotoXY(68, 21); cout << "P1 MOVE UP:" << (char)toupper(keyboard.MoveUp);
	}
}

void HienThiP1MoveDown(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subB, MoveKeyBoard& keyboard)
{
	if (select_main == 2 && select_subB == 4)
	{
		TextColor(244);
		for (int i = y + 22; i <= ChieuRong - 20; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 23); cout << char(205);
			//cạnh dưới
			gotoXY(i, 25); cout << char(205);
		}
		gotoXY(67, 23); cout << char(201);
		gotoXY(84, 23); cout << char(187);
		gotoXY(67, 25); cout << char(200);
		gotoXY(84, 25); cout << char(188);

		gotoXY(68, 24); cout << "P1 MOVE DOWN:" << (char)toupper(keyboard.MoveDown);
	}
	else
	{
		TextColor(240);
		for (int i = y + 22; i <= ChieuRong - 20; i++)
		{
			//Cạnh trái
			gotoXY(67, i); cout << char(186);
			//Cạnh phải
			gotoXY(84, i); cout << char(186);
		}
		for (int i = x + 64; i <= VungDiChuyen - 15; i++)
		{
			//cạnh trên
			gotoXY(i, 23); cout << char(205);
			//cạnh dưới
			gotoXY(i, 25); cout << char(205);
		}
		gotoXY(67, 23); cout << char(201);
		gotoXY(84, 23); cout << char(187);
		gotoXY(67, 25); cout << char(200);
		gotoXY(84, 25); cout << char(188);

		TextColor(241);
		gotoXY(68, 24); cout << "P1 MOVE DOWN:" << (char)toupper(keyboard.MoveDown);
	}
}

void ChangeControlKey(char phim, int select_main, int select_subA, int select_subB, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2)
{
	if (select_main == 2 && select_subB == 1 && int(phim) == 13)
	{
		char MoveLeftNew = _getch();
		if (MoveLeftNew == keyboard.MoveDown)
		{
			swap(keyboard.MoveLeft, keyboard.MoveDown);
		}
		else if (MoveLeftNew == keyboard.MoveRight)
		{
			swap(keyboard.MoveLeft, keyboard.MoveRight);
		}
		else if (MoveLeftNew == keyboard.MoveUp)
		{
			swap(keyboard.MoveLeft, keyboard.MoveUp);
		}
		else if (MoveLeftNew == keyboardP2.MoveUp)
		{
			swap(keyboard.MoveLeft, keyboardP2.MoveUp);
		}
		else if (MoveLeftNew == keyboardP2.MoveDown)
		{
			swap(keyboard.MoveLeft, keyboardP2.MoveDown);
		}
		else if (MoveLeftNew == keyboardP2.MoveLeft)
		{
			swap(keyboard.MoveLeft, keyboardP2.MoveLeft);
		}
		else if (MoveLeftNew == keyboardP2.MoveRight)
		{
			swap(keyboard.MoveLeft, keyboardP2.MoveRight);
		}
		else
		{
			keyboard.MoveLeft = MoveLeftNew;
		}
	}
	if (select_main == 2 && select_subB == 2 && int(phim) == 13)
	{
		char MoveRightNew = _getch();
		if (MoveRightNew == keyboard.MoveDown)
		{
			swap(keyboard.MoveRight, keyboard.MoveDown);
		}
		else if (MoveRightNew == keyboard.MoveLeft)
		{
			swap(keyboard.MoveRight, keyboard.MoveLeft);
		}
		else if (MoveRightNew == keyboard.MoveUp)
		{
			swap(keyboard.MoveRight, keyboard.MoveUp);
		}
		else if (MoveRightNew == keyboardP2.MoveUp)
		{
			swap(keyboard.MoveRight, keyboardP2.MoveUp);
		}
		else if (MoveRightNew == keyboardP2.MoveDown)
		{
			swap(keyboard.MoveRight, keyboardP2.MoveDown);
		}
		else if (MoveRightNew == keyboardP2.MoveLeft)
		{
			swap(keyboard.MoveRight, keyboardP2.MoveLeft);
		}
		else if (MoveRightNew == keyboardP2.MoveRight)
		{
			swap(keyboard.MoveRight, keyboardP2.MoveRight);
		}
		else
		{
			keyboard.MoveRight = MoveRightNew;
		}
	}
	if (select_main == 2 && select_subB == 3 && int(phim) == 13)
	{
		char MoveUpNew = _getch();
		if (MoveUpNew == keyboard.MoveDown)
		{
			swap(keyboard.MoveUp, keyboard.MoveDown);
		}
		else if (MoveUpNew == keyboard.MoveLeft)
		{
			swap(keyboard.MoveUp, keyboard.MoveLeft);
		}
		else if (MoveUpNew == keyboard.MoveRight)
		{
			swap(keyboard.MoveUp, keyboard.MoveRight);
		}
		else if (MoveUpNew == keyboardP2.MoveUp)
		{
			swap(keyboard.MoveUp, keyboardP2.MoveUp);
		}
		else if (MoveUpNew == keyboardP2.MoveDown)
		{
			swap(keyboard.MoveUp, keyboardP2.MoveDown);
		}
		else if (MoveUpNew == keyboardP2.MoveLeft)
		{
			swap(keyboard.MoveUp, keyboardP2.MoveLeft);
		}
		else if (MoveUpNew == keyboardP2.MoveRight)
		{
			swap(keyboard.MoveUp, keyboardP2.MoveRight);
		}
		else
		{
			keyboard.MoveUp = MoveUpNew;
		}
	}
	if (select_main == 2 && select_subB == 4 && int(phim) == 13)
	{
		char MoveDownNew = _getch();
		if (MoveDownNew == keyboard.MoveLeft)
		{
			swap(keyboard.MoveDown, keyboard.MoveLeft);
		}
		else if (MoveDownNew == keyboard.MoveRight)
		{
			swap(keyboard.MoveDown, keyboard.MoveRight);
		}
		else if (MoveDownNew == keyboard.MoveUp)
		{
			swap(keyboard.MoveDown, keyboard.MoveUp);
		}
		else if (MoveDownNew == keyboardP2.MoveUp)
		{
			swap(keyboard.MoveDown, keyboardP2.MoveUp);
		}
		else if (MoveDownNew == keyboardP2.MoveDown)
		{
			swap(keyboard.MoveDown, keyboardP2.MoveDown);
		}
		else if (MoveDownNew == keyboardP2.MoveLeft)
		{
			swap(keyboard.MoveDown, keyboardP2.MoveLeft);
		}
		else if (MoveDownNew == keyboardP2.MoveRight)
		{
			swap(keyboard.MoveDown, keyboardP2.MoveRight);
		}
		else
		{
			keyboard.MoveDown = MoveDownNew;
		}
	}
	if (select_main == 2 && select_subB == 5 && int(phim) == 13)
	{
		char MoveLeftNew = _getch();
		if (MoveLeftNew == keyboardP2.MoveDown)
		{
			swap(keyboardP2.MoveLeft, keyboardP2.MoveDown);
		}
		else if (MoveLeftNew == keyboardP2.MoveRight)
		{
			swap(keyboardP2.MoveLeft, keyboardP2.MoveRight);
		}
		else if (MoveLeftNew == keyboardP2.MoveUp)
		{
			swap(keyboardP2.MoveLeft, keyboardP2.MoveUp);
		}
		else if (MoveLeftNew == keyboard.MoveUp)
		{
			swap(keyboardP2.MoveLeft, keyboard.MoveUp);
		}
		else if (MoveLeftNew == keyboard.MoveDown)
		{
			swap(keyboardP2.MoveLeft, keyboard.MoveDown);
		}
		else if (MoveLeftNew == keyboard.MoveLeft)
		{
			swap(keyboardP2.MoveLeft, keyboard.MoveLeft);
		}
		else if (MoveLeftNew == keyboard.MoveRight)
		{
			swap(keyboardP2.MoveLeft, keyboard.MoveRight);
		}
		else
		{
			keyboardP2.MoveLeft = MoveLeftNew;
		}
	}
	if (select_main == 2 && select_subB == 6 && int(phim) == 13)
	{
		char MoveRightNew = _getch();
		if (MoveRightNew == keyboardP2.MoveDown)
		{
			swap(keyboardP2.MoveRight, keyboardP2.MoveDown);
		}
		else if (MoveRightNew == keyboardP2.MoveLeft)
		{
			swap(keyboardP2.MoveRight, keyboardP2.MoveLeft);
		}
		else if (MoveRightNew == keyboardP2.MoveUp)
		{
			swap(keyboardP2.MoveRight, keyboardP2.MoveUp);
		}
		else if (MoveRightNew == keyboard.MoveUp)
		{
			swap(keyboardP2.MoveRight, keyboard.MoveUp);
		}
		else if (MoveRightNew == keyboard.MoveDown)
		{
			swap(keyboardP2.MoveRight, keyboard.MoveDown);
		}
		else if (MoveRightNew == keyboard.MoveLeft)
		{
			swap(keyboardP2.MoveRight, keyboard.MoveLeft);
		}
		else if (MoveRightNew == keyboard.MoveRight)
		{
			swap(keyboardP2.MoveRight, keyboard.MoveRight);
		}
		else
		{
			keyboardP2.MoveRight = MoveRightNew;
		}
	}
	if (select_main == 2 && select_subB == 7 && int(phim) == 13)
	{
		char MoveUpNew = _getch();
		if (MoveUpNew == keyboardP2.MoveDown)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveDown);
		}
		else if (MoveUpNew == keyboardP2.MoveLeft)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveLeft);
		}
		else if (MoveUpNew == keyboardP2.MoveRight)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveRight);
		}
		else if (MoveUpNew == keyboard.MoveUp)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveUp);
		}
		else if (MoveUpNew == keyboard.MoveDown)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveDown);
		}
		else if (MoveUpNew == keyboard.MoveLeft)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveLeft);
		}
		else if (MoveUpNew == keyboard.MoveRight)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveRight);
		}
		else
		{
			keyboardP2.MoveRight = MoveUpNew;
		}
	}
	if (select_main == 2 && select_subB == 8 && int(phim) == 13)
	{
		char MoveDownNew = _getch();
		if (MoveDownNew == keyboardP2.MoveUp)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveUp);
		}
		else if (MoveDownNew == keyboardP2.MoveLeft)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveLeft);
		}
		else if (MoveDownNew == keyboardP2.MoveRight)
		{
			swap(keyboardP2.MoveUp, keyboardP2.MoveRight);
		}
		else if (MoveDownNew == keyboard.MoveUp)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveUp);
		}
		else if (MoveDownNew == keyboard.MoveDown)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveDown);
		}
		else if (MoveDownNew == keyboard.MoveLeft)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveLeft);
		}
		else if (MoveDownNew == keyboard.MoveRight)
		{
			swap(keyboardP2.MoveUp, keyboard.MoveRight);
		}
		else
		{
			keyboardP2.MoveRight = MoveDownNew;
		}
	}
}

void turnOnOffMusic(int x, int y, int ChieuRong, int ChieuDai, int select_main, int select_subA, int soundIG, int soundEF)
{
	char Redlight[1] = { '<' };

	if (soundEF == 1)
	{
		TextColor(242);
		print_Text(Redlight[0], 13, 68);

		TextColor(244);
		print_Text(Redlight[0], 13, 78);
	}
	else
	{
		TextColor(244);
		print_Text(Redlight[0], 13, 68);

		TextColor(242);
		print_Text(Redlight[0], 13, 78);
	}
	if (soundIG == 1)
	{
		TextColor(242);
		print_Text(Redlight[0], 16, 68);

		TextColor(244);
		print_Text(Redlight[0], 16, 78);
	}
	else
	{
		TextColor(244);
		print_Text(Redlight[0], 16, 68);

		TextColor(242);
		print_Text(Redlight[0], 16, 78);
	}
}

void HienThiChonOption(int x, int y, int VungDiChuyen, int ChieuRong, int select_main, int select_subA, int select_subB, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundBG, int& soundEF)
{
	
	HienThiSound(select_main);
	HienThiControlKey(select_main);
	HienThiChonEffect(x, y, VungDiChuyen, ChieuRong, select_main, select_subA);
	HienThiChonSoundBG(x, y, VungDiChuyen, ChieuRong, select_main, select_subA);
	turnOnOffMusic(x, y, VungDiChuyen, ChieuRong, select_main, select_subA, soundBG, soundEF);

	TextColor(240);
	gotoXY(72, 14); cout << "ON"; gotoXY(82, 14); cout << "OFF";
	gotoXY(72, 17); cout << "ON"; gotoXY(82, 17); cout << "OFF";

	HienThiP1MoveLeft(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboard);
	HienThiP1MoveRight(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboard);
	HienThiP1MoveUp(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboard);
	HienThiP1MoveDown(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboard);

	HienThiP2MoveLeft(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboardP2);
	HienThiP2MoveRight(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboardP2);
	HienThiP2MoveUp(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboardP2);
	HienThiP2MoveDown(x, y, VungDiChuyen, ChieuRong, select_main, select_subB, keyboardP2);
}

void MenuConfig(int x, int y, int VungDiChuyen, int ChieuRong, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundBG, int& soundEF)
{
	system("cls");
	resizeConsole(890, 840);
	system("color 8F");
	VeVien(x, y, VungDiChuyen, ChieuRong);
	VeTieuDeOption(x, y, VungDiChuyen, ChieuRong);

	//Vẽ các ô chọn option
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);

		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen - 15, i); std::cout << char(219);
	}
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong; j++)
		{
			// Vẽ nền trắng bên trong
			TextColor(15);
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = y + 11; i <= ChieuRong - 5; i++)
	{
		//Vẽ cạnh dọc giữa
		TextColor(240);
		gotoXY(x + 41, i); std::cout << char(186);
	}
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		//Vẽ cạnh ngang giữa
		gotoXY(i, y + 17); std::cout << char(205);
		gotoXY(i, y + 37); std::cout << char(205);
	}
	gotoXY(45, 19); cout << char(206); //Vẽ dấu liên kết
	gotoXY(45, 39); cout << char(207); //Vẽ dấu liên kết dưới
	gotoXY(30, 41); cout << "<" << (char)toupper(keyboard.MoveUp) << "/" << (char)toupper(keyboard.MoveDown) << "> TO MOVE UP / DOWN, <" << (char)toupper(keyboard.MoveLeft) << "/" << (char)toupper(keyboard.MoveRight) << "> TO MOVE LEFT / RIGHT";
	gotoXY(30, 43); cout << "GET IN CONFIG SECTION, USE <" << (char)toupper(keyboard.MoveRight) << ">. TO RETURN, USE <" << (char)toupper(keyboard.MoveLeft) << ">";

	bool getAnyKey = false;
	bool Lock_choice = false;
	int select_main = 1;
	int select_subA = 1; //For sound setting
	int select_subB = 1; //for key setting

	HienThiChonOption(x, y, VungDiChuyen, ChieuRong, select_main, select_subA, select_subB, keyboard, keyboardP2, soundBG, soundEF);
	while (getAnyKey == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == keyboard.MoveUp && Lock_choice == false)
			{
				select_main--;
			}
			if (phim == keyboard.MoveDown && Lock_choice == false)
			{
				select_main++;
			}
			if (phim == keyboard.MoveRight && Lock_choice == false)
			{
				Lock_choice = true;
			}
			if (phim == keyboard.MoveLeft && Lock_choice == true)
			{
				Lock_choice = false;
			}
			if (phim == keyboard.MoveUp && select_main == 1 && Lock_choice == true)
			{
				select_subA--;
			}
			if (phim == keyboard.MoveUp && select_main == 2 && Lock_choice == true)
			{
				select_subB--;
			}
			if (phim == keyboard.MoveDown && select_main == 1 && Lock_choice == true)
			{
				select_subA++;
			}
			if (phim == keyboard.MoveDown && select_main == 2 && Lock_choice == true)
			{
				select_subB++;
			}
			if (int(phim) == 13 && select_main == 1 && select_subA == 1)
			{
				if (soundEF == 0)
				{
					soundEF = 1;
				}
				else if (soundEF == 1)
				{
					soundEF = 0;
				}
			}
			if (int(phim) == 13 && select_main == 1 && select_subA == 2)
			{
				if (soundBG == 0)
				{
					soundBG = 1;
				}
				else if (soundBG == 1)
				{
					soundBG = 0;
				}
			}
			if (select_main > 2)
			{
				select_main = 1;
			}
			if (select_main < 1)
			{
				select_main = 2;
			}
			if (select_subA > 2)
			{
				select_subA = 1;
			}
			if (select_subA < 1)
			{
				select_subA = 2;
			}
			if (select_subB > 8)
			{
				select_subB = 1;
			}
			if (select_subB < 1)
			{
				select_subB = 8;
			}
			ChangeControlKey(phim, select_main, select_subA, select_subB, keyboard, keyboardP2);
			HienThiChonOption(x, y, VungDiChuyen, ChieuRong, select_main, select_subA, select_subB, keyboard, keyboardP2, soundBG, soundEF);
			turnOnOffMusic(x, y, VungDiChuyen, ChieuRong, select_main, select_subA, soundBG, soundEF);
			if (phim == char(27))
			{
				getAnyKey = true;
			}
		}
	}
}

void HuongDanChoi(int x, int y, int VungDiChuyen, int ChieuRong, MoveKeyBoard keyboardP1, MoveKeyBoard keyboardP2)
{
	system("cls");
	resizeConsole(890, 840);
	system("color 8F");
	VeVien(x, y, VungDiChuyen, ChieuRong);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong - 15; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(204);
	for (int i = x + 29; i <= VungDiChuyen - 24; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 30; i <= VungDiChuyen - 25; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(33, 6); cout << char(201);
	gotoXY(74, 6); cout << char(187);
	gotoXY(33, 10); cout << char(200);
	gotoXY(74, 10); cout << char(188);

	char guide[5] = { 'g', 'u', 'i', 'd', 'e' };
	TextColor(206);
	print_Text(guide[0], 7, 45);
	print_Text(guide[1], 7, 50);
	print_Text(guide[2], 7, 54);
	print_Text(guide[3], 7, 56);
	print_Text(guide[4], 7, 60);

	TextColor(240);
	gotoXY(22, 14); cout << "Let's control your snake to eat food and gain the highest score!";
	gotoXY(22, 15); cout << "When reaching the enough score, the gateway will appears leading";
	gotoXY(35, 16); cout << "to the new and more challenging map!";

	TextColor(244);
	gotoXY(48, 18); cout << "Milestone";
	gotoXY(36, 19); cout << "Only used for mode 2, 3: Adventure";
	gotoXY(22, 27); cout << "Notes:";
	gotoXY(40, 21); cout << char(4); gotoXY(40, 23); cout << char(4); gotoXY(40, 25); cout << char(4);
	gotoXY(40, 22); cout << char(4); gotoXY(40, 24); cout << char(4);

	TextColor(240);
	gotoXY(43, 21); cout << "Level 1: 300 scores";
	gotoXY(43, 22); cout << "Level 2: 800 scores";
	gotoXY(43, 23); cout << "Level 3: 1500 scores";
	gotoXY(43, 24); cout << "Level 4: 3000 scores";
	gotoXY(43, 25); cout << "Level 5: 5000 scores";
	gotoXY(28, 27); cout << "You should avoid the wall. If not, your snake will die!";

	TextColor(204);
	for (int i = x + 29; i <= VungDiChuyen - 24; i++)
	{
		for (int j = y + 30; j <= ChieuRong - 8; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 30; i <= ChieuRong - 8; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 30; i <= VungDiChuyen - 25; i++)
	{
		gotoXY(i, 32); cout << char(205);
		gotoXY(i, 36); cout << char(205);
	}
	gotoXY(33, 32); cout << char(201);
	gotoXY(74, 32); cout << char(187);
	gotoXY(33, 36); cout << char(200);
	gotoXY(74, 36); cout << char(188);

	char key[8] = { 'k', 'e', 'y', 'b', 'o', 'a', 'r','d' };
	TextColor(206);
	print_Text(key[0], 33, 38);
	print_Text(key[1], 33, 42);
	print_Text(key[2], 33, 46);
	print_Text(key[3], 33, 52);
	print_Text(key[4], 33, 56);
	print_Text(key[5], 33, 60);
	print_Text(key[6], 33, 64);
	print_Text(key[7], 33, 68);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 36); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong + 2); std::cout << char(220);
	}
	for (int i = y + 36; i <= ChieuRong + 4; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		for (int j = y + 37; j <= ChieuRong + 3; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = y + 37; i <= ChieuRong + 3; i++)
	{
		gotoXY(x + 31, i); std::cout << char(179);
		gotoXY(x + 49, i); std::cout << char(179);
		gotoXY(x + 67, i); std::cout << char(179);
	}
	for (int i = x + 16; i <= VungDiChuyen - 12; i++)
	{
		gotoXY(i, y + 40); std::cout << char(205);
		gotoXY(i, y + 44); std::cout << char(205);
	}
	gotoXY(21, 40); cout << (char)toupper(keyboardP1.MoveLeft) << ":P1 Move Left";
	gotoXY(37, 40); cout << (char)toupper(keyboardP1.MoveRight) << ":P1 Move Right";
	gotoXY(55, 40); cout << (char)toupper(keyboardP1.MoveDown) << ":P1 Move Down";
	gotoXY(73, 40); cout << (char)toupper(keyboardP1.MoveUp) << ":P1 Move Up";

	gotoXY(21, 44); cout << (char)toupper(keyboardP2.MoveLeft) << ":P2 Move Left";
	gotoXY(37, 44); cout << (char)toupper(keyboardP2.MoveRight) << ":P2 Move Right";
	gotoXY(55, 44); cout << (char)toupper(keyboardP2.MoveDown) << ":P2 Move Down";
	gotoXY(73, 44); cout << (char)toupper(keyboardP2.MoveUp) << ":P2 Move Up";

	gotoXY(25, 47); cout << "P: Pause/Options/Guide";
	gotoXY(65, 47); cout << "Enter: Choose";

	bool getAnyKey = false;
	while (getAnyKey == false)
	{
		if (_kbhit())
		{
			getAnyKey = true;
		}
	}
}

void Nut_Return(int x, int y, int VungBangDiem, int ChieuRong, bool paused, int selection)
{
	//KHUNG RETURN 
	char symbol[1] = { '?' };
	if (paused == true && selection == 1)
	{
		TextColor(238);
		for (int i = x; i <= VungBangDiem - 86; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x, i); std::cout << char(219);
			gotoXY(x + 9, i); std::cout << char(219);
		}
	}
	else if (paused == true && selection == 2)
	{
		TextColor(238);
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 9, i); std::cout << char(219);
		}
		TextColor(240);
		for (int i = x; i <= VungBangDiem - 86; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x, i); std::cout << char(219);
		}
	}
	else if (paused == true)
	{
		TextColor(240);
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 9, i); std::cout << char(219);
		}
		for (int i = x; i <= VungBangDiem - 86; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x, i); std::cout << char(219);
			gotoXY(x + 9, i); std::cout << char(219);
		}
	}
	TextColor(136);
	for (int i = x; i <= x + 7; i++) //x + 29
	{
		for (int j = ChieuRong; j <= ChieuRong + 4; j++)
		{
			gotoXY(i + 1, j + 3); std::cout << char(219);
		}
	}
	TextColor(139);
	print_Text(symbol[0], 48, 5);
}

void Nut_Option(int x, int y, int VungBangDiem, int ChieuRong, bool paused, int selection)
{
	if (paused == true && selection == 2)
	{
		TextColor(238);
		for (int i = x + 9; i <= VungBangDiem - 62; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 9, i); std::cout << char(219);
			gotoXY(x + 33, i); std::cout << char(219);
		}
	}
	else if (paused == true && selection == 3)
	{
		TextColor(238);
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 33, i); std::cout << char(219);
		}
		TextColor(240);
		for (int i = x + 9; i <= VungBangDiem - 62; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 9, i); std::cout << char(219);
		}
	}
	else if (paused == true)
	{
		TextColor(240);
		for (int i = x + 9; i <= VungBangDiem - 62; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 9, i); std::cout << char(219);
			gotoXY(x + 33, i); std::cout << char(219);
		}
	}
	TextColor(204);
	for (int i = x + 1; i <= x + 23; i++) //x + 29
	{
		for (int j = ChieuRong + 3; j <= ChieuRong + 7; j++)
		{
			gotoXY(i + 9, j); std::cout << char(219);
		}
	}
	TextColor(199);
	char option[6] = { 'o', 'p', 't', 'i', 'o', 'n' };
	print_Text(option[0], 48, 15);
	print_Text(option[1], 48, 19);
	print_Text(option[2], 48, 23);
	print_Text(option[3], 48, 27);
	print_Text(option[4], 48, 29);
	print_Text(option[5], 48, 33);
}

void Nut_Guide(int x, int y, int VungBangDiem, int ChieuRong, bool paused, int selection)
{
	//KHUNG GUIDE
	if (paused == true && selection == 3)
	{
		TextColor(238);
		// Vẽ 2 thanh ngang
		for (int i = x + 34; i <= VungBangDiem - 41; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		//Vẽ 2 thanh dọc
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 33, i); std::cout << char(219);
			gotoXY(x + 54, i); std::cout << char(219);
		}
	}
	else
	{
		TextColor(240);
		// Vẽ 2 thanh ngang
		for (int i = x + 34; i <= VungBangDiem - 41; i++)
		{
			gotoXY(i, ChieuRong + 2); std::cout << char(219);
			gotoXY(i, ChieuRong + 8); std::cout << char(219);
		}
		//Vẽ 2 thanh dọc
		for (int i = ChieuRong + 2; i <= ChieuRong + 8; i++)
		{
			gotoXY(x + 33, i); std::cout << char(219);
			gotoXY(x + 54, i); std::cout << char(219);
		}
	}
	TextColor(221);
	for (int i = x + 34; i <= VungBangDiem - 41; i++) //x + 29
	{
		for (int j = ChieuRong + 3; j <= ChieuRong + 7; j++)
		{
			gotoXY(i, j); std::cout << char(219);
		}
	}
	TextColor(219);
	char guide[5] = { 'g', 'u', 'i', 'd', 'e' };
	print_Text(guide[0], 48, 39);
	print_Text(guide[1], 48, 44);
	print_Text(guide[2], 48, 48);
	print_Text(guide[3], 48, 50);
	print_Text(guide[4], 48, 54);
}

void HienthiMenuPause(int x, int y, int ChieuDai, int ChieuRong, bool paused, int selection)
{
	Nut_Guide(x, y, ChieuDai, ChieuRong, paused, selection);
	Nut_Option(x, y, ChieuDai, ChieuRong, paused, selection);
	Nut_Return(x, y, ChieuDai, ChieuRong, paused, selection);
}

void HienThiOptionMenu(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(204);
	for (int i = x + 29; i <= ChieuDai - 24; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 30; i <= ChieuDai - 25; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(33, 6); cout << char(201);
	gotoXY(74, 6); cout << char(187);
	gotoXY(33, 10); cout << char(200);
	gotoXY(74, 10); cout << char(188);

	char game_menu[8] = { 'g', 'a', 'm', 'e', 'm', 'e', 'n', 'u'};
	TextColor(206);
	print_Text(game_menu[0], 7, 35);
	print_Text(game_menu[1], 7, 40);
	print_Text(game_menu[2], 7, 44);
	print_Text(game_menu[3], 7, 50);
	print_Text(game_menu[4], 7, 56);
	print_Text(game_menu[5], 7, 62);
	print_Text(game_menu[6], 7, 66);
	print_Text(game_menu[7], 7, 70);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
		//Vẽ các cạnh giữa
		gotoXY(i, y + 15); std::cout << char(205);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ các cạnh giữa
		gotoXY(i, y + 16); std::cout << char(205);
		gotoXY(i, y + 22); std::cout << char(205);
		gotoXY(i, y + 28); std::cout << char(205);
		gotoXY(i, y + 34); std::cout << char(205);
		gotoXY(i, y + 40); std::cout << char(205);
	}
	gotoXY(37, 43); cout << "PRESS <W>/<S> TO MOVE UP/ DOWN";
	gotoXY(41, 44); cout<< "PRESS <ENTER> TO CHOOSE";
}

void HienThiOptionMainMenu(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(204);
	for (int i = x + 24; i <= ChieuDai - 19; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(28, i); cout << char(186);
		gotoXY(79, i); cout << char(186);
	}
	for (int i = x + 25; i <= ChieuDai - 20; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(28, 6); cout << char(201);
	gotoXY(79, 6); cout << char(187);
	gotoXY(28, 10); cout << char(200);
	gotoXY(79, 10); cout << char(188);

	char game_title[12] = { 'h', 'u', 'n', 't', 'i', 'n', 'g', 's', 'n', 'a', 'k', 'e'};
	TextColor(206);
	print_Text(game_title[0], 7, 30);
	print_Text(game_title[1], 7, 34);
	print_Text(game_title[2], 7, 38);
	print_Text(game_title[3], 7, 42);
	print_Text(game_title[4], 7, 46);
	print_Text(game_title[5], 7, 48);
	print_Text(game_title[6], 7, 52);
	print_Text(game_title[7], 7, 59);
	print_Text(game_title[8], 7, 63);
	print_Text(game_title[9], 7, 67);
	print_Text(game_title[10], 7, 71);
	print_Text(game_title[11], 7, 75);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
		//Vẽ các cạnh giữa
		gotoXY(i, y + 15); std::cout << char(205);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ các cạnh giữa
		gotoXY(i, y + 16); std::cout << char(205);
		gotoXY(i, y + 22); std::cout << char(205);
		gotoXY(i, y + 28); std::cout << char(205);
		gotoXY(i, y + 34); std::cout << char(205);
		gotoXY(i, y + 40); std::cout << char(205);
	}
	gotoXY(37, 43); cout << "PRESS <W>/<S> TO MOVE UP/ DOWN";
	gotoXY(41, 44); cout << "PRESS <ENTER> TO CHOOSE";
}

void Nut_Resume(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	if (selection == 1)
	{
		TextColor(244);
		char resume[6] = { 'r', 'e', 's', 'u', 'm', 'e' };
		print_Text(resume[0], 14, 43);
		print_Text(resume[1], 14, 47);
		print_Text(resume[2], 14, 51);
		print_Text(resume[3], 14, 55);
		print_Text(resume[4], 14, 59);
		print_Text(resume[5], 14, 65);

		DeleteSymbolSnakeChoosing(13, 20);
		PrintSymbolSnakeChoosing(13, 20);
	}
	else
	{
		TextColor(246);
		char resume[6] = { 'r', 'e', 's', 'u', 'm', 'e' };
		print_Text(resume[0], 14, 43);
		print_Text(resume[1], 14, 47);
		print_Text(resume[2], 14, 51);
		print_Text(resume[3], 14, 55);
		print_Text(resume[4], 14, 59);
		print_Text(resume[5], 14, 65);

		DeleteSymbolSnakeChoosing(13, 20);
		PrintSymbolSnakeIdle(13, 20);
	}
}

void Nut_NewGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	if (selection == 2)
	{
		TextColor(244);
		char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
		print_Text(newgame[0], 20, 43);
		print_Text(newgame[1], 20, 47);
		print_Text(newgame[2], 20, 51);
		print_Text(newgame[3], 20, 57);
		print_Text(newgame[4], 20, 62);
		print_Text(newgame[5], 20, 66);
		print_Text(newgame[6], 20, 72);

		DeleteSymbolSnakeChoosing(19, 20);
		PrintSymbolSnakeChoosing(19, 20);
	}
	else
	{
		TextColor(246);
		char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
		print_Text(newgame[0], 20, 43);
		print_Text(newgame[1], 20, 47);
		print_Text(newgame[2], 20, 51);
		print_Text(newgame[3], 20, 57);
		print_Text(newgame[4], 20, 62);
		print_Text(newgame[5], 20, 66);
		print_Text(newgame[6], 20, 72);

		DeleteSymbolSnakeChoosing(19, 20);
		PrintSymbolSnakeIdle(19, 20);
	}
}

void Nut_OptionGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char option[6] = { 'o', 'p', 't', 'i', 'o', 'n' };
	if (selection == 3)
	{
		TextColor(244);
		print_Text(option[0], 26, 43);
		print_Text(option[1], 26, 47);
		print_Text(option[2], 26, 51);
		print_Text(option[3], 26, 55);
		print_Text(option[4], 26, 57);
		print_Text(option[5], 26, 61);

		DeleteSymbolSnakeChoosing(25, 20);
		PrintSymbolSnakeChoosing(25, 20);
	}
	else
	{
		TextColor(246);
		print_Text(option[0], 26, 43);
		print_Text(option[1], 26, 47);
		print_Text(option[2], 26, 51);
		print_Text(option[3], 26, 55);
		print_Text(option[4], 26, 57);
		print_Text(option[5], 26, 61);

		DeleteSymbolSnakeChoosing(25, 20);
		PrintSymbolSnakeIdle(25, 20);
	}
}

void Nut_SaveGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char savegame[8] = { 's', 'a', 'v', 'e' };
	if (selection == 4)
	{
		TextColor(244);
		print_Text(savegame[0], 32, 43);
		print_Text(savegame[1], 32, 47);
		print_Text(savegame[2], 32, 51);
		print_Text(savegame[3], 32, 56);

		DeleteSymbolSnakeChoosing(31, 20);
		PrintSymbolSnakeChoosing(31, 20);
	}
	else
	{
		TextColor(246);
		print_Text(savegame[0], 32, 43);
		print_Text(savegame[1], 32, 47);
		print_Text(savegame[2], 32, 51);
		print_Text(savegame[3], 32, 56);

		DeleteSymbolSnakeChoosing(31, 20);
		PrintSymbolSnakeIdle(31, 20);
	}
}

void Nut_ExitGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char exitgame[8] = { 'e', 'x', 'i', 't' };
	if (selection == 5)
	{
		TextColor(244);
		print_Text(exitgame[0], 38, 43);
		print_Text(exitgame[1], 38, 47);
		print_Text(exitgame[2], 38, 53);
		print_Text(exitgame[3], 38, 55);

		DeleteSymbolSnakeChoosing(37, 20);
		PrintSymbolSnakeChoosing(37, 20);
	}
	else
	{
		TextColor(246);
		print_Text(exitgame[0], 38, 43);
		print_Text(exitgame[1], 38, 47);
		print_Text(exitgame[2], 38, 53);
		print_Text(exitgame[3], 38, 55);

		DeleteSymbolSnakeChoosing(37, 20);
		PrintSymbolSnakeIdle(37, 20);
	}
}

void HienThiSelectOption(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	Nut_Resume(x, y, ChieuDai, ChieuRong, selection);
	Nut_NewGame(x, y, ChieuDai, ChieuRong, selection);
	Nut_OptionGame(x, y, ChieuDai, ChieuRong, selection);
	Nut_SaveGame(x, y, ChieuDai, ChieuRong, selection);
	Nut_ExitGame(x, y, ChieuDai, ChieuRong, selection);
}

void Nut_NewGameMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	if (selection == 1)
	{
		TextColor(244);
		char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
		print_Text(newgame[0], 14, 43);
		print_Text(newgame[1], 14, 47);
		print_Text(newgame[2], 14, 51);
		print_Text(newgame[3], 14, 57);
		print_Text(newgame[4], 14, 62);
		print_Text(newgame[5], 14, 66);
		print_Text(newgame[6], 14, 72);

		DeleteSymbolSnakeChoosing(13, 20);
		PrintSymbolSnakeChoosing(13, 20);
	}
	else
	{
		TextColor(246);
		char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
		print_Text(newgame[0], 14, 43);
		print_Text(newgame[1], 14, 47);
		print_Text(newgame[2], 14, 51);
		print_Text(newgame[3], 14, 57);
		print_Text(newgame[4], 14, 62);
		print_Text(newgame[5], 14, 66);
		print_Text(newgame[6], 14, 72);

		DeleteSymbolSnakeChoosing(13, 20);
		PrintSymbolSnakeIdle(13, 20);
	}
}

void Nut_LoadGameMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	if (selection == 2)
	{
		TextColor(244);
		char loadgame[8] = { 'l', 'o', 'a', 'd', 'g', 'a', 'm', 'e' };
		print_Text(loadgame[0], 20, 43);
		print_Text(loadgame[1], 20, 47);
		print_Text(loadgame[2], 20, 51);
		print_Text(loadgame[3], 20, 55);
		print_Text(loadgame[4], 20, 59);
		print_Text(loadgame[5], 20, 64);
		print_Text(loadgame[6], 20, 68);
		print_Text(loadgame[7], 20, 74);

		DeleteSymbolSnakeChoosing(19, 20);
		PrintSymbolSnakeChoosing(19, 20);
	}
	else
	{
		TextColor(246);
		char loadgame[8] = { 'l', 'o', 'a', 'd', 'g', 'a', 'm', 'e' };
		print_Text(loadgame[0], 20, 43);
		print_Text(loadgame[1], 20, 47);
		print_Text(loadgame[2], 20, 51);
		print_Text(loadgame[3], 20, 55);
		print_Text(loadgame[4], 20, 59);
		print_Text(loadgame[5], 20, 64);
		print_Text(loadgame[6], 20, 68);
		print_Text(loadgame[7], 20, 74);

		DeleteSymbolSnakeChoosing(19, 20);
		PrintSymbolSnakeIdle(19, 20);
	}
}

void Nut_OptionGameMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char option[6] = { 'o', 'p', 't', 'i', 'o', 'n' };
	if (selection == 3)
	{
		TextColor(244);
		print_Text(option[0], 26, 43);
		print_Text(option[1], 26, 47);
		print_Text(option[2], 26, 51);
		print_Text(option[3], 26, 55);
		print_Text(option[4], 26, 57);
		print_Text(option[5], 26, 61);

		DeleteSymbolSnakeChoosing(25, 20);
		PrintSymbolSnakeChoosing(25, 20);
	}
	else
	{
		TextColor(246);
		print_Text(option[0], 26, 43);
		print_Text(option[1], 26, 47);
		print_Text(option[2], 26, 51);
		print_Text(option[3], 26, 55);
		print_Text(option[4], 26, 57);
		print_Text(option[5], 26, 61);

		DeleteSymbolSnakeChoosing(25, 20);
		PrintSymbolSnakeIdle(25, 20);
	}
}

void Nut_AboutMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char about[5] = { 'a', 'b', 'o', 'u', 't' };
	if (selection == 4)
	{
		TextColor(244);
		print_Text(about[0], 32, 43);
		print_Text(about[1], 32, 47);
		print_Text(about[2], 32, 51);
		print_Text(about[3], 32, 55);
		print_Text(about[4], 32, 59);

		DeleteSymbolSnakeChoosing(31, 20);
		PrintSymbolSnakeChoosing(31, 20);
	}
	else
	{
		TextColor(246);
		print_Text(about[0], 32, 43);
		print_Text(about[1], 32, 47);
		print_Text(about[2], 32, 51);
		print_Text(about[3], 32, 55);
		print_Text(about[4], 32, 59);

		DeleteSymbolSnakeChoosing(31, 20);
		PrintSymbolSnakeIdle(31, 20);
	}
}


void Nut_ExitGameMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char exitgame[8] = { 'e', 'x', 'i', 't' };
	if (selection == 5)
	{
		TextColor(244);
		print_Text(exitgame[0], 38, 43);
		print_Text(exitgame[1], 38, 47);
		print_Text(exitgame[2], 38, 53);
		print_Text(exitgame[3], 38, 55);

		DeleteSymbolSnakeChoosing(37, 20);
		PrintSymbolSnakeChoosing(37, 20);
	}
	else
	{
		TextColor(246);
		print_Text(exitgame[0], 38, 43);
		print_Text(exitgame[1], 38, 47);
		print_Text(exitgame[2], 38, 53);
		print_Text(exitgame[3], 38, 55);

		DeleteSymbolSnakeChoosing(37, 20);
		PrintSymbolSnakeIdle(37, 20);
	}
}

void HienThiSelectMainMenu(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	Nut_NewGameMainMenu(x, y, ChieuDai, ChieuRong, selection);
	Nut_LoadGameMainMenu(x, y, ChieuDai, ChieuRong, selection);
	Nut_OptionGameMainMenu(x, y, ChieuDai, ChieuRong, selection);
	Nut_AboutMainMenu(x, y, ChieuDai, ChieuRong, selection);
	Nut_ExitGameMainMenu(x, y, ChieuDai, ChieuRong, selection);
}

int LogicOptionMenu(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	HienThiSelectOption(x, y, ChieuDai, ChieuRong, select);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 2;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 3)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 3;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 4)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 4;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 5)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 5;
				inputChoice = true;
			}
			if (phim == 's')
			{
				select++;
			}
			if (phim == 'w')
			{
				select--;
			}
			if (select < 1)
			{
				select = 5;
			}
			if (select > 5)
			{
				select = 1;
			}
			HienThiSelectOption(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

int LogicOptionMainMenu(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	HienThiSelectMainMenu(x, y, ChieuDai, ChieuRong, select);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 2;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 3)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 3;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 4)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 4;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 5)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 5;
				inputChoice = true;
			}
			if (phim == 's')
			{
				select++;
			}
			if (phim == 'w')
			{
				select--;
			}
			if (select < 1)
			{
				select = 5;
			}
			if (select > 5)
			{
				select = 1;
			}
			HienThiSelectMainMenu(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

void VeVienMenu(int x, int y, int VungDiChuyen, int ChieuRong)
{
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x - 4; i <= VungDiChuyen + 8; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y - 2); std::cout << char(219);
		//Vẽ cạnh dưới
		gotoXY(i, y + ChieuRong + 8); std::cout << char(219);
	}
	for (int i = y - 2; i <= ChieuRong + 9; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x - 3, i); std::cout << char(219);
		gotoXY(x - 4, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen + 3, i); std::cout << char(219);
		gotoXY(x + VungDiChuyen + 4, i); std::cout << char(219);
	}
	//Vẽ viền đen bên trong
	for (int i = x; i <= VungDiChuyen + 3; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y); std::cout << char(219);
		gotoXY(i, y + ChieuRong + 6); std::cout << char(219);
	}
	//Vẽ cạnh trái - cạnh phải - cạnh phân chia vùng rắn di chuyển và bảng điểm
	for (int i = y; i <= ChieuRong + 8; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen, i); std::cout << char(219);
	}
	TextColor(134); //187
	for (int i = x - 2; i <= VungDiChuyen + 6; i++)
	{
		//Vẽ cạnh trên
		gotoXY(i, y - 1); std::cout << char(219);
		//Vẽ cạnh dưới
		gotoXY(i, y + ChieuRong + 7); std::cout << char(219);
	}
	for (int i = y; i <= ChieuRong + 8; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x - 1, i); std::cout << char(219);
		gotoXY(x - 2, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + VungDiChuyen + 1, i); std::cout << char(219);
		gotoXY(x + VungDiChuyen + 2, i); std::cout << char(219);
	}
}

void VeDuoiRanPhai()
{
	char RightSnakeTail[5][5] = { " " };
	RightSnakeTail[0][4] = char(219);
	RightSnakeTail[1][4] = char(219);
	RightSnakeTail[2][4] = char(219);
	RightSnakeTail[3][4] = RightSnakeTail[3][3] = char(219); RightSnakeTail[3][2] = RightSnakeTail[3][1] = RightSnakeTail[3][0] = char(220);
	RightSnakeTail[4][4] = RightSnakeTail[4][3] = RightSnakeTail[4][2] = RightSnakeTail[4][1] = RightSnakeTail[4][0] = char(223);

	TextColor(10);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(102 + j, 48 + i);
			cout << RightSnakeTail[i][j];
		}
	}
}

void VeThanRanPhai()
{
	char RightSnakeBody[13][10] = { " " };
	RightSnakeBody[3][4] = char(219);
	RightSnakeBody[4][4] = RightSnakeBody[4][3] = char(219);
	RightSnakeBody[5][5] = char(221); RightSnakeBody[5][4] = RightSnakeBody[5][3] = RightSnakeBody[5][2] = char(219);
	RightSnakeBody[6][5] = RightSnakeBody[6][4] = RightSnakeBody[6][3] = RightSnakeBody[6][2] = char(219);
	RightSnakeBody[7][6] = RightSnakeBody[7][5] = RightSnakeBody[7][4] = RightSnakeBody[7][3] = RightSnakeBody[7][2] = char(219);
	RightSnakeBody[8][8] = char(221); RightSnakeBody[8][7] = RightSnakeBody[8][6] = RightSnakeBody[8][5] = RightSnakeBody[8][4] = RightSnakeBody[8][3] = char(219);
	RightSnakeBody[9][9] = char(221); RightSnakeBody[9][8] = RightSnakeBody[9][7] = RightSnakeBody[9][6] = RightSnakeBody[9][5] = RightSnakeBody[9][4] = char(219);
	RightSnakeBody[10][9] = RightSnakeBody[10][8] = char(219); RightSnakeBody[10][7] = RightSnakeBody[10][6] = char(223);
	RightSnakeBody[11][9] = char(219); RightSnakeBody[11][8] = char(223);
	RightSnakeBody[12][9] = char(219);

	for (int i = 12; i > 0; i--)
	{
		for (int j = 9; j > 0; j--)
		{
			gotoXY(97 + j, 35 + i);
			cout << RightSnakeBody[i][j];
		}
	}

	for (int i = 12; i > 0; i--)
	{
		for (int j = 9; j > 0; j--)
		{
			gotoXY(97 + j, 24 + i);
			cout << RightSnakeBody[i][j];
		}
	}

	for (int i = 12; i > 0; i--)
	{
		for (int j = 9; j > 0; j--)
		{
			gotoXY(97 + j, 13 + i);
			cout << RightSnakeBody[i][j];
		}
	}
}

void VeDuoiRanTrai()
{
	char LeftSnakeTail[5][5] = { " " };
	LeftSnakeTail[0][0] = char(219);
	LeftSnakeTail[1][0] = char(219);
	LeftSnakeTail[2][0] = char(219);
	LeftSnakeTail[3][0] = LeftSnakeTail[3][1] = char(219); LeftSnakeTail[3][2] = LeftSnakeTail[3][3] = LeftSnakeTail[3][4] = char(220);
	LeftSnakeTail[4][0] = LeftSnakeTail[4][1] = LeftSnakeTail[4][2] = LeftSnakeTail[4][3] = LeftSnakeTail[4][4] = char(223);

	TextColor(10);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(0 + j, 48 + i);
			cout << LeftSnakeTail[i][j];
		}
	}
}

void VeThanRanTrai()
{
	char LeftSnakeBody[20][10] = { " " };
	LeftSnakeBody[3][5] = char(219);
	LeftSnakeBody[4][5] = LeftSnakeBody[4][6] = char(219);
	LeftSnakeBody[5][4] = char(222); LeftSnakeBody[5][5] = LeftSnakeBody[5][6] = LeftSnakeBody[5][7] = char(219);
	LeftSnakeBody[6][4] = LeftSnakeBody[6][5] = LeftSnakeBody[6][6] = LeftSnakeBody[6][7] = char(219);
	LeftSnakeBody[7][3] = LeftSnakeBody[7][4] = LeftSnakeBody[7][5] = LeftSnakeBody[7][6] = LeftSnakeBody[7][7] = char(219);
	LeftSnakeBody[8][1] = char(222); LeftSnakeBody[8][2] = LeftSnakeBody[8][3] = LeftSnakeBody[8][4] = LeftSnakeBody[8][5] = LeftSnakeBody[8][6] = char(219);
	LeftSnakeBody[9][0] = char(222); LeftSnakeBody[9][1] = LeftSnakeBody[9][2] = LeftSnakeBody[9][3] = LeftSnakeBody[9][4] = LeftSnakeBody[9][5] = char(219);
	LeftSnakeBody[10][0] = LeftSnakeBody[10][1] = char(219); LeftSnakeBody[10][2] = LeftSnakeBody[10][3] = char(223);
	LeftSnakeBody[11][0] = char(219); LeftSnakeBody[11][1] = char(223);
	LeftSnakeBody[12][0] = char(219);

	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoXY(0 + j, 35 + i);
			cout << LeftSnakeBody[i][j];
		}
	}

	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoXY(0 + j, 24 + i);
			cout << LeftSnakeBody[i][j];
		}
	}

	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoXY(0 + j, 13 + i);
			cout << LeftSnakeBody[i][j];
		}
	}
}


void VeDauRanPhai()
{
	char RightSnakeHead[10][14] = { " " };
	RightSnakeHead[1][11] = char(221);
	RightSnakeHead[1][10] = RightSnakeHead[1][9] = RightSnakeHead[1][8] = RightSnakeHead[1][7] = char(219);
	RightSnakeHead[1][6] = char(219);

	RightSnakeHead[2][12] = char(221);
	RightSnakeHead[2][11] = RightSnakeHead[2][10] = RightSnakeHead[2][9] = RightSnakeHead[2][8] = char(219);
	RightSnakeHead[2][7] = RightSnakeHead[2][6] = RightSnakeHead[2][5] = char(219);

	RightSnakeHead[3][12] = RightSnakeHead[3][11] = RightSnakeHead[3][10] = RightSnakeHead[3][9] = char(219);
	RightSnakeHead[3][8] = RightSnakeHead[3][7] = RightSnakeHead[3][6] = RightSnakeHead[3][5] = char(219);
	RightSnakeHead[3][4] = char(219);

	RightSnakeHead[4][12] = RightSnakeHead[4][11] = RightSnakeHead[4][10] = RightSnakeHead[4][9] = char(219);
	RightSnakeHead[4][8] = RightSnakeHead[4][7] = RightSnakeHead[4][6] = RightSnakeHead[4][5] = char(219);
	RightSnakeHead[4][4] = RightSnakeHead[4][3] = char(219);

	RightSnakeHead[5][12] = RightSnakeHead[5][11] = RightSnakeHead[5][10] = RightSnakeHead[5][9] = char(219);
	RightSnakeHead[5][8] = RightSnakeHead[5][7] = RightSnakeHead[5][6] = RightSnakeHead[5][5] = char(219);
	RightSnakeHead[5][4] = RightSnakeHead[5][3] = RightSnakeHead[5][2] = char(219);

	RightSnakeHead[6][12] = RightSnakeHead[6][11] = char(219);
	RightSnakeHead[6][10] = RightSnakeHead[6][9] = RightSnakeHead[6][8] = char(223);
	RightSnakeHead[6][7] = RightSnakeHead[6][6] = RightSnakeHead[6][5] = RightSnakeHead[6][4] = char(219);
	RightSnakeHead[6][3] = RightSnakeHead[6][2] = RightSnakeHead[6][1] = char(219);

	RightSnakeHead[7][12] = RightSnakeHead[7][11] = char(219); RightSnakeHead[7][7] = char(221); RightSnakeHead[7][6] = char(219);
	RightSnakeHead[7][5] = RightSnakeHead[7][4] = RightSnakeHead[7][3] = RightSnakeHead[7][2] = RightSnakeHead[7][1] = char(219);

	RightSnakeHead[8][12] = char(219); RightSnakeHead[8][6] = char(221);
	RightSnakeHead[8][5] = RightSnakeHead[8][4] = RightSnakeHead[8][3] = RightSnakeHead[8][2] = RightSnakeHead[8][1] = char(219);

	RightSnakeHead[9][12] = char(219); RightSnakeHead[9][5] = RightSnakeHead[9][4] = RightSnakeHead[9][3] = RightSnakeHead[9][2] = char(223);

	TextColor(10);
	for (int i = 9; i > 0; i--)
	{
		for (int j = 13; j > 0; j--)
		{
			gotoXY(94 + j, 3 + i);
			cout << RightSnakeHead[i][j];
		}
	}
}

void VeLuoiRanPhai()
{
	string SnakeTounge[2][4] = { " " };
	SnakeTounge[0][3] = char(219);
	SnakeTounge[1][3] = SnakeTounge[1][2] = SnakeTounge[1][0] = char(223); SnakeTounge[1][1] = char(219);

	TextColor(132);
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			gotoXY(94 + j, 13 + i);
			cout << SnakeTounge[i][j];
		}
	}
}

void VeDauRanTrai()
{
	char LeftSnakeHead[10][20] = { " " };
	LeftSnakeHead[1][1] = char(222);
	LeftSnakeHead[1][2] = LeftSnakeHead[1][3] = LeftSnakeHead[1][4] = LeftSnakeHead[1][5] = char(219);
	LeftSnakeHead[1][6] = char(219);

	LeftSnakeHead[2][0] = char(222);
	LeftSnakeHead[2][1] = LeftSnakeHead[2][2] = LeftSnakeHead[2][3] = LeftSnakeHead[2][4] = char(219);
	LeftSnakeHead[2][5] = LeftSnakeHead[2][6] = LeftSnakeHead[2][7] = char(219);

	LeftSnakeHead[3][0] = LeftSnakeHead[3][1] = LeftSnakeHead[3][2] = LeftSnakeHead[3][3] = char(219);
	LeftSnakeHead[3][4] = LeftSnakeHead[3][5] = LeftSnakeHead[3][6] = LeftSnakeHead[3][7] = char(219);
	LeftSnakeHead[3][8] = char(219);

	LeftSnakeHead[4][0] = LeftSnakeHead[4][1] = LeftSnakeHead[4][2] = LeftSnakeHead[4][3] = char(219);
	LeftSnakeHead[4][4] = LeftSnakeHead[4][5] = LeftSnakeHead[4][6] = LeftSnakeHead[4][7] = char(219);
	LeftSnakeHead[4][8] = LeftSnakeHead[4][9] = char(219);

	LeftSnakeHead[5][0] = LeftSnakeHead[5][1] = LeftSnakeHead[5][2] = LeftSnakeHead[5][3] = char(219);
	LeftSnakeHead[5][4] = LeftSnakeHead[5][5] = LeftSnakeHead[5][6] = LeftSnakeHead[5][7] = char(219);
	LeftSnakeHead[5][8] = LeftSnakeHead[5][9] = LeftSnakeHead[5][10] = char(219);

	LeftSnakeHead[6][0] = LeftSnakeHead[6][1] = char(219);
	LeftSnakeHead[6][2] = LeftSnakeHead[6][3] = LeftSnakeHead[6][4] = char(223);
	LeftSnakeHead[6][5] = LeftSnakeHead[6][6] = LeftSnakeHead[6][7] = LeftSnakeHead[6][8] = char(219);
	LeftSnakeHead[6][9] = LeftSnakeHead[6][10] = LeftSnakeHead[6][11] = char(219);

	LeftSnakeHead[7][0] = LeftSnakeHead[7][1] = char(219); LeftSnakeHead[7][5] = char(222); LeftSnakeHead[7][6] = char(219);
	LeftSnakeHead[7][7] = LeftSnakeHead[7][8] = LeftSnakeHead[7][9] = LeftSnakeHead[7][10] = LeftSnakeHead[7][11] = char(219);

	LeftSnakeHead[8][0] = char(219); LeftSnakeHead[8][6] = char(222);
	LeftSnakeHead[8][7] = LeftSnakeHead[8][8] = LeftSnakeHead[8][9] = LeftSnakeHead[8][10] = LeftSnakeHead[8][11] = char(219);

	LeftSnakeHead[9][0] = char(219); LeftSnakeHead[9][7] = LeftSnakeHead[9][8] = LeftSnakeHead[9][9] = LeftSnakeHead[9][10] = char(223);

	TextColor(10);
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(0 + j, 3 + i);
			cout << LeftSnakeHead[i][j];
		}
	}
}

void VeLuoiRanTrai()
{
	string SnakeTounge[2][4] = { " " };
	SnakeTounge[0][0] = char(219);
	SnakeTounge[1][0] = SnakeTounge[1][1] = SnakeTounge[1][3] = char(223); SnakeTounge[1][2] = char(219);

	TextColor(132);
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			gotoXY(9 + j, 13 + i);
			cout << SnakeTounge[i][j];
		}
	}
}

void VeMatRanTrai()
{
	string SnakeEye[1][5] = { " " };
	SnakeEye[0][0] = SnakeEye[0][3] = char(219);

	TextColor(133);
	for (int i = 0; i < 1; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(7 + j, 10 + i);
			cout << SnakeEye[i][j];
		}
	}
}

void VeMatRanPhai()
{
	string SnakeEye[1][5] = { " " };
	SnakeEye[0][0] = SnakeEye[0][3] = char(219);

	TextColor(133);
	for (int i = 0; i < 1; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(96 + j, 10 + i);
			cout << SnakeEye[i][j];
		}
	}
}

void VeTrangTriMenu(int x, int y, int VungDiChuyen, int ChieuRong)
{
	//Vẽ rắn bên trái
	VeDuoiRanTrai();
	VeThanRanTrai();
	VeDauRanTrai();
	VeLuoiRanTrai();
	VeMatRanTrai();

	//Vẽ rắn bên phải
	VeDuoiRanPhai();
	VeThanRanPhai();
	VeDauRanPhai();
	VeLuoiRanPhai();
	VeMatRanPhai();
}

int MenuOptionGame(int soundIG, int soundEF)
{
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	system("color 8F");
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionMenu(x, y, ChieuDai, ChieuRong);
	noCursorType(); //Xóa con trỏ(dấu nháy)
	int result = LogicOptionMenu(x, y, ChieuRong, ChieuDai, soundIG, soundEF);
	return result;
}

int MenuOption(int x, int y, int VungDiChuyen, int ChieuRong, bool Paused, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundIG, int& soundEF,
	char* ten_nguoi_choi, int diem, int ran_dot, ToaDo* ran, int SPEED, int huong, int man, int vat_can, ToaDo* vat_can_dong,
	string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int mode)
{
	int choice = -1;
	while (true)
	{
		if (choice == -1)
		{
			system("cls");
			choice = MenuOptionGame(soundIG, soundEF);
		}
		else if (choice == 1)
		{
			return 1;
		}
		else if (choice == 2)
		{
			system("cls");
			return 2;
		}
		else if (choice == 3)
		{
			system("cls");
			MenuConfig(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2, soundIG, soundEF);
			system("cls");
			choice = -1;
		}
		else if (choice == 4)
		{
			system("cls");
			int save = SaveGame(ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, vat_can, vat_can_dong, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
			if (save == 1)
			{
				system("cls");
				choice = -1;
			}
			else if (save == 2)
			{
				system("cls");
				exit(0);
			}
		}
		else if (choice == 5)
		{
			return 5;
		}
	}
}

int MenuOption2(int x, int y, int VungDiChuyen, int ChieuRong, bool Paused, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& soundIG, int& soundEF,
	char* ten_nguoi_choi1, char* ten_nguoi_choi2, int diem1, int diem2, int ran_dot1, ToaDo* ran1, int ran_dot2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man, int vat_can, ToaDo* vat_can_dong,
	string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int mode)
{
	int choice = -1;
	while (true)
	{
		if (choice == -1)
		{
			system("cls");
			choice = MenuOptionGame(soundIG, soundEF);
		}
		else if (choice == 1)
		{
			return 1;
		}
		else if (choice == 2)
		{
			system("cls");
			return 2;
		}
		else if (choice == 3)
		{
			system("cls");
			MenuConfig(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2, soundIG, soundEF);
			system("cls");
			choice = -1;
		}
		else if (choice == 4)
		{
			system("cls");
			int save = SaveGame2(ten_nguoi_choi1, ten_nguoi_choi2, diem1, diem2, ran_dot1, ran1, ran_dot2, ran2, SPEED, huong1, huong2, man, vat_can, vat_can_dong, data, nData, nguoiChoi1, nguoiChoi2, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
			if (save == 1)
			{
				system("cls");
				choice = -1;
			}
			else if (save == 2)
			{
				system("cls");
				exit(0);
			}
		}
		else if (choice == 5)
		{
			return 5;
		}
	}
}


int MenuPause(bool Paused, int soundIG, int soundEF)
{
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	TextColor(204);
	for (int i = x + 29; i <= ChieuDai - 25; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(73, i); cout << char(186);
	}
	for (int i = x + 30; i <= ChieuDai - 26; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(33, 6); cout << char(201);
	gotoXY(73, 6); cout << char(187);
	gotoXY(33, 10); cout << char(200);
	gotoXY(73, 10); cout << char(188);

	char pause_menu[6] = { 'p', 'a', 'u', 's', 'e', 'd' };
	TextColor(206);
	print_Text(pause_menu[0], 7, 42);
	print_Text(pause_menu[1], 7, 46);
	print_Text(pause_menu[2], 7, 50);
	print_Text(pause_menu[3], 7, 54);
	print_Text(pause_menu[4], 7, 58);
	print_Text(pause_menu[5], 7, 62);

	//LOGIC CHỌN MENU PAUSE Ở ĐÂY
	//Đầu tiên tô màu khi con trỏ đang dừng ở một ô
	int cont = MAXINT;
	bool getChoice = false;
	int select = 1;
	HienthiMenuPause(x, y, ChieuDai, ChieuRong, Paused, select);
	while (getChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				cont = 1;
				getChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				cont = 2;
				getChoice = true;
			}
			if (int(phim) == 13 && select == 3)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				cont = 3;
				getChoice = true;
			}
			if (phim == 'a')
			{
				select--;
			}
			if (phim == 'd')
			{
				select++;
			}
			if (select < 1)
			{
				select = 3;
			}
			if (select > 3)
			{
				select = 1;
			}
			HienthiMenuPause(x, y, ChieuDai, ChieuRong, Paused, select);
		}
	}
	Sleep(600);
	return cont;
}

int MainMenu(int soundBG, int soundIG, int soundEF)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionMainMenu(x, y, ChieuDai, ChieuRong);
	int result = LogicOptionMainMenu(x, y, ChieuRong, ChieuDai, soundIG, soundEF);
	return result;
}

void HienThiOptionModeGame(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(204);
	for (int i = x + 29; i <= ChieuDai - 25; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(33, i); cout << char(186);
		gotoXY(73, i); cout << char(186);
	}
	for (int i = x + 30; i <= ChieuDai - 26; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(33, 6); cout << char(201);
	gotoXY(73, 6); cout << char(187);
	gotoXY(33, 10); cout << char(200);
	gotoXY(73, 10); cout << char(188);

	char modegame[8] = { 'g', 'a', 'm', 'e', 'm', 'o', 'd', 'e' };
	TextColor(206);
	print_Text(modegame[0], 7, 35);
	print_Text(modegame[1], 7, 40);
	print_Text(modegame[2], 7, 44);
	print_Text(modegame[3], 7, 50);
	print_Text(modegame[4], 7, 55);
	print_Text(modegame[5], 7, 61);
	print_Text(modegame[6], 7, 65);
	print_Text(modegame[7], 7, 69);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 9); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong - 7; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 8; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh giữa
		gotoXY(i, y + 12); std::cout << char(205);
		gotoXY(i, y + 28); std::cout << char(205);
	}
	gotoXY(53, 30); cout << char(203);
	for (int i = 0; i <= 5; i++)
	{
		gotoXY(53, 31 + i); std::cout << char(186);
	}
	gotoXY(22, 13); cout << "<A/D>:NEXT/BACK, <G>:LEADER BOARD, <ENTER>:SELECT, <ESC>:RETURN";
	TextColor(80);
	//vẽ viền đen bên ngoài chữ LeaderBoard
	for (int i = x + 23; i <= ChieuDai - 19; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 40); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong); std::cout << char(220);
	}
	for (int i = y + 40; i <= ChieuRong + 2; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 22, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 23, i); std::cout << char(219);
	}
	// Vẽ nền tím bên trong chữ LeaderBoard
	TextColor(85);
	for (int i = x + 23; i <= ChieuDai - 20; i++)
	{
		for (int j = y + 41; j <= ChieuRong + 1; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	char leaderBoard[12] = { 'l', 'e', 'a', 'd', 'e', 'r', 'b', 'o', 'a', 'r', 'd', '@' };
	TextColor(91);

	print_Symbol(leaderBoard[11], 28, 43);

	print_Text(leaderBoard[0], 43, 34);
	print_Text(leaderBoard[1], 43, 38);
	print_Text(leaderBoard[2], 43, 42);
	print_Text(leaderBoard[3], 43, 46);
	print_Text(leaderBoard[4], 43, 50);
	print_Text(leaderBoard[5], 43, 54);

	print_Text(leaderBoard[6], 43, 59);
	print_Text(leaderBoard[7], 43, 63);
	print_Text(leaderBoard[8], 43, 67);
	print_Text(leaderBoard[9], 43, 71);
	print_Text(leaderBoard[10], 43, 75);
}

void DeletingSpace(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 15; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 16; i <= ChieuDai - 50; i++)
	{
		for (int j = y + 30; j <= ChieuRong - 8; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 50; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 30; j <= ChieuRong - 8; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
}

void VeChiTiet1PlayerEndless(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[12][22] = { " " };
	snake[0][0] = snake[0][1] = char(223); snake[0][2] = snake[0][3] = snake[0][4] = snake[0][5] = char(219);
	snake[1][4] = snake[1][5] = char(219);
	snake[2][4] = snake[2][5] = char(219);
	snake[3][4] = snake[3][5] = char(219);
	snake[4][4] = snake[4][5] = char(219);
	snake[5][4] = snake[5][5] = char(219);
	snake[6][4] = snake[6][5] = char(219);
	snake[7][4] = snake[7][5] = char(219);
	snake[8][4] = snake[8][5] = char(219);
	snake[9][4] = snake[9][5] = char(219); snake[9][6] = snake[9][7] = char(219);
	snake[10][4] = snake[10][5] = char(219); snake[10][6] = snake[10][7] = char(219);

	snake[1][8] = snake[1][9] = char(219); snake[1][10] = snake[1][11] = char(219);
	snake[2][8] = snake[2][9] = char(219); snake[2][10] = snake[2][11] = char(219);
	snake[3][8] = snake[3][9] = char(219);
	snake[4][8] = snake[4][9] = char(219);
	snake[5][8] = snake[5][9] = char(219);
	snake[6][8] = snake[6][9] = char(219);
	snake[7][8] = snake[7][9] = char(219);
	snake[8][8] = snake[8][9] = char(219);
	snake[9][8] = snake[9][9] = char(219); 
	snake[10][8] = snake[10][9] = char(219); 

	snake[1][12] = snake[1][13] = char(219); 
	snake[2][12] = snake[2][13] = char(219); 
	snake[3][12] = snake[3][13] = char(219);
	snake[4][12] = snake[4][13] = char(219);
	snake[5][12] = snake[5][13] = char(219);
	snake[6][12] = snake[6][13] = char(219);
	snake[7][12] = snake[7][13] = char(219); snake[7][14] = snake[7][15] = char(219);
	snake[8][12] = snake[8][13] = char(219); snake[8][14] = snake[8][15] = char(219);
	snake[3][19] = char(219);  snake[3][20] = char(223); snake[3][21] = char(220);
	snake[4][16] = snake[4][17] = char(219); snake[4][18] = snake[4][19] = snake[4][20] = snake[4][21] = char(219);
	snake[5][16] = snake[5][17] = char(219); snake[5][19] = char(219); snake[5][20] = char(220); snake[5][21] = char(223);
	snake[6][16] = snake[6][17] = char(219);
	snake[7][16] = snake[7][17] = char(219);
	snake[8][16] = snake[8][17] = char(219);

	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			if ((i == 3 && j == 20) || (i == 5 && j == 20))
			{
				TextColor(9);
			}
			else
			{
				TextColor(97);
			}
			gotoXY(x + j, y + i);
			cout << snake[i][j];
		}
	}
}

void VeNen1PlayerEndless(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(102);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
}

void VeChiTiet1PlayerEndless2(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(102);
	char apple[5][5] = { " " };
	apple[0][1] = apple[0][3] = char(223), apple[0][2] = char(220);
	apple[1][0] = char(220); apple[1][1] = apple[1][2] = apple[1][3] = char(219); apple[1][4] = (char)220;
	apple[2][0] = apple[2][1] = apple[2][2] = apple[2][3] = apple[2][4] = (char)219;
	apple[3][0] = apple[3][1] = apple[3][2] = apple[3][3] = apple[3][4] = (char)219;
	apple[4][1] = apple[4][2] = apple[4][3] = char(223);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 0)
			{
				TextColor(106);
			}
			else
			{
				TextColor(100);
			}
			cout << apple[i][j];
		}
	}
}

void Nut1PlayerEndless(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char OnePlayer[8] = { 1, 'p', 'l', 'a', 'y', 'e', 'r'};
	if (selection == 1)
	{
		DeletingSpace(x, y, ChieuDai, ChieuRong);
		VeNen1PlayerEndless(x, y, ChieuDai, ChieuRong);
		VeChiTiet1PlayerEndless(35, 17, ChieuDai, ChieuRong);
		VeChiTiet1PlayerEndless2(60, 19, ChieuDai, ChieuRong);

		TextColor(244);
		print_Number(OnePlayer[0], 32, 23);
		print_Text(OnePlayer[1], 32, 27);
		print_Text(OnePlayer[2], 32, 31);
		print_Text(OnePlayer[3], 32, 35);
		print_Text(OnePlayer[4], 32, 39);
		print_Text(OnePlayer[5], 32, 43);
		print_Text(OnePlayer[6], 32, 47);

		TextColor(240);
		gotoXY(23, 36); cout << "TYPE 1: ENDLESS LOOP";
		gotoXY(58, 32); cout << "This mode aims the player";
		gotoXY(58, 33); cout << "to reach as high score as ";
		gotoXY(58, 34); cout << "possible in one map.";

		TextColor(238);
		print_Symbol('-', 39, 20);
		TextColor(119);
		print_Symbol('-', 39, 37);
		print_Symbol('-', 39, 54);
		print_Symbol('-', 39, 71);
	}
}


void VeNen1PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong)
{
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 16; j++)
		{
			TextColor(51);
			gotoXY(i, j); cout << char(219);
		}
	}

	char map[2] = { 'l', 'v' };
	TextColor(49);
	print_Text(map[0], 17, 30);
	print_Text(map[1], 17, 34);
	print_Number(1, 17, 39);

	print_Text(map[0], 17, 65);
	print_Text(map[1], 17, 69);
	print_Number(2, 17, 74);
}

void VeChiTiet1PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong)
{
	char gate[7][7] = { " " };
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			gate[i][j] = char(219);
		}
	}

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			if (i > 0 && i < 7 && j > 0 && j < 6)
			{
				TextColor(56);
			}
			else
			{
				TextColor(54);
			}
			gotoXY(x + j, y + i);
			cout << gate[i][j];
			gotoXY(x + j + 34, y + i);
			cout << gate[i][j];
		}
	}
}

void VeChiTiet1PlayerAdventure2(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[7][26] = { " " };
	snake[5][0] = snake[5][1] = snake[5][2] = char(220);
	snake[5][3] = snake[5][4] = snake[5][5] = snake[5][6] = snake[5][7] = snake[5][8] = snake[5][9] = char(219);
	snake[5][10] = snake[5][11] = char(219);
	snake[4][10] = snake[4][11] = char(219);
	snake[3][10] = snake[3][11] = snake[3][12] = snake[3][13] = snake[3][14] = snake[3][15] = char(219);
	snake[4][14] = snake[4][15] = char(219);
	snake[5][14] = snake[5][15] = snake[5][16] = snake[5][17] = snake[5][18] = snake[5][19] = snake[5][20] = snake[5][21] = char(219);
	snake[4][20] = snake[4][21] = char(219);
	snake[3][20] = snake[3][21] = char(219);
	snake[2][20] = snake[2][21] = char(219);
	snake[1][20] = snake[1][21] = snake[1][22] = snake[1][23] = snake[1][24] = snake[1][25] = char(219);
	snake[0][23] = char(219); snake[0][25] = char(220); snake[0][24] = char(223);

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 26; j++)
		{
			if (i == 0 && j == 25)
			{
				TextColor(61);

			}
			else if (i == 0 && j == 24)
			{
				TextColor(237);
			}
			else
			{
				TextColor(141);
			}
			gotoXY(x + j + 1, y + i - 4);
			cout << snake[i][j];
		}
	}
}


void Nut1PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char OnePlayer[8] = { 1, 'p', 'l', 'a', 'y', 'e', 'r', 'e' };
	if (selection == 2)
	{
		DeletingSpace(x, y, ChieuDai, ChieuRong);
		VeNen1PlayerAdventure(x, y, ChieuDai, ChieuRong);
		VeChiTiet1PlayerAdventure(33, 21, ChieuDai, ChieuRong);
		VeChiTiet1PlayerAdventure2(33, 26, ChieuDai, ChieuRong);

		TextColor(244);
		print_Number(OnePlayer[0], 32, 23);
		print_Text(OnePlayer[1], 32, 27);
		print_Text(OnePlayer[2], 32, 31);
		print_Text(OnePlayer[3], 32, 35);
		print_Text(OnePlayer[4], 32, 39);
		print_Text(OnePlayer[5], 32, 43);
		print_Text(OnePlayer[6], 32, 47);

		TextColor(240);
		gotoXY(23, 36); cout << "TYPE 2: ADVENTURE";
		gotoXY(56, 32); cout << "This game mode let the player";
		gotoXY(56, 33); cout << "try to eat enough food so as";
		gotoXY(56, 34); cout << "to go into the new map.";

		TextColor(238);
		print_Symbol('-', 39, 37);
		TextColor(119);
		print_Symbol('-', 39, 20);
		print_Symbol('-', 39, 54);
		print_Symbol('-', 39, 71);
	}
}

void VeNen2PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong)
{
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 16; j++)
		{
			TextColor(136);
			gotoXY(i, j); cout << char(219);
		}
	}
}

void VeChiTiet2PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[8][22] = { " " };
	snake[0][21] = snake[0][20] = char(223); snake[0][19] = char(219);
	snake[1][19] = snake[1][18] = snake[1][17] = snake[1][16] = char(223);
	snake[0][16] = char(219); snake[0][15] = snake[0][14] = snake[0][13] = snake[0][12] = char(219);
	snake[1][13] = snake[1][12] = char(219);
	snake[2][13] = snake[2][12] = snake[2][11] = snake[2][10] = snake[2][9] = snake[2][8] = char(219);
	snake[1][9] = snake[1][8] = char(219);
	snake[0][9] = snake[0][8] = snake[0][7] = snake[0][6] = snake[0][5] = snake[0][4] = snake[0][3] = snake[0][2] = char(219);
	snake[1][3] = snake[1][2] = char(219);
	snake[2][3] = snake[2][2] = char(219);
	snake[3][3] = snake[3][2] = char(219);
	snake[4][3] = snake[4][2] = snake[4][1] = snake[4][0] = char(219);

	char snake2[8][22] = { " " };
	snake2[4][21] = snake2[4][20] = snake2[4][19] = snake2[4][18] = char(219);
	snake2[3][19] = snake2[3][18] = char(219);
	snake2[2][19] = snake2[2][18] = char(219);
	snake2[1][19] = snake2[1][18] = char(219);
	snake2[0][19] = snake2[0][18] = snake2[0][17] = snake2[0][16] = snake2[0][15] = snake2[0][14] = char(219);
	snake2[0][13] = snake2[0][12] = snake2[0][11] = snake2[0][10] = char(219);
	snake2[1][11] = snake2[1][10] = char(219);
	snake2[2][11] = snake2[2][10] = char(219);
	snake2[3][11] = snake2[3][10] = char(219);
	snake2[4][11] = snake2[4][10] = char(219);
	snake2[5][11] = snake2[5][10] = char(219); snake2[5][9] = snake2[5][12] = char(220);
	snake2[6][11] = snake2[6][10] = char(219); snake2[6][9] = snake2[6][12] = char(223);

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			gotoXY(x + j - 22, y + i);
			if ((i == 5 && j == 9) || (i == 5 && j == 12))
			{
				TextColor(181);
			}
			else
			{
				TextColor(139);
			}
			cout << snake2[i][j];
			gotoXY(x + j, y + i);
			cout << snake[i][j];
		}
	}
}

void VeChiTiet2PlayerAdventure2(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[8][22] = { " " };
	snake[7][0] = snake[7][1] = char(220); snake[7][2] = char(219);
	snake[6][2] = snake[6][3] = snake[6][4] = snake[6][5] = char(220);
	snake[7][5] = char(219); snake[7][6] = snake[7][7] = snake[7][8] = snake[7][9] = char(219);
	snake[6][8] = snake[6][9] = char(219);
	snake[5][8] = snake[5][9] = snake[5][10] = snake[5][11] = snake[5][12] = snake[5][13] = char(219);
	snake[6][12] = snake[6][13] = char(219);
	snake[7][12] = snake[7][13] = snake[7][14] = snake[7][15] = snake[7][16] = snake[7][17] = snake[7][18] = snake[7][19] = char(219);
	snake[6][18] = snake[6][19] = char(219);
	snake[5][18] = snake[5][19] = char(219);
	snake[4][18] = snake[4][19] = char(219);
	snake[3][18] = snake[3][19] = snake[3][20] = snake[3][21] = char(219);

	char snake2[8][22] = { " " };
	snake2[3][0] = snake2[3][1] = snake2[3][2] = snake2[3][3] = char(219);
	snake2[4][2] = snake2[4][3] = char(219);
	snake2[5][2] = snake2[5][3] = char(219);
	snake2[6][2] = snake2[6][3] = char(219);
	snake2[7][2] = snake2[7][3] = snake2[7][4] = snake2[7][5] = snake2[7][6] = snake2[7][7] = char(219);
	snake2[7][8] = snake2[7][9] = snake2[7][10] = snake2[7][11] = char(219);
	snake2[6][10] = snake2[6][11] = char(219);
	snake2[5][10] = snake2[5][11] = char(219);
	snake2[4][10] = snake2[4][11] = char(219);
	snake2[3][10] = snake2[3][11] = char(219);
	snake2[2][10] = snake2[2][11] = char(219); snake2[2][12] = snake2[2][9] = char(223);
	snake2[1][10] = snake2[1][11] = char(219); snake2[1][12] = snake2[1][9] = char(220);

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			gotoXY(x + j + 22, y + i);
			if ((i == 2 && j == 9) || (i == 2 && j == 12))
			{
				TextColor(197);
			}
			else
			{
				TextColor(140);
			}
			cout << snake2[i][j];
			gotoXY(x + j, y + i);
			cout << snake[i][j];
		}
	}
}

void VeChiTiet2PlayerAdventure3(int x, int y, int ChieuDai, int ChieuRong)
{
	char fruit[3][5] = { " " };
	fruit[0][0] = char(220); fruit[0][1] = fruit[0][2] = fruit[0][3] = char(219); fruit[0][4] = char(220);
	fruit[1][0] = fruit[1][1] = fruit[1][2] = fruit[1][3] = fruit[1][4] = char(219);
	fruit[2][0] = char(223); fruit[2][1] = fruit[2][2] = fruit[2][3] = char(219); fruit[2][4] = char(223);

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 1 && j != 0 && j != 4)
			{
				TextColor(137);
			}
			else
			{
				TextColor(129);
			}
			cout << fruit[i][j];
			gotoXY(x + j + 48, y + i - 8);
			if (i == 1 && j != 0 && j != 4)
			{
				TextColor(134);
			}
			else
			{
				TextColor(132);
			}
			cout << fruit[i][j];
		}
	}
}


void Nut2PlayerAdventure(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char TwoPlayer[8] = { 2, 'p', 'l', 'a', 'y', 'e', 'r', 'e'};
	if (selection == 3)
	{
		DeletingSpace(x, y, ChieuDai, ChieuRong);
		VeNen2PlayerAdventure(x, y, ChieuDai, ChieuRong);
		VeChiTiet2PlayerAdventure(40, 17, ChieuDai, ChieuRong);
		VeChiTiet2PlayerAdventure2(45, 20, ChieuDai, ChieuRong);
		VeChiTiet2PlayerAdventure3(27, 25, ChieuDai, ChieuRong);

		TextColor(244);
		print_Number(TwoPlayer[0], 32, 23);
		print_Text(TwoPlayer[1], 32, 27);
		print_Text(TwoPlayer[2], 32, 31);
		print_Text(TwoPlayer[3], 32, 35);
		print_Text(TwoPlayer[4], 32, 39);
		print_Text(TwoPlayer[5], 32, 43);
		print_Text(TwoPlayer[6], 32, 47);

		TextColor(240);
		gotoXY(23, 36); cout << "TYPE 2: ADVENTURE";
		gotoXY(55, 32); cout << "This game mode let two players";
		gotoXY(55, 33); cout << "together eat enough food so as";
		gotoXY(55, 34); cout << "to go into the new map.";

		TextColor(238);
		print_Symbol('-', 39, 54);

		TextColor(119);
		print_Symbol('-', 39, 20);
		print_Symbol('-', 39, 37);
		print_Symbol('-', 39, 71);
	}
}

void VeNen2PlayerBattle(int x, int y, int ChieuDai, int ChieuRong)
{
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 16; j++)
		{
			if (i <  53)
			{
				TextColor(221);
			}
			else if (i == 53)
			{
				TextColor(240);
			}
			else
			{
				TextColor(187);
			}
			gotoXY(i, j); cout << char(219);
		}
	}

	char vs[2] = { 'v', 's' };
	TextColor(222);
	print_Text(vs[0], 21, 49);
	TextColor(190);
	print_Text(vs[1], 21, 54);
}

void VeChiTiet2PlayerBattle(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[12][22] = { " " };
	snake[10][0] = snake[10][1] = char(223); snake[10][2] = snake[10][3] = char(219);
	snake[11][2] = snake[11][3] = snake[11][4] = snake[11][5] = snake[11][6] = snake[11][7] = snake[11][8] = snake[11][9] = snake[11][10] = char(219);
	snake[11][11] = snake[11][12] = snake[11][13] = snake[11][14] = snake[11][15] = snake[11][16] = char(219);
	snake[7][15] = snake[7][16] = snake[8][15] = snake[8][16] = snake[9][15] = snake[9][16] = snake[10][15] = snake[10][16] = char(219);
	snake[7][15] = snake[7][16] = snake[7][14] = snake[7][13] = snake[7][12] = snake[7][11] = snake[7][10] = snake[7][9] = snake[7][8] = char(219);
	snake[6][9] = snake[6][8] = snake[5][9] = snake[5][8] = snake[4][9] = snake[4][8] = char(219);
	snake[3][8] = snake[3][9] = snake[3][10] = snake[3][11] = snake[3][12] = snake[3][13] = snake[3][14] = char(219);
	snake[2][11] = snake[2][12] = char(219); snake[2][14] = char(220); snake[2][13] = char(223);

	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 2 && j == 13)
			{
				TextColor(233);
			}
			else
			{
				TextColor(217);
			}
			cout << snake[i][j];
		}
	}
}

void VeChiTiet2PlayerBattle2(int x, int y, int ChieuDai, int ChieuRong)
{
	char snake[12][22] = { " " };
	snake[10][21] = snake[10][20] = char(223); snake[10][19] = snake[10][18] = char(219);
	snake[11][19] = snake[11][18] = snake[11][17] = snake[11][16] = snake[11][15] = snake[11][14] = snake[11][13] = snake[11][12] = snake[11][11] = char(219);
	snake[11][10] = snake[11][9] = snake[11][8] = snake[11][7] = snake[11][6] = snake[11][5] = char(219);
	snake[7][5] = snake[7][6] = snake[8][5] = snake[8][6] = snake[9][5] = snake[9][6] = snake[10][5] = snake[10][6] = char(219);
	snake[7][6] = snake[7][5] = snake[7][7] = snake[7][8] = snake[7][9] = snake[7][10] = snake[7][11] = snake[7][12] = snake[7][13] = char(219);
	snake[6][12] = snake[6][13] = snake[5][12] = snake[5][13] = snake[4][12] = snake[4][13] = char(219);
	snake[3][13] = snake[3][12] = snake[3][11] = snake[3][10] = snake[3][9] = snake[3][8] = snake[3][7] = char(219);
	snake[2][10] = snake[2][9] = char(219); snake[2][7] = char(220); snake[2][8] = char(223);

	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 2 && j == 8)
			{
				TextColor(226);
			}
			else
			{
				TextColor(178);
			}
			cout << snake[i][j];
		}
	}
}

void Nut2PlayerBattle(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char OnePlayer[8] = { 2, 'p', 'l', 'a', 'y', 'e', 'r', 'e' };
	if (selection == 4)
	{
		DeletingSpace(x, y, ChieuDai, ChieuRong);
		VeNen2PlayerBattle(x, y, ChieuDai, ChieuRong); //Ve nen voi chu VS
		VeChiTiet2PlayerBattle(25, 17, ChieuDai, ChieuRong); //Ve con ran 1
		VeChiTiet2PlayerBattle2(59, 17, ChieuDai, ChieuRong); //Ve con ran 2

		TextColor(244);
		print_Number(OnePlayer[0], 32, 23);
		print_Text(OnePlayer[1], 32, 27);
		print_Text(OnePlayer[2], 32, 31);
		print_Text(OnePlayer[3], 32, 35);
		print_Text(OnePlayer[4], 32, 39);
		print_Text(OnePlayer[5], 32, 43);
		print_Text(OnePlayer[6], 32, 47);

		TextColor(240);
		gotoXY(23, 36); cout << "TYPE 2: BATTLE";
		gotoXY(55, 32); cout << "This game mode let two players";
		gotoXY(55, 33); cout << "combat each other to determine";
		gotoXY(55, 34); cout << "whose snake is stronger.";

		TextColor(119);
		print_Symbol('-', 39, 20);
		print_Symbol('-', 39, 37);
		print_Symbol('-', 39, 54);
		TextColor(238);
		print_Symbol('-', 39, 71);
	}
}

void HienThiSelectGameMode(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	Nut1PlayerEndless(x, y, ChieuDai, ChieuRong, selection);
	Nut1PlayerAdventure(x, y, ChieuDai, ChieuRong, selection);
	Nut2PlayerAdventure(x, y, ChieuDai, ChieuRong, selection);
	Nut2PlayerBattle(x, y, ChieuDai, ChieuRong, selection);
}

int LogicSelectGameMode(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	HienThiSelectGameMode(x, y, ChieuDai, ChieuRong, select);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 0;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 2;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 3)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 3;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 4)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 4;
				inputChoice = true;
			}
			if (phim == 'g' || phim == 'G')
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 5;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveRight)
			{
				select++;
			}
			if (phim == KeyBoardP1.MoveLeft)
			{
				select--;
			}
			if (select < 1)
			{
				select = 4;
			}
			if (select > 4)
			{
				select = 1;
			}
			HienThiSelectGameMode(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

int MenuSelectModeGame(int soundBG, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionModeGame(x, y, ChieuDai, ChieuRong);
	int result = LogicSelectGameMode(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2);
	return result;
}

//-----------------------------------------------------------------------------------------------------------------------------
//GAME OVER MENU
//-----------------------------------------------------------------------------------------------------------------------------

void VeNenGameOver(int x, int y, int ChieuDai, int ChieuRong)
{
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 14; j <= ChieuRong - 17; j++)
		{
			TextColor(17);
			gotoXY(i, j); cout << char(219);
		}
	}
	int index = 12;
	int row = 0;
	while (index > 0)
	{
		TextColor(238);
		for (int i = x + 20 + index; i <= ChieuDai - 16 - index; i++)
		{
			gotoXY(i, 16 + row); cout << char(219);
		}
		index--;
		row++;
	}
}

void VeRanChet(int x, int y, int ChieuDai, int ChieuRong)
{
	char sDeadTail[6][10] = { " " };
	sDeadTail[0][8] = sDeadTail[0][9] = char(219);
	sDeadTail[1][8] = sDeadTail[1][9] = char(219);
	sDeadTail[2][8] = sDeadTail[2][9] = char(219);
	sDeadTail[3][8] = sDeadTail[3][9] = char(219);
	sDeadTail[4][8] = sDeadTail[4][9] = char(219);
	sDeadTail[5][8] = sDeadTail[5][9] = char(219);

	sDeadTail[4][5] = sDeadTail[4][6] = sDeadTail[4][7] = char(220);
	sDeadTail[5][5] = sDeadTail[5][6] = sDeadTail[5][7] = char(219);

	sDeadTail[1][2] = sDeadTail[1][1] = sDeadTail[1][0] = char(220);
	sDeadTail[1][4] = sDeadTail[1][3] = char(220);
	sDeadTail[2][4] = sDeadTail[2][3] = char(219); sDeadTail[2][1] = sDeadTail[2][2] = char(223);
	sDeadTail[3][4] = sDeadTail[3][3] = char(219);
	sDeadTail[4][4] = sDeadTail[4][3] = char(219);
	sDeadTail[5][4] = sDeadTail[5][3] = char(219);

	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoXY(x + j + 3, y + i);
			TextColor(234);
			cout << sDeadTail[i][j];
		}
	}

	char sDeadBody[6][20] = { " " };
	sDeadBody[1][16] = char(220); sDeadBody[1][17] = sDeadBody[1][18] = sDeadBody[1][19] = char(219);
	sDeadBody[2][16] = sDeadBody[2][17] = sDeadBody[2][18] = sDeadBody[2][19] = char(219);
	sDeadBody[3][16] = sDeadBody[3][17] = char(219);
	sDeadBody[4][16] = sDeadBody[4][17] = char(219);
	sDeadBody[5][16] = char(219); sDeadBody[5][17] = char(219);
	sDeadBody[4][15] = char(220); sDeadBody[5][15] = char(219);
	sDeadBody[4][14] = char(220); sDeadBody[5][14] = char(219);
	sDeadBody[4][13] = char(219); sDeadBody[5][13] = char(219);
	sDeadBody[4][12] = char(219); sDeadBody[5][12] = char(219);
	sDeadBody[3][12] = sDeadBody[3][13] = char(219);
	sDeadBody[2][12] = sDeadBody[2][13] = char(219);
	sDeadBody[1][12] = sDeadBody[1][13] = char(219);
	sDeadBody[0][12] = char(219); sDeadBody[0][13] = char(219);
	sDeadBody[0][11] = char(219); sDeadBody[1][11] = char(223);
	sDeadBody[0][10] = char(219); sDeadBody[1][10] = char(223);
	sDeadBody[0][9] = char(219); sDeadBody[1][9] = char(223);
	sDeadBody[0][8] = char(219); sDeadBody[1][8] = char(223);
	sDeadBody[0][7] = char(219);
	sDeadBody[1][7] = sDeadBody[1][8] = char(219);
	sDeadBody[2][7] = sDeadBody[2][8] = char(219);
	sDeadBody[3][7] = sDeadBody[3][8] = char(219);
	sDeadBody[4][7] = sDeadBody[4][8] = char(219);
	sDeadBody[5][7] = char(219);  sDeadBody[5][8] = char(219);
	sDeadBody[5][6] = char(219); sDeadBody[4][6] = char(220);
	sDeadBody[5][6] = char(219); sDeadBody[4][6] = char(220);
	sDeadBody[5][5] = char(219); sDeadBody[4][5] = char(220);
	sDeadBody[5][4] = char(219); sDeadBody[4][4] = char(219); sDeadBody[5][3] = char(219);
	sDeadBody[4][3] = sDeadBody[4][4] = char(219);
	sDeadBody[3][3] = sDeadBody[3][4] = char(219);
	sDeadBody[2][3] = sDeadBody[2][4] = char(219);
	sDeadBody[1][3] = sDeadBody[1][4] = char(219);
	sDeadBody[0][3] = sDeadBody[0][4] = char(219);
	sDeadBody[0][2] = char(219); sDeadBody[1][2] = char(223);
	sDeadBody[0][1] = char(219); sDeadBody[1][1] = char(223);
	sDeadBody[0][0] = char(219); sDeadBody[1][0] = char(223);

	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(x + j + 13, y + i);
			TextColor(234);
			cout << sDeadBody[i][j];
		}
	}

	char sDeadHead[5][13] = { " " };
	sDeadHead[0][4] = char(220);
	sDeadHead[0][5] = sDeadHead[0][6] = sDeadHead[0][7] = sDeadHead[0][8] = char(219); sDeadHead[0][9] = char(220);
	sDeadHead[1][3] = sDeadHead[1][4] = sDeadHead[1][5] = sDeadHead[1][6] = sDeadHead[1][7] = sDeadHead[1][8] = sDeadHead[1][9] = char(219);
	sDeadHead[1][10] = sDeadHead[1][11] = sDeadHead[1][12] = char(219);
	sDeadHead[2][3] = sDeadHead[2][4] = sDeadHead[2][5] = sDeadHead[2][6] = sDeadHead[2][7] = sDeadHead[2][8] = sDeadHead[2][9] = char(219);
	sDeadHead[2][10] = sDeadHead[2][11] = sDeadHead[2][12] = char(219);
	sDeadHead[3][2] = char(223);
	sDeadHead[3][3] = sDeadHead[3][4] = sDeadHead[3][5] = sDeadHead[3][6] = sDeadHead[3][7] = sDeadHead[3][8] = sDeadHead[3][9] = char(219);
	sDeadHead[4][4] = char(223); sDeadHead[4][5] = sDeadHead[4][6] = sDeadHead[4][7] = sDeadHead[4][8] = sDeadHead[4][9] = char(219);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			gotoXY(x + j + 30, y + i);
			TextColor(234);
			cout << sDeadHead[i][j];
		}
	}

	char sDeadEye[5][5] = { " " };
	sDeadEye[2][0] = char(223);
	sDeadEye[2][1] = char(223);
	sDeadEye[2][2] = char(223);
	sDeadEye[2][3] = char(223);
	sDeadEye[2][4] = char(223);

	sDeadEye[1][2] = char(219);
	sDeadEye[2][2] = char(219);
	sDeadEye[3][2] = char(223);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j + 35, y + i);
			TextColor(160);
			cout << sDeadEye[i][j];
		}
	}

	char sDeadMouth[3][5] = { " " };
	sDeadMouth[0][0] = sDeadMouth[0][1] = sDeadMouth[0][2] = sDeadMouth[0][4] = char(223);
	sDeadMouth[0][3] = char(219);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j + 40, y + i + 3);
			TextColor(228);
			cout << sDeadMouth[i][j];
		}
	}
	char Holy[3][5] = { " " };

	Holy[0][1] = Holy[0][2] = Holy[0][3] = char(220);
	Holy[1][0] = Holy[1][4] = char(219);
	Holy[2][1] = Holy[2][2] = Holy[2][3] = char(223);

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j + 35, y + i - 3);
			TextColor(230);
			cout << Holy[i][j];
		}
	}
}

void VeHienThiNut(int x, int y, int ChieuDai, int ChieuRong)
{
	char button[3][5] = { " " };
	button[0][1] = button[0][2] = button[0][3] = char(223); button[0][0] = button[0][4] = char(219);
	button[1][0] = button[1][4] = char(219); button[1][1] = char(32); button[1][3] = char(32);
	button[2][1] = button[2][2] = button[2][3] = char(220); button[2][0] = button[2][4] = char(219);

	button[1][2] = char(219);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 1 && j == 2)
			{
				TextColor(228);
			}
			else
			{
				TextColor(230);
			}
			cout << button[i][j];
		}
	}
}

void XoaHienThiNut(int x, int y, int ChieuDai, int ChieuRong)
{
	char button[3][5] = { " " };
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			button[i][j] = char(219);
		}
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			TextColor(187);
			cout << button[i][j];
		}
	}
}

void NutNewGameOver(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
	if (selection == 1)
	{
		TextColor(180);
		print_Text(newgame[0], 37, 37);
		print_Text(newgame[1], 37, 41);
		print_Text(newgame[2], 37, 45);
		print_Text(newgame[3], 37, 52);
		print_Text(newgame[4], 37, 57);
		print_Text(newgame[5], 37, 61);
		print_Text(newgame[6], 37, 67);

		//XoaHienThiNut(29, 37, ChieuDai, ChieuRong);
		VeHienThiNut(29, 37, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(184);
		print_Text(newgame[0], 37, 37);
		print_Text(newgame[1], 37, 41);
		print_Text(newgame[2], 37, 45);
		print_Text(newgame[3], 37, 52);
		print_Text(newgame[4], 37, 57);
		print_Text(newgame[5], 37, 61);
		print_Text(newgame[6], 37, 67);

		XoaHienThiNut(29, 37, ChieuDai, ChieuRong);
	}
}

void NutReturnGameOver(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char returnMenu[10] = { 'r', 'e', 't', 'u', 'r', 'n', 'm', 'e', 'n', 'u' };
	if (selection == 2)
	{
		TextColor(180);
		print_Text(returnMenu[0], 42, 37);
		print_Text(returnMenu[1], 42, 41);
		print_Text(returnMenu[2], 42, 45);
		print_Text(returnMenu[3], 42, 49);
		print_Text(returnMenu[4], 42, 53);
		print_Text(returnMenu[5], 42, 57);
		print_Text(returnMenu[6], 42, 62);
		print_Text(returnMenu[7], 42, 68);
		print_Text(returnMenu[8], 42, 72);
		print_Text(returnMenu[9], 42, 76);

		VeHienThiNut(29, 42, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(184);
		print_Text(returnMenu[0], 42, 37);
		print_Text(returnMenu[1], 42, 41);
		print_Text(returnMenu[2], 42, 45);
		print_Text(returnMenu[3], 42, 49);
		print_Text(returnMenu[4], 42, 53);
		print_Text(returnMenu[5], 42, 57);
		print_Text(returnMenu[6], 42, 62);
		print_Text(returnMenu[7], 42, 68);
		print_Text(returnMenu[8], 42, 72);
		print_Text(returnMenu[9], 42, 76);

		XoaHienThiNut(29, 42, ChieuDai, ChieuRong);
	}
}

void HienThiSelectGameOver(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	NutNewGameOver(x, y, ChieuDai, ChieuRong, selection);
	NutReturnGameOver(x, y, ChieuDai, ChieuRong, selection);
}

void VeDiemRanChet(int x, int y, int ChieuDai, int ChieuRong, int diem)
{
	char point[2] = {'X', 'j'};
	TextColor(158);
	print_Text(point[0], 31, 57);
	print_Text(point[0], 31, 62);
	print_Text(point[0], 31, 67);
	print_Text(point[0], 31, 72);
	print_Text(point[0], 31, 77);

	int soDonVi = 0;
	int soHangChuc = 0;
	int soHangTram = 0;
	int soHangNghin = 0;
	int soChucNghin = 0;

	soDonVi = diem % 10;
	soHangChuc = diem / 10 % 10;
	soHangTram = diem / 100 % 10;
	soHangNghin = diem / 1000 % 10;
	soChucNghin = diem / 10000 % 10;

	int i = 10;
	int rand = 0;
	print_Text(point[1], 31, 77);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 77);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 77);
	print_Number(soDonVi, 31, 77);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 72);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 72);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 72);
	print_Number(soHangChuc, 31, 72);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 67);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 67);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 67);
	print_Number(soHangTram, 31, 67);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 62);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 62);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 62);
	print_Number(soHangNghin, 31, 62);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 57);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 57);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 57);
	print_Number(soChucNghin, 31, 57);
}

void HienThiOptionGameOver(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(221);
	for (int i = x + 27; i <= ChieuDai - 24; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(222);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(31, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 28; i <= ChieuDai - 24; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(31, 6); cout << char(201);
	gotoXY(74, 6); cout << char(187);
	gotoXY(31, 10); cout << char(200);
	gotoXY(74, 10); cout << char(188);

	char gameover[9] = { 'g', 'a', 'm', 'e', 'o', 'v', 'e', 'r', '!' };
	TextColor(222);
	print_Text(gameover[0], 7, 33);
	print_Text(gameover[1], 7, 38);
	print_Text(gameover[2], 7, 42);
	print_Text(gameover[3], 7, 48);
	print_Text(gameover[4], 7, 53);
	print_Text(gameover[5], 7, 57);
	print_Text(gameover[6], 7, 62);
	print_Text(gameover[7], 7, 66);
	print_Symbol(gameover[8], 70, 7);
	print_Symbol(gameover[8], 72, 7);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 20; i <= ChieuDai - 16; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng hình rắn chết
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 20, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 20, i); std::cout << char(219);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(144);
		gotoXY(i, y + ChieuRong - 11); std::cout << char(220);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(176);
		gotoXY(i, y + ChieuRong - 6); std::cout << char(220);
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
	}

	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	// Vẽ nền vàng bên dưới
	TextColor(153);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 28; j <= ChieuRong - 10; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	// Vẽ nền đỏ bên dưới
	TextColor(187);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 34; j <= ChieuRong - 5; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 39; j <= ChieuRong; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 12); std::cout << char(205);
	}
	for (int i = y + 28; i <= ChieuRong - 9; i++)
	{
		//Vẽ cạnh giữa
		gotoXY(x + ChieuDai - 48, i); std::cout << char(219);
	}

	gotoXY(30, 13); cout << "<A/D> TO MOVE NEXT/BACK, <ENTER> TO SELECT";
	char score[6] = { 's', 'c', 'o', 'r', 'e', '@' };
	TextColor(158);
	print_Symbol(score[5], 26, 31);
	print_Text(score[0], 31, 33);
	print_Text(score[1], 31, 37);
	print_Text(score[2], 31, 41);
	print_Text(score[3], 31, 45);
	print_Text(score[4], 31, 49);

}

void HienThiLeader(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 20; i <= ChieuDai - 16; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng hình rắn chết
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong - 15; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 20, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 20, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	// Vẽ nền trắng bên trong
	TextColor(238);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= y + 15; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	char congrats[10] = { 'h', 'i', 'g', 'h', 's', 'c', 'o', 'r', 'e', '!'};
	TextColor(228);
	print_Text(congrats[0], 14, 34);
	print_Text(congrats[1], 14, 38);
	print_Text(congrats[2], 14, 40);
	print_Text(congrats[3], 14, 45);
	print_Text(congrats[4], 14, 51);
	print_Text(congrats[5], 14, 55);
	print_Text(congrats[6], 14, 59);
	print_Text(congrats[7], 14, 63);
	print_Text(congrats[8], 14, 67);
	print_Symbol('!', 71, 14);

	TextColor(240);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		// Vẽ cạnh giữa
		gotoXY(i, y + 16); std::cout << char(220);
	}
}

int LogicSelectGameOver(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2, int diem, char* ten_nguoi_choi, BangDiem bangDiem[], int so_luong)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	VeNenGameOver(x, y, ChieuDai, ChieuRong);
	VeRanChet(30, 20, ChieuDai, ChieuRong);
	HienThiSelectGameOver(x, y, ChieuDai, ChieuRong, select);
	VeDiemRanChet(x, y, ChieuDai, ChieuRong, diem);
	Sleep(2000);
	if ((KiemTraTop5(bangDiem, so_luong, ten_nguoi_choi, diem) == true))
	{
		HienThiLeader(x, y, ChieuDai, ChieuRong);
		LuuDanhSachNguoiChoiDiemCaoNhat(bangDiem, so_luong, ten_nguoi_choi, diem);
	}
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				res = 0;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 2;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveDown)
			{
				select++;
			}
			if (phim == KeyBoardP1.MoveUp)
			{
				select--;
			}
			if (select < 1)
			{
				select = 2;
			}
			if (select > 2)
			{
				select = 1;
			}
			HienThiSelectGameOver(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

int MenuGameOver(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int& diem, char* ten_nguoi_choi, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int mode)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	
	int so_luong = 0;
	BangDiem bangDiem[5];
	ifstream fileIn;

	if (mode == 1)
	{
		fileIn.open("bangdiem.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}
	else if (mode == 2)
	{
		fileIn.open("bangdiem2.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}
	else if (mode == 3)
	{
		fileIn.open("bangdiem3.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}

	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionGameOver(x, y, ChieuDai, ChieuRong);
	int result = LogicSelectGameOver(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2, diem, ten_nguoi_choi, bangDiem, so_luong);
	return result;
}

//--------------------------------------------------------------------------------------------------------------------------------
//GAME OVER MODE 4
//--------------------------------------------------------------------------------------------------------------------------------

void VeDiemRanChetMode4(int x, int y, int ChieuDai, int ChieuRong, int diem, int diem2)
{
	char point[2] = { 'X', 'j' };
	TextColor(158);
	print_Text(point[0], 31, 38);
	print_Text(point[0], 31, 42);
	print_Text(point[0], 31, 46);

	print_Text(point[0], 31, 58);
	print_Text(point[0], 31, 62);
	print_Text(point[0], 31, 66);

	int soDonVi = 0;
	int soHangChuc = 0;
	int soHangTram = 0;

	soDonVi = diem % 10;
	soHangChuc = diem / 10 % 10;
	soHangTram = diem / 100 % 10;

	int soDonVi2 = 0;
	int soHangChuc2 = 0;
	int soHangTram2 = 0;

	soDonVi2 = diem2 % 10;
	soHangChuc2 = diem2 / 10 % 10;
	soHangTram2 = diem2 / 100 % 10;

	int i = 10;
	int rand = 0;
	print_Text(point[1], 31, 38);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 38);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 38);
	print_Number(soHangTram, 31, 38);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 42);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 42);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 42);
	print_Number(soHangChuc, 31, 42);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 46);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 46);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 46);
	print_Number(soDonVi, 31, 46);


	i = 10;
	rand = 0;
	print_Text(point[1], 31, 58);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 58);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 58);
	print_Number(soHangTram2, 31, 58);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 62);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 62);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 62);
	print_Number(soHangChuc2, 31, 62);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 66);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 66);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 66);
	print_Number(soDonVi2, 31, 66);
}

void HienThiOptionGameOverMode4(int x, int y, int ChieuDai, int ChieuRong, int whoWin)
{
	TextColor(221);
	for (int i = x + 26; i <= ChieuDai - 22; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 35; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(222);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(30, i); cout << char(186);
		gotoXY(76, i); cout << char(186);
	}
	for (int i = x + 27; i <= ChieuDai - 22; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(30, 6); cout << char(201);
	gotoXY(76, 6); cout << char(187);
	gotoXY(30, 10); cout << char(200);
	gotoXY(76, 10); cout << char(188);

	if (whoWin == 0)
	{
		char player1Win[9] = { 'p', 'l', 'a', 'y', 'e', 'r', 'w', 'o', 'n'};
		TextColor(222);
		print_Text(player1Win[0], 7, 31);
		print_Text(player1Win[1], 7, 35);
		print_Text(player1Win[2], 7, 39);
		print_Text(player1Win[3], 7, 43);
		print_Text(player1Win[4], 7, 47);
		print_Text(player1Win[5], 7, 51);
		print_Number(1, 7, 55);
		print_Text(player1Win[6], 7, 59);
		print_Text(player1Win[7], 7, 65);
		print_Text(player1Win[8], 7, 69);
		print_Symbol('!', 73, 7);
		print_Symbol('!', 75, 7);
	}
	else if (whoWin == 1)
	{
		char player2Win[9] = { 'p', 'l', 'a', 'y', 'e', 'r', 'w', 'o', 'n' };
		TextColor(222);
		print_Text(player2Win[0], 7, 31);
		print_Text(player2Win[1], 7, 35);
		print_Text(player2Win[2], 7, 39);
		print_Text(player2Win[3], 7, 43);
		print_Text(player2Win[4], 7, 47);
		print_Text(player2Win[5], 7, 51);
		print_Number(2, 7, 55);
		print_Text(player2Win[6], 7, 59);
		print_Text(player2Win[7], 7, 65);
		print_Text(player2Win[8], 7, 69);
		print_Symbol('!', 73, 7);
		print_Symbol('!', 75, 7);
	}
	else if (whoWin == 2)
	{
		char NoPlayerWin[8] = { 'g', 'a', 'm', 'e', 'd', 'r', 'a', 'w' };
		TextColor(222);
		print_Text(NoPlayerWin[0], 7, 33);
		print_Text(NoPlayerWin[1], 7, 38);
		print_Text(NoPlayerWin[2], 7, 42);
		print_Text(NoPlayerWin[3], 7, 48);
		print_Text(NoPlayerWin[4], 7, 53);
		print_Text(NoPlayerWin[5], 7, 57);
		print_Text(NoPlayerWin[6], 7, 61);
		print_Text(NoPlayerWin[7], 7, 65);
		print_Symbol('!', 71, 7);
		print_Symbol('!', 73, 7);
	}

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 20; i <= ChieuDai - 16; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng hình rắn chết
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 20, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 20, i); std::cout << char(219);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(144);
		gotoXY(i, y + ChieuRong - 11); std::cout << char(220);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(176);
		gotoXY(i, y + ChieuRong - 6); std::cout << char(220);
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
	}

	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	// Vẽ nền vàng bên dưới
	TextColor(153);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 28; j <= ChieuRong - 10; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	// Vẽ nền đỏ bên dưới
	TextColor(187);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 34; j <= ChieuRong - 5; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 39; j <= ChieuRong; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 12); std::cout << char(205);
	}

	gotoXY(34, 13); cout << "<A/D> TO MOVE NEXT/BACK, <ENTER> TO SELECT";

	TextColor(158);
	print_Text('p', 31, 28);
	print_Number(1, 31, 32);

	print_Symbol(':', 53, 31);

	print_Text('p', 31, 72);
	print_Number(2, 31, 76);
}

int LogicSelectGameOverMode4(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2, int diem, int diem2, int whoWin)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	VeNenGameOver(x, y, ChieuDai, ChieuRong);
	VeRanChet(30, 20, ChieuDai, ChieuRong);
	HienThiSelectGameOver(x, y, ChieuDai, ChieuRong, select);
	VeDiemRanChetMode4(x, y, ChieuDai, ChieuRong, diem, diem2);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				res = 0;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 2;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveDown)
			{
				select++;
			}
			if (phim == KeyBoardP1.MoveUp)
			{
				select--;
			}
			if (select < 1)
			{
				select = 2;
			}
			if (select > 2)
			{
				select = 1;
			}
			HienThiSelectGameOver(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

int MenuGameOverMode4(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int diem, int diem2, int whoWin)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionGameOverMode4(x, y, ChieuDai, ChieuRong, whoWin);
	int result = LogicSelectGameOverMode4(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2, diem, diem2, whoWin);
	return result;
}

//-----------------------------------------------------------------------------------------------------------------------------
//GAME ABOUT
//-----------------------------------------------------------------------------------------------------------------------------

void HienThiAbout(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(204);
	for (int i = x + 38; i <= ChieuDai - 35; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(42, i); cout << char(186);
		gotoXY(64, i); cout << char(186);
	}
	for (int i = x + 39; i <= ChieuDai - 34; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(42, 6); cout << char(201);
	gotoXY(64, 6); cout << char(187);
	gotoXY(42, 10); cout << char(200);
	gotoXY(64, 10); cout << char(188);

	char about[5] = { 'a', 'b', 'o', 'u', 't' };
	TextColor(206);
	print_Text(about[0], 7, 44);
	print_Text(about[1], 7, 48);
	print_Text(about[2], 7, 52);
	print_Text(about[3], 7, 56);
	print_Text(about[4], 7, 60);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 2); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 1; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ các cạnh giữa
		gotoXY(i, y + 27); std::cout << char(205);
		gotoXY(i, y + 40); std::cout << char(205);
	}
	gotoXY(25, 14); cout << "THIS IS THE GAME PROJECT FOR PROGRAMMING TECHNIQUE COURSE, ";
	gotoXY(21, 16); cout << "21CLC_A, HCMUS UNDER THE GUIDANCE OF TEACHER DR.TRUONG TOAN THINH.";
	gotoXY(32, 19); cout << "OUR GROUP NUMBER IS 01, INCLUDING 4 MEMBERS:";
	gotoXY(44, 43); cout << "PRESS <ESC> TO EXIT";

	gotoXY(38, 21); cout << "VO NGOC GIA BAO   - ID: 21127016";
	gotoXY(38, 23); cout << "TRAN NGUYEN HUAN  - ID: 21127050";
	gotoXY(38, 25); cout << "NGUYEN MINH THONG - ID: 21127696";
	gotoXY(38, 27); cout << "NGUYEN PHU TRONG  - ID: 21127708";


	TextColor(244);
	gotoXY(32, 21); cout << char(4);
	gotoXY(32, 23); cout << char(4);
	gotoXY(32, 25); cout << char(4);
	gotoXY(32, 27); cout << char(4);

	TextColor(102);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 28; j <= ChieuRong - 3; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	VeChiTiet1PlayerEndless(35, 31, ChieuDai, ChieuRong);
	VeChiTiet1PlayerEndless2(60, 32, ChieuDai, ChieuRong);
}

int LogicAbout(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	HienThiAbout(x, y, ChieuDai, ChieuRong);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				res = 0;
				inputChoice = true;
			}
		}
	}
	return res;
}

int About(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiAbout(x, y, ChieuDai, ChieuRong);
	int result = LogicAbout(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2);
	return result;
}

//--------------------------------------------------------------------------------------------------------------------------------
//MENU LOAD GAME
//--------------------------------------------------------------------------------------------------------------------------------

void LoadGamePage1(bool getInto, char* ten_nguoi_choi, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int x, int y, int ChieuDai, int ChieuRong,

	MoveKeyBoard& keyboardP1, NguoiChoi* danhSachNguoiChoi)
{
	char mode1[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode1[0], 13, 44);
	print_Text(mode1[1], 13, 50);
	print_Text(mode1[2], 13, 54);
	print_Text(mode1[3], 13, 58);
	print_Number(1, 13, 63);
	TextColor(240);
	gotoXY(39, y + 14); cout << "TYPE: ENDLESS LOOP - NO.PLAYER: 01";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(64, y + 16); cout << "MAP"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(76, y + 16); cout << "SCORE";

	string tmp;
	ifstream In;
	In.open("data.txt", ios::in);
	In >> nData;
	if (nData > 0) {
		getline(In, tmp);
		for (int i = 0; i < nData; i++)
		{
			getline(In, data[i], '\n');
		}
		In.close();
	}
	else
		In.close();


	ifstream fileIn;
	int nNguoiChoi = 0;
	danhSachNguoiChoi = XuatDanhSachNguoiChoi(fileIn, data, nData, nNguoiChoi);

	if (getInto == true)
	{
		int temp = logic_load_game(x, y, danhSachNguoiChoi, nNguoiChoi, keyboardP1, soundEF);
		if (temp == -1)
		{
			gotoXY(28, y + 28); cout << "THERE IS CURRENTLY NO PLAYER/TEAM IN THIS MODE"; gotoXY(60, y + 16); cout << char(186);
		}
		else
		{
			LoadLaiGame(ten_nguoi_choi, diem, ran_dot1, ran1, SPEED, huong1, man, vat_can_so_o, vat_can, danhSachNguoiChoi, temp);
			TrangThai = temp;
		}
	}
}

void LoadGamePage2(bool getInto2, char* ten_nguoi_choi, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int x, int y, int ChieuDai, int ChieuRong,
	MoveKeyBoard& keyboardP1, NguoiChoi* danhSachNguoiChoi)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(2, 13, 63);
	TextColor(240);
	gotoXY(40, y + 14); cout << "TYPE: ADVENTURE - NO.PLAYER: 01";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(64, y + 16); cout << "MAP"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(76, y + 16); cout << "SCORE";

	string tmp;
	ifstream In;
	In.open("data2.txt", ios::in);
	In >> nData;
	if (nData > 0) {
		getline(In, tmp);
		for (int i = 0; i < nData; i++)
		{
			getline(In, data[i], '\n');
		}
		In.close();
	}
	else
		In.close();

	ifstream fileIn;
	int nNguoiChoi = 0;
	danhSachNguoiChoi = XuatDanhSachNguoiChoi(fileIn, data, nData, nNguoiChoi);

	if (getInto2 == true)
	{
		int temp = logic_load_game(x, y, danhSachNguoiChoi, nNguoiChoi, keyboardP1, soundEF);
		if (temp == -1)
		{
			gotoXY(28, y + 28); cout << "THERE IS CURRENTLY NO PLAYER/TEAM IN THIS MODE"; gotoXY(60, y + 16); cout << char(186);
		}
		else
		{
			LoadLaiGame(ten_nguoi_choi, diem, ran_dot1, ran1, SPEED, huong1, man, vat_can_so_o, vat_can, danhSachNguoiChoi, temp);
			TrangThai = temp;
		}
	}
}

void LoadGamePage3(bool getInto3, char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int x, int y, int ChieuDai, int ChieuRong,
	MoveKeyBoard& keyboardP1, NguoiChoi** danhSachNguoiChoi2, NguoiChoi* danhSachNguoiChoi)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(3, 13, 63);
	TextColor(240);
	gotoXY(40, y + 14); cout << "TYPE: ADVENTURE - NO.PLAYER: 02";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(64, y + 16); cout << "MAP"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(76, y + 16); cout << "SCORE";

	string tmp;
	ifstream In;
	In.open("data3.txt", ios::in);
	In >> nData;
	if (nData > 0) {
		getline(In, tmp);
		for (int i = 0; i < nData; i++)
		{
			getline(In, data[i], '\n');
		}
		In.close();
	}
	else
		In.close();

	int nNguoiChoi = 0;
	danhSachNguoiChoi2 = XuatDanhSachNguoiChoi2(In, data, nData, nNguoiChoi);
	if (getInto3 == true)
	{
		int temp = logic_load_game2(x, y, danhSachNguoiChoi2, nNguoiChoi, keyboardP1, soundEF);
		if (temp == -1)
		{
			gotoXY(28, y + 28); cout << "THERE IS CURRENTLY NO PLAYER/TEAM IN THIS MODE"; gotoXY(60, y + 16); cout << char(186);
		}
		else
		{
			LoadLaiGame2(ten_nguoi_choi, ten_nguoi_choi2, diem, diem2, ran_dot1, ran_dot2, ran1, ran2, SPEED, huong1, huong2, man, vat_can_so_o, vat_can, danhSachNguoiChoi2, temp);
			TrangThai = temp;
		}
	}
}

void LoadGamePage4(bool getInto4, char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, int x, int y, int ChieuDai, int ChieuRong,
	MoveKeyBoard& keyboardP1, MoveKeyBoard& keyboardP2, NguoiChoi** danhSachNguoiChoi2, NguoiChoi* danhSachNguoiChoi)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(4, 13, 63);
	TextColor(240);
	gotoXY(41, y + 14); cout << "TYPE: BATTLE - NO.PLAYER: 02";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(64, y + 16); cout << "MAP"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(76, y + 16); cout << "SCORE";

	string tmp;
	ifstream In;
	In.open("data4.txt", ios::in);
	In >> nData;
	if (nData > 0) {
		getline(In, tmp);
		for (int i = 0; i < nData; i++)
		{
			getline(In, data[i], '\n');
		}
		In.close();
	}
	else {
		In.close();
	}

	int nNguoiChoi = 0;
	danhSachNguoiChoi2 = XuatDanhSachNguoiChoi2(In, data, nData, nNguoiChoi);
	if (getInto4 == true)
	{
		int temp = logic_load_game2(x, y, danhSachNguoiChoi2, nNguoiChoi, keyboardP1, soundEF);
		if (temp == -1)
		{
			gotoXY(28, y + 28); cout << "THERE IS CURRENTLY NO PLAYER/TEAM IN THIS MODE"; gotoXY(60, y + 16); cout << char(186);
		}
		else
		{
			LoadLaiGame2(ten_nguoi_choi, ten_nguoi_choi2, diem, diem2, ran_dot1, ran_dot2, ran1, ran2, SPEED, huong1, huong2, man, vat_can_so_o, vat_can, danhSachNguoiChoi2, temp);
			TrangThai = temp;
		}
	}
}

void HienThiLoadGame(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	TextColor(204);
	for (int i = x + 31; i <= ChieuDai - 27; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(34, i); cout << char(186);
		gotoXY(72, i); cout << char(186);
	}
	for (int i = x + 31; i <= ChieuDai - 27; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(34, 6); cout << char(201);
	gotoXY(72, 6); cout << char(187);
	gotoXY(34, 10); cout << char(200);
	gotoXY(72, 10); cout << char(188);

	char load[8] = { 'l', 'o', 'a', 'd', 'g', 'a', 'm', 'e'};
	TextColor(206);
	print_Text(load[0], 7, 36);
	print_Text(load[1], 7, 40);
	print_Text(load[2], 7, 44);
	print_Text(load[3], 7, 48);
	print_Text(load[4], 7, 53);
	print_Text(load[5], 7, 58);
	print_Text(load[6], 7, 62);
	print_Text(load[7], 7, 68);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 2); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 1; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		gotoXY(i, y + 15); std::cout << char(205);
		gotoXY(i, y + 17); std::cout << char(205);
		gotoXY(i, y + 40); std::cout << char(205);
	}
	gotoXY(21, y + 41); cout << "<= LEFT KEY: " << (char)toupper(keyboardP1.MoveLeft) << ", <" << (char)toupper(keyboardP1.MoveUp) << "/" << (char)toupper(keyboardP1.MoveDown) << "> : UP/DOWN, <ENTER>: SELECT, " << (char)toupper(keyboardP1.MoveRight) << ": RIGHT KEY =>";
}

int LogicLoadGame(char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, int x, int y, int ChieuDai, int ChieuRong,
	MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, NguoiChoi* danhSachNguoiChoi, NguoiChoi** danhSachNguoiChoi2)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	bool change = false;
	bool getInto = false;
	bool getInto2 = false;
	bool getInto3 = false;
	bool getInto4 = false;

	HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	LoadGamePage1(getInto, ten_nguoi_choi, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
		man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong, 
		KeyBoardP1, danhSachNguoiChoi);
	TextColor(244);
	gotoXY(30, y + 26); cout << "PRESS <ENTER> TO CHOOSE THIS MODE FOR LOADING GAME";
	while (inputChoice == false)
	{
		if (select == 1 && change == true)
		{
			change = false;
			HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
			LoadGamePage1(getInto, ten_nguoi_choi, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
				man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong,
				KeyBoardP1, danhSachNguoiChoi);
			TextColor(244);
			gotoXY(30, y + 26); cout << "PRESS <ENTER> TO CHOOSE THIS MODE FOR LOADING GAME";
		}
		if (select == 2 && change == true)
		{
			change = false;
			HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
			LoadGamePage2(getInto2, ten_nguoi_choi, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
				man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong,
				KeyBoardP1, danhSachNguoiChoi);
			TextColor(244);
			gotoXY(30, y + 26); cout << "PRESS <ENTER> TO CHOOSE THIS MODE FOR LOADING GAME";
		}
		if (select == 3 && change == true)
		{
			change = false;
			HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
			LoadGamePage3(getInto3, ten_nguoi_choi, ten_nguoi_choi2, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
				man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong,
				KeyBoardP1, danhSachNguoiChoi2, danhSachNguoiChoi);
			TextColor(244);
			gotoXY(30, y + 26); cout << "PRESS <ENTER> TO CHOOSE THIS MODE FOR LOADING GAME";
		}
		if (select == 4 && change == true)
		{
			change = false;
			HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
			LoadGamePage4(getInto4, ten_nguoi_choi, ten_nguoi_choi2, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
				man, vat_can, vat_can_so_o, data, nData, nguoiChoi, nguoiChoi2, TrangThai, x, y, ChieuDai, ChieuRong,
				KeyBoardP1, KeyBoardP2, danhSachNguoiChoi2, danhSachNguoiChoi);
			TextColor(244);
			gotoXY(30, y + 26); cout << "PRESS <ENTER> TO CHOOSE THIS MODE FOR LOADING GAME";
		}
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				res = 0;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveRight)
			{
				change = true;
				select++;
			}
			if (phim == KeyBoardP1.MoveLeft)
			{
				change = true;
				select--;
			}
			if (select > 4)
			{
				select = 1;
			}
			if (select < 1)
			{
				select = 4;
			}
			if (int(phim) == 13 && select == 1)
			{
				getInto = true;
				HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
				LoadGamePage1(getInto, ten_nguoi_choi, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
					man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong, KeyBoardP1, danhSachNguoiChoi);
				inputChoice = true;
				res = 1;
			}
			if (int(phim) == 13 && select == 2)
			{
				getInto2 = true;
				HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
				LoadGamePage2(getInto2, ten_nguoi_choi, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
					man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong, KeyBoardP1, danhSachNguoiChoi);
				inputChoice = true;
				res = 2;
			}
			if (int(phim) == 13 && select == 3)
			{
				getInto3 = true;
				HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
				LoadGamePage3(getInto3, ten_nguoi_choi, ten_nguoi_choi2, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
					man, vat_can, vat_can_so_o, data, nData, nguoiChoi, TrangThai, x, y, ChieuDai, ChieuRong, KeyBoardP1, danhSachNguoiChoi2, danhSachNguoiChoi);
				inputChoice = true;
				res = 3;
			}
			if (int(phim) == 13 && select == 4)
			{
				getInto4 = true;
				HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
				LoadGamePage4(getInto4, ten_nguoi_choi, ten_nguoi_choi2, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF,
					man, vat_can, vat_can_so_o, data, nData, nguoiChoi, nguoiChoi2, TrangThai, x, y, ChieuDai, ChieuRong, KeyBoardP1, KeyBoardP2, danhSachNguoiChoi2, danhSachNguoiChoi);
				inputChoice = true;
				res = 4;
			}
		}
	}
	return res;
}

int LoadGame(char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], int& ran_dot1, ToaDo ran2[], int& ran_dot2, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int soundEF,
	int& man, ToaDo vat_can[], int vat_can_so_o, string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, NguoiChoi* danhSachNguoiChoi, NguoiChoi** danhSachNguoiChoi2)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiLoadGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	int result = LogicLoadGame(ten_nguoi_choi, ten_nguoi_choi2, ran1, ran_dot1, ran2, ran_dot2, diem, diem2, SPEED, huong1, huong2, soundEF, man, vat_can, vat_can_so_o, data, nData,
		nguoiChoi, nguoiChoi2, TrangThai, x, y, ChieuDai, ChieuRong, KeyBoardP1, KeyBoardP2, danhSachNguoiChoi, danhSachNguoiChoi2);
	return result;
}

//--------------------------------------------------------------------------------------------------------------------------------
// SAVE GAME
//--------------------------------------------------------------------------------------------------------------------------------

void VeHienThiNutSaveGame(int x, int y, int ChieuDai, int ChieuRong)
{
	char button[3][5] = { " " };
	button[0][1] = button[0][2] = button[0][3] = char(223); button[0][0] = button[0][4] = char(219);
	button[1][0] = button[1][4] = char(219); button[1][1] = char(32); button[1][3] = char(32);
	button[2][1] = button[2][2] = button[2][3] = char(220); button[2][0] = button[2][4] = char(219);

	button[1][2] = char(219);

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			if (i == 1 && j == 2)
			{
				TextColor(240);
			}
			else
			{
				TextColor(237);
			}
			cout << button[i][j];
		}
	}
}

void XoaHienThiNutSaveGame(int x, int y, int ChieuDai, int ChieuRong)
{
	char button[3][5] = { " " };
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			button[i][j] = char(219);
		}
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j, y + i);
			TextColor(15);
			cout << button[i][j];
		}
	}
}

void NutExitSaveGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char exitGame[8] = { 'e', 'x', 'i', 't', 'g', 'a', 'm', 'e' };
	if (selection == 2)
	{
		TextColor(244);
		print_Text(exitGame[0], 31, 34);
		print_Text(exitGame[1], 31, 38);
		print_Text(exitGame[2], 31, 44);
		print_Text(exitGame[3], 31, 46);
		print_Text(exitGame[4], 31, 51);
		print_Text(exitGame[5], 31, 56);
		print_Text(exitGame[6], 31, 60);
		print_Text(exitGame[7], 31, 66);

		VeHienThiNutSaveGame(24, 31, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(246);
		print_Text(exitGame[0], 31, 34);
		print_Text(exitGame[1], 31, 38);
		print_Text(exitGame[2], 31, 44);
		print_Text(exitGame[3], 31, 46);
		print_Text(exitGame[4], 31, 51);
		print_Text(exitGame[5], 31, 56);
		print_Text(exitGame[6], 31, 60);
		print_Text(exitGame[7], 31, 66);

		XoaHienThiNutSaveGame(24, 31, ChieuDai, ChieuRong);
	}
}

void NutReturnSaveGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char returnOption[12] = { 'r', 'e', 't', 'u','r','n','o','p','t','i','o','n' };
	if (selection == 1)
	{
		TextColor(244);
		print_Text(returnOption[0], 24, 34);
		print_Text(returnOption[1], 24, 38);
		print_Text(returnOption[2], 24, 42);
		print_Text(returnOption[3], 24, 46);
		print_Text(returnOption[4], 24, 50);
		print_Text(returnOption[5], 24, 54);
		print_Text(returnOption[6], 24, 60);
		print_Text(returnOption[7], 24, 64);
		print_Text(returnOption[8], 24, 68);
		print_Text(returnOption[9], 24, 72);
		print_Text(returnOption[10], 24, 74);
		print_Text(returnOption[11], 24, 78);

		VeHienThiNutSaveGame(24, 24, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(246);
		print_Text(returnOption[0], 24, 34);
		print_Text(returnOption[1], 24, 38);
		print_Text(returnOption[2], 24, 42);
		print_Text(returnOption[3], 24, 46);
		print_Text(returnOption[4], 24, 50);
		print_Text(returnOption[5], 24, 54);
		print_Text(returnOption[6], 24, 60);
		print_Text(returnOption[7], 24, 64);
		print_Text(returnOption[8], 24, 68);
		print_Text(returnOption[9], 24, 72);
		print_Text(returnOption[10], 24, 74);
		print_Text(returnOption[11], 24, 78);

		XoaHienThiNutSaveGame(24, 24, ChieuDai, ChieuRong);
	}
}

void HienThiSelectSaveGame(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	NutReturnSaveGame(x, y, ChieuDai, ChieuRong, selection);
	NutExitSaveGame(x, y, ChieuDai, ChieuRong, selection);
}

void HienThiNenSelectSaveGame(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 20); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 11); std::cout << char(220);
	}
	for (int i = y + 20; i <= ChieuRong - 9; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 21; j <= ChieuRong - 10; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		gotoXY(i, y + 26); std::cout << char(223);
	}
}

void HienThiSaveGame(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	TextColor(204);
	for (int i = x + 31; i <= ChieuDai - 27; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(206);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(34, i); cout << char(186);
		gotoXY(72, i); cout << char(186);
	}
	for (int i = x + 31; i <= ChieuDai - 27; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(34, 6); cout << char(201);
	gotoXY(72, 6); cout << char(187);
	gotoXY(34, 10); cout << char(200);
	gotoXY(72, 10); cout << char(188);

	char save[8] = { 's', 'a', 'v', 'e', 'g', 'a', 'm', 'e' };
	TextColor(206);
	print_Text(save[0], 7, 36);
	print_Text(save[1], 7, 40);
	print_Text(save[2], 7, 44);
	print_Text(save[3], 7, 49);
	print_Text(save[4], 7, 53);
	print_Text(save[5], 7, 58);
	print_Text(save[6], 7, 62);
	print_Text(save[7], 7, 68);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 26); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong - 24; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 25; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		gotoXY(i, y + 14); std::cout << char(205);
	}
	gotoXY(33, y + 12); cout << " USES <ENTER>: SELECT, USES <W/S>: UP/DOWN";
}

int LogicSaveGame(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	HienThiNenSelectSaveGame(x, y, ChieuDai, ChieuRong);
	HienThiSelectSaveGame(x, y, ChieuDai, ChieuRong, select);
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(13) && select == 1)
			{
				res = 1;
				inputChoice = true;
			}
			if (phim == char(13) && select == 2)
			{
				res = 2;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveUp)
			{
				select--;
			}
			if (phim == KeyBoardP1.MoveDown)
			{
				select++;
			}
			if (select > 2)
			{
				select = 1;
			}
			if (select < 1)
			{
				select = 2;
			}
			HienThiSelectSaveGame(x, y, ChieuDai, ChieuRong, select);
		}
	}
	return res;
}

int SaveGame(char* ten_nguoi_choi, int diem, int ran_dot, ToaDo* ran, int SPEED, int huong, int man, int vat_can_dong_so_o,
	ToaDo vat_can[], string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiSaveGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	LuuGame(ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, vat_can_dong_so_o, vat_can, data, nData, nguoiChoi, TrangThai, mode);
	int result = LogicSaveGame(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2);
	return result;
}

int SaveGame2(char* ten_nguoi_choi1, char* ten_nguoi_choi2, int diem1, int diem2, int ran_dot1, ToaDo* ran1, int ran_dot2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man, int vat_can_dong_so_o,
	ToaDo vat_can[], string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiSaveGame(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	LuuGame2(ten_nguoi_choi1, ten_nguoi_choi2, diem1, diem2, ran_dot1, ran1, ran_dot2, ran2, SPEED, huong1, huong2, man, vat_can_dong_so_o, vat_can, data, nData, nguoiChoi1, nguoiChoi2, TrangThai, mode);
	int result = LogicSaveGame(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2);
	return result;
}

//------------------------------------------------------------------------------------------------------------------
//LEADER BOARD
//------------------------------------------------------------------------------------------------------------------

void LeaderBoardPage1(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	char mode1[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode1[0], 13, 44);
	print_Text(mode1[1], 13, 50);
	print_Text(mode1[2], 13, 54);
	print_Text(mode1[3], 13, 58);
	print_Number(1, 13, 63);
	TextColor(240);
	gotoXY(39, y + 14); cout << "TYPE: ENDLESS LOOP - NO.PLAYER: 01";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(62, y + 16); cout << "SCORE"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(74, y + 16); cout << "TIME PLAYED";

	int so_luong = 0;
	BangDiem bangDiem[5];
	ifstream fileIn;
	fileIn.open("bangdiem.txt", ios::in);
	DocFileBangDiem(fileIn, bangDiem, so_luong);
	fileIn.close();
	GiaoDienBangDiem(x, y, ChieuDai, ChieuRong, bangDiem, so_luong);
}

void LeaderBoardPage2(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(2, 13, 63);
	TextColor(240);
	gotoXY(40, y + 14); cout << "TYPE: ADVENTURE - NO.PLAYER: 01";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(62, y + 16); cout << "SCORE"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(74, y + 16); cout << "TIME PLAYED";

	int so_luong = 0;
	BangDiem bangDiem[5];
	ifstream fileIn;
	fileIn.open("bangdiem2.txt", ios::in);
	DocFileBangDiem(fileIn, bangDiem, so_luong);
	fileIn.close();
	GiaoDienBangDiem(x, y, ChieuDai, ChieuRong, bangDiem, so_luong);
}

void LeaderBoardPage3(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(3, 13, 63);
	TextColor(240);
	gotoXY(40, y + 14); cout << "TYPE: ADVENTURE - NO.PLAYER: 02";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(62, y + 16); cout << "SCORE"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(74, y + 16); cout << "TIME PLAYED";

	int so_luong = 0;
	BangDiem bangDiem[5];
	ifstream fileIn;
	fileIn.open("bangdiem3.txt", ios::in);
	DocFileBangDiem(fileIn, bangDiem, so_luong);
	fileIn.close();
	GiaoDienBangDiem(x, y, ChieuDai, ChieuRong, bangDiem, so_luong);
}

void LeaderBoardPage4(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	char mode2[4] = { 'm', 'o', 'd', 'e' };
	TextColor(241);
	print_Text(mode2[0], 13, 44);
	print_Text(mode2[1], 13, 50);
	print_Text(mode2[2], 13, 54);
	print_Text(mode2[3], 13, 58);
	print_Number(4, 13, 63);
	TextColor(240);
	gotoXY(41, y + 14); cout << "TYPE: BATTLE - NO.PLAYER: 02";

	gotoXY(22, y + 16); cout << "NO."; gotoXY(26, y + 16); cout << char(186);
	gotoXY(33, y + 16); cout << "NAME OF PLAYER/TEAM"; gotoXY(60, y + 16); cout << char(186);
	gotoXY(62, y + 16); cout << "SCORE"; gotoXY(69, y + 16); cout << char(186);
	gotoXY(74, y + 16); cout << "TIME PLAYED";

	gotoXY(28, y + 27); cout << "THE RECORDED FOR THIS MODE TEMPORARILY NOT EXISTS!";
}

void HienThiLeaderBoard(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	TextColor(85);
	for (int i = x + 27; i <= ChieuDai - 22; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(91);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(30, i); cout << char(186);
		gotoXY(77, i); cout << char(186);
	}
	for (int i = x + 27; i <= ChieuDai - 22; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(30, 6); cout << char(201);
	gotoXY(77, 6); cout << char(187);
	gotoXY(30, 10); cout << char(200);
	gotoXY(77, 10); cout << char(188);

	char LB[11] = { 'l', 'e', 'a', 'd', 'e', 'r', 'b', 'o', 'a', 'r', 'd'};
	TextColor(91);
	print_Text(LB[0], 7, 32);
	print_Text(LB[1], 7, 36);
	print_Text(LB[2], 7, 40);
	print_Text(LB[3], 7, 44);
	print_Text(LB[4], 7, 48);
	print_Text(LB[5], 7, 52);
	print_Text(LB[6], 7, 57);
	print_Text(LB[7], 7, 61);
	print_Text(LB[8], 7, 65);
	print_Text(LB[9], 7, 69);
	print_Text(LB[10], 7, 73);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng
		gotoXY(i, y + ChieuRong - 2); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 15, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 15, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 1; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = x + 16; i <= ChieuDai - 12; i++)
	{
		gotoXY(i, y + 15); std::cout << char(205);
		gotoXY(i, y + 17); std::cout << char(205);
		gotoXY(i, y + 40); std::cout << char(205);
	}
	gotoXY(21, y + 41); cout << "<= LEFT KEY: " << (char)toupper(keyboardP1.MoveLeft) << ", <" << (char)toupper(keyboardP1.MoveUp) << "/" << (char)toupper(keyboardP1.MoveDown) << "> : UP/DOWN, <ENTER>: SELECT, " << (char)toupper(keyboardP1.MoveRight) << ": RIGHT KEY =>";
}

int LogicLeaderBoard(int x, int y, int ChieuDai, int ChieuRong, MoveKeyBoard& keyboardP1)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	bool change = false;
	HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, keyboardP1);
	LeaderBoardPage1(x, y, ChieuDai, ChieuRong, keyboardP1);
	while (inputChoice == false)
	{
		if (select == 1 && change == true)
		{
			change = false;
			HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, keyboardP1);
			LeaderBoardPage1(x, y, ChieuDai, ChieuRong, keyboardP1);
		}
		if (select == 2 && change == true)
		{
			change = false;
			HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, keyboardP1);
			LeaderBoardPage2(x, y, ChieuDai, ChieuRong, keyboardP1);
		}
		if (select == 3 && change == true)
		{
			change = false;
			HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, keyboardP1);
			LeaderBoardPage3(x, y, ChieuDai, ChieuRong, keyboardP1);
		}
		if (select == 4 && change == true)
		{
			change = false;
			HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, keyboardP1);
			LeaderBoardPage4(x, y, ChieuDai, ChieuRong, keyboardP1);
		}
		if (_kbhit())
		{
			char phim = _getch();
			if (phim == char(27))
			{
				res = 0;
				inputChoice = true;
			}
			if (phim == keyboardP1.MoveRight)
			{
				change = true;
				select++;
			}
			if (phim == keyboardP1.MoveLeft)
			{
				change = true;
				select--;
			}
			if (select > 4)
			{
				select = 1;
			}
			if (select < 1)
			{
				select = 4;
			}
		}
	}
	return res;
}

int LeaderBoard(int soundBG, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;
	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiLeaderBoard(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	int result = LogicLeaderBoard(x, y, ChieuDai, ChieuRong, KeyBoardP1);
	return result;
}

//-----------------------------------------------------------------------------------------------------------------------------------------------
//MENU WINNING
//-----------------------------------------------------------------------------------------------------------------------------------------------

void VeRanThang(int x, int y, int ChieuDai, int ChieuRong)
{
	char sDeadTail[6][10] = { " " };
	sDeadTail[0][8] = sDeadTail[0][9] = char(219);
	sDeadTail[1][8] = sDeadTail[1][9] = char(219);
	sDeadTail[2][8] = sDeadTail[2][9] = char(219);
	sDeadTail[3][8] = sDeadTail[3][9] = char(219);
	sDeadTail[4][8] = sDeadTail[4][9] = char(219);
	sDeadTail[5][8] = sDeadTail[5][9] = char(219);

	sDeadTail[4][5] = sDeadTail[4][6] = sDeadTail[4][7] = char(220);
	sDeadTail[5][5] = sDeadTail[5][6] = sDeadTail[5][7] = char(219);

	sDeadTail[1][2] = sDeadTail[1][1] = sDeadTail[1][0] = char(220);
	sDeadTail[1][4] = sDeadTail[1][3] = char(220);
	sDeadTail[2][4] = sDeadTail[2][3] = char(219); sDeadTail[2][1] = sDeadTail[2][2] = char(223);
	sDeadTail[3][4] = sDeadTail[3][3] = char(219);
	sDeadTail[4][4] = sDeadTail[4][3] = char(219);
	sDeadTail[5][4] = sDeadTail[5][3] = char(219);

	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			gotoXY(x + j + 3, y + i);
			TextColor(234);
			cout << sDeadTail[i][j];
		}
	}

	char sDeadBody[6][20] = { " " };
	sDeadBody[1][16] = char(220); sDeadBody[1][17] = sDeadBody[1][18] = sDeadBody[1][19] = char(219);
	sDeadBody[2][16] = sDeadBody[2][17] = sDeadBody[2][18] = sDeadBody[2][19] = char(219);
	sDeadBody[3][16] = sDeadBody[3][17] = char(219);
	sDeadBody[4][16] = sDeadBody[4][17] = char(219);
	sDeadBody[5][16] = char(219); sDeadBody[5][17] = char(219);
	sDeadBody[4][15] = char(220); sDeadBody[5][15] = char(219);
	sDeadBody[4][14] = char(220); sDeadBody[5][14] = char(219);
	sDeadBody[4][13] = char(219); sDeadBody[5][13] = char(219);
	sDeadBody[4][12] = char(219); sDeadBody[5][12] = char(219);
	sDeadBody[3][12] = sDeadBody[3][13] = char(219);
	sDeadBody[2][12] = sDeadBody[2][13] = char(219);
	sDeadBody[1][12] = sDeadBody[1][13] = char(219);
	sDeadBody[0][12] = char(219); sDeadBody[0][13] = char(219);
	sDeadBody[0][11] = char(219); sDeadBody[1][11] = char(223);
	sDeadBody[0][10] = char(219); sDeadBody[1][10] = char(223);
	sDeadBody[0][9] = char(219); sDeadBody[1][9] = char(223);
	sDeadBody[0][8] = char(219); sDeadBody[1][8] = char(223);
	sDeadBody[0][7] = char(219);
	sDeadBody[1][7] = sDeadBody[1][8] = char(219);
	sDeadBody[2][7] = sDeadBody[2][8] = char(219);
	sDeadBody[3][7] = sDeadBody[3][8] = char(219);
	sDeadBody[4][7] = sDeadBody[4][8] = char(219);
	sDeadBody[5][7] = char(219);  sDeadBody[5][8] = char(219);
	sDeadBody[5][6] = char(219); sDeadBody[4][6] = char(220);
	sDeadBody[5][6] = char(219); sDeadBody[4][6] = char(220);
	sDeadBody[5][5] = char(219); sDeadBody[4][5] = char(220);
	sDeadBody[5][4] = char(219); sDeadBody[4][4] = char(219); sDeadBody[5][3] = char(219);
	sDeadBody[4][3] = sDeadBody[4][4] = char(219);
	sDeadBody[3][3] = sDeadBody[3][4] = char(219);
	sDeadBody[2][3] = sDeadBody[2][4] = char(219);
	sDeadBody[1][3] = sDeadBody[1][4] = char(219);
	sDeadBody[0][3] = sDeadBody[0][4] = char(219);
	sDeadBody[0][2] = char(219); sDeadBody[1][2] = char(223);
	sDeadBody[0][1] = char(219); sDeadBody[1][1] = char(223);
	sDeadBody[0][0] = char(219); sDeadBody[1][0] = char(223);

	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			gotoXY(x + j + 13, y + i);
			TextColor(234);
			cout << sDeadBody[i][j];
		}
	}

	char sDeadHead[5][13] = { " " };
	sDeadHead[0][4] = char(220);
	sDeadHead[0][5] = sDeadHead[0][6] = sDeadHead[0][7] = sDeadHead[0][8] = char(219); sDeadHead[0][9] = char(220);
	sDeadHead[1][3] = sDeadHead[1][4] = sDeadHead[1][5] = sDeadHead[1][6] = sDeadHead[1][7] = sDeadHead[1][8] = sDeadHead[1][9] = char(219);
	sDeadHead[1][10] = sDeadHead[1][11] = sDeadHead[1][12] = char(219);
	sDeadHead[2][3] = sDeadHead[2][4] = sDeadHead[2][5] = sDeadHead[2][6] = sDeadHead[2][7] = sDeadHead[2][8] = sDeadHead[2][9] = char(219);
	sDeadHead[2][10] = sDeadHead[2][11] = sDeadHead[2][12] = char(219);
	sDeadHead[3][2] = char(223);
	sDeadHead[3][3] = sDeadHead[3][4] = sDeadHead[3][5] = sDeadHead[3][6] = sDeadHead[3][7] = sDeadHead[3][8] = sDeadHead[3][9] = char(219);
	sDeadHead[4][4] = char(223); sDeadHead[4][5] = sDeadHead[4][6] = sDeadHead[4][7] = sDeadHead[4][8] = sDeadHead[4][9] = char(219);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			gotoXY(x + j + 30, y + i);
			TextColor(234);
			cout << sDeadHead[i][j];
		}
	}

	char sDeadEye[5][5] = { " " };
	sDeadEye[1][1] = char(219);
	sDeadEye[0][2] = char(219);
	sDeadEye[1][3] = char(219);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j + 34, y + i);
			TextColor(160);
			cout << sDeadEye[i][j];
		}
	}

	char sDeadMouth[3][5] = { " " };
	sDeadMouth[0][0] = sDeadMouth[0][1] = sDeadMouth[0][2] = sDeadMouth[0][4] = char(223);
	sDeadMouth[0][3] = char(219);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			gotoXY(x + j + 40, y + i + 3);
			TextColor(228);
			cout << sDeadMouth[i][j];
		}
	}
}


void NutNewGameWin(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char newgame[7] = { 'n', 'e', 'w', 'g', 'a', 'm', 'e' };
	if (selection == 1)
	{
		TextColor(180);
		print_Text(newgame[0], 37, 37);
		print_Text(newgame[1], 37, 41);
		print_Text(newgame[2], 37, 45);
		print_Text(newgame[3], 37, 52);
		print_Text(newgame[4], 37, 57);
		print_Text(newgame[5], 37, 61);
		print_Text(newgame[6], 37, 67);

		VeHienThiNut(29, 37, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(184);
		print_Text(newgame[0], 37, 37);
		print_Text(newgame[1], 37, 41);
		print_Text(newgame[2], 37, 45);
		print_Text(newgame[3], 37, 52);
		print_Text(newgame[4], 37, 57);
		print_Text(newgame[5], 37, 61);
		print_Text(newgame[6], 37, 67);

		XoaHienThiNut(29, 37, ChieuDai, ChieuRong);
	}
}

void NutReturnGameWin(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	char returnMenu[10] = { 'r', 'e', 't', 'u', 'r', 'n', 'm', 'e', 'n', 'u' };
	if (selection == 2)
	{
		TextColor(180);
		print_Text(returnMenu[0], 42, 37);
		print_Text(returnMenu[1], 42, 41);
		print_Text(returnMenu[2], 42, 45);
		print_Text(returnMenu[3], 42, 49);
		print_Text(returnMenu[4], 42, 53);
		print_Text(returnMenu[5], 42, 57);
		print_Text(returnMenu[6], 42, 62);
		print_Text(returnMenu[7], 42, 68);
		print_Text(returnMenu[8], 42, 72);
		print_Text(returnMenu[9], 42, 76);

		VeHienThiNut(29, 42, ChieuDai, ChieuRong);
	}
	else
	{
		TextColor(184);
		print_Text(returnMenu[0], 42, 37);
		print_Text(returnMenu[1], 42, 41);
		print_Text(returnMenu[2], 42, 45);
		print_Text(returnMenu[3], 42, 49);
		print_Text(returnMenu[4], 42, 53);
		print_Text(returnMenu[5], 42, 57);
		print_Text(returnMenu[6], 42, 62);
		print_Text(returnMenu[7], 42, 68);
		print_Text(returnMenu[8], 42, 72);
		print_Text(returnMenu[9], 42, 76);

		XoaHienThiNut(29, 42, ChieuDai, ChieuRong);
	}
}

void HienThiSelectGameWin(int x, int y, int ChieuDai, int ChieuRong, int selection)
{
	NutNewGameOver(x, y, ChieuDai, ChieuRong, selection);
	NutReturnGameOver(x, y, ChieuDai, ChieuRong, selection);
}

void VeDiemRanThang(int x, int y, int ChieuDai, int ChieuRong, int diem)
{
	char point[2] = { 'X', 'j' };
	TextColor(158);
	print_Text(point[0], 31, 57);
	print_Text(point[0], 31, 62);
	print_Text(point[0], 31, 67);
	print_Text(point[0], 31, 72);
	print_Text(point[0], 31, 77);

	int soDonVi = 0;
	int soHangChuc = 0;
	int soHangTram = 0;
	int soHangNghin = 0;
	int soChucNghin = 0;

	soDonVi = diem % 10;
	soHangChuc = diem / 10 % 10;
	soHangTram = diem / 100 % 10;
	soHangNghin = diem / 1000 % 10;
	soChucNghin = diem / 10000 % 10;

	int i = 10;
	int rand = 0;
	print_Text(point[1], 31, 77);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 77);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 77);
	print_Number(soDonVi, 31, 77);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 72);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 72);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 72);
	print_Number(soHangChuc, 31, 72);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 67);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 67);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 67);
	print_Number(soHangTram, 31, 67);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 62);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 62);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 62);
	print_Number(soHangNghin, 31, 62);

	i = 10;
	rand = 0;
	print_Text(point[1], 31, 57);
	while (i > 0)
	{
		rand++;
		print_Number(rand, 31, 57);
		Sleep(50);
		if (rand == 10) rand = 0;
		i--;
	}
	print_Text(point[1], 31, 57);
	print_Number(soChucNghin, 31, 57);
}

void HienThiOptionGameWin(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(221);
	for (int i = x + 27; i <= ChieuDai - 24; i++)
	{
		for (int j = y + 4; j <= ChieuRong - 34; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(222);
	for (int i = y + 5; i <= ChieuRong - 35; i++)
	{
		gotoXY(31, i); cout << char(186);
		gotoXY(74, i); cout << char(186);
	}
	for (int i = x + 28; i <= ChieuDai - 24; i++)
	{
		gotoXY(i, 6); cout << char(205);
		gotoXY(i, 10); cout << char(205);
	}
	gotoXY(31, 6); cout << char(201);
	gotoXY(74, 6); cout << char(187);
	gotoXY(31, 10); cout << char(200);
	gotoXY(74, 10); cout << char(188);

	char gamewin[7] = { 'y', 'o', 'u', 'w', 'o', 'n', '!' };
	TextColor(222);
	print_Text(gamewin[0], 7, 40);
	print_Text(gamewin[1], 7, 44);
	print_Text(gamewin[2], 7, 48);
	print_Text(gamewin[3], 7, 52);
	print_Text(gamewin[4], 7, 58);
	print_Text(gamewin[5], 7, 62);
	print_Symbol('!', 66, 7);

	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 20; i <= ChieuDai - 16; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng hình rắn chết
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong + 1; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 20, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 20, i); std::cout << char(219);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(144);
		gotoXY(i, y + ChieuRong - 11); std::cout << char(220);
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh dưới cùng hình khung điểm
		TextColor(176);
		gotoXY(i, y + ChieuRong - 6); std::cout << char(220);
		gotoXY(i, y + ChieuRong - 1); std::cout << char(220);
	}

	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	// Vẽ nền vàng bên dưới
	TextColor(153);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 28; j <= ChieuRong - 10; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	// Vẽ nền đỏ bên dưới
	TextColor(187);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 34; j <= ChieuRong - 5; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 39; j <= ChieuRong; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}
	TextColor(240);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 12); std::cout << char(205);
	}
	for (int i = y + 28; i <= ChieuRong - 9; i++)
	{
		//Vẽ cạnh giữa
		gotoXY(x + ChieuDai - 48, i); std::cout << char(219);
	}

	gotoXY(30, 13); cout << "<A/D> TO MOVE NEXT/BACK, <ENTER> TO SELECT";
	char score[6] = { 's', 'c', 'o', 'r', 'e', '@' };
	TextColor(158);
	print_Symbol(score[5], 26, 31);
	print_Text(score[0], 31, 33);
	print_Text(score[1], 31, 37);
	print_Text(score[2], 31, 41);
	print_Text(score[3], 31, 45);
	print_Text(score[4], 31, 49);

}

void HienThiLeaderGameWin(int x, int y, int ChieuDai, int ChieuRong)
{
	TextColor(240);
	//vẽ viền đen bên ngoài
	for (int i = x + 20; i <= ChieuDai - 16; i++)
	{
		//Vẽ cạnh trên cùng
		gotoXY(i, y + 10); std::cout << char(223);
		//Vẽ cạnh dưới cùng hình rắn chết
		gotoXY(i, y + ChieuRong - 17); std::cout << char(220);
	}
	for (int i = y + 10; i <= ChieuRong - 15; i++)
	{
		//Vẽ cạnh trái
		gotoXY(x + 20, i); std::cout << char(219);
		//Vẽ cạnh phải
		gotoXY(x + ChieuDai - 20, i); std::cout << char(219);
	}
	// Vẽ nền trắng bên trong
	TextColor(15);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= ChieuRong - 16; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	// Vẽ nền trắng bên trong
	TextColor(238);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		for (int j = y + 11; j <= y + 15; j++)
		{
			gotoXY(i, j); cout << char(219);
		}
	}

	char congrats[10] = { 'h', 'i', 'g', 'h', 's', 'c', 'o', 'r', 'e', '!' };
	TextColor(228);
	print_Text(congrats[0], 14, 34);
	print_Text(congrats[1], 14, 38);
	print_Text(congrats[2], 14, 40);
	print_Text(congrats[3], 14, 45);
	print_Text(congrats[4], 14, 51);
	print_Text(congrats[5], 14, 55);
	print_Text(congrats[6], 14, 59);
	print_Text(congrats[7], 14, 63);
	print_Text(congrats[8], 14, 67);
	print_Symbol('!', 71, 14);

	TextColor(240);
	for (int i = x + 21; i <= ChieuDai - 17; i++)
	{
		// Vẽ cạnh giữa
		gotoXY(i, y + 16); std::cout << char(220);
	}
}

int LogicSelectGameWin(int x, int y, int ChieuRong, int ChieuDai, int soundIG, int soundEF, MoveKeyBoard KeyBoardP1, MoveKeyBoard KeyBoardP2, int diem, char* ten_nguoi_choi, BangDiem bangDiem[], int so_luong)
{
	int select = 1;
	int res = MAXINT;
	bool inputChoice = false;
	VeNenGameOver(x, y, ChieuDai, ChieuRong);
	HienThiSelectGameWin(x, y, ChieuDai, ChieuRong, select);
	VeRanThang(30, 20, ChieuDai, ChieuRong);
	VeDiemRanThang(x, y, ChieuDai, ChieuRong, diem);
	Sleep(2000);
	if ((KiemTraTop5(bangDiem, so_luong, ten_nguoi_choi, diem) == true))
	{
		HienThiLeader(x, y, ChieuDai, ChieuRong);
		LuuDanhSachNguoiChoiDiemCaoNhat(bangDiem, so_luong, ten_nguoi_choi, diem);
	}
	while (inputChoice == false)
	{
		if (_kbhit())
		{
			char phim = _getch();
			if (int(phim) == 13 && select == 1)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = 1;
				inputChoice = true;
			}
			if (int(phim) == 13 && select == 2)
			{
				if (soundEF == 1)
				{
					PlaySound(L"SelectEffect.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				res = -1;
				inputChoice = true;
			}
			if (phim == KeyBoardP1.MoveDown)
			{
				select++;
			}
			if (phim == KeyBoardP1.MoveUp)
			{
				select--;
			}
			if (select < 1)
			{
				select = 2;
			}
			if (select > 2)
			{
				select = 1;
			}
			HienThiSelectGameOver(x, y, ChieuDai, ChieuRong, select);
		}
	}
	Sleep(600);
	return res;
}

int MenuWinning(int soundIG, int soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int& diem, char* ten_nguoi_choi, string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int mode)
{
	system("color 8F");
	resizeConsole(890, 840);
	int x = 4;
	int y = 2;
	int ChieuRong = 44;
	int ChieuDai = 98;

	int so_luong = 0;
	BangDiem bangDiem[5];
	ifstream fileIn;

	if (mode == 1)
	{
		fileIn.open("bangdiem.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}
	else if (mode == 2)
	{
		fileIn.open("bangdiem2.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}
	else if (mode == 3)
	{
		fileIn.open("bangdiem3.txt", ios::in);
		DocFileBangDiem(fileIn, bangDiem, so_luong);
		fileIn.close();
	}

	noCursorType();
	VeVienMenu(x, y, ChieuDai, ChieuRong);
	VeTrangTriMenu(x, y, ChieuDai, ChieuRong);
	HienThiOptionGameWin(x, y, ChieuDai, ChieuRong);
	int result = LogicSelectGameWin(x, y, ChieuRong, ChieuDai, soundIG, soundEF, KeyBoardP1, KeyBoardP2, diem, ten_nguoi_choi, bangDiem, so_luong);
	return result;
}