#pragma once
#pragma comment(lib, "winmm.lib")
#include <cstdlib>
#include "c_snake.h"

void AnQuaThuongMode2(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& SPEED, int& diem, int x, int y, int ChieuRong,
	ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundIG, int soundEF, bool checkPause,
	bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime);

bool KiemTraThuaMan1(ToaDo ran[], int ran_dot, ToaDo 
	[], int KichThuocVatCan);

void Man1Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode);