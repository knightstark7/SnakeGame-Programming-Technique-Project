#pragma once
#pragma comment(lib, "winmm.lib")
#include <cstdlib>
#include "c_snake.h"

void Man5Mode3(char* ten_nguoi_choi, char* ten_nguoi_choi2, ToaDo ran1[], ToaDo ran2[], int& ran_dot1, int& ran_dot2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong1, int& huong2, int& man, ToaDo vat_can[], int vat_can_so_o,
	string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& KeyBoardP1, MoveKeyBoard& KeyBoardP2, int mode);