#include "c_scoreboard.h"
#include "c_text.h"
#include "c_mylib.h"
#include <iostream>

void DocFileBangDiem(ifstream& fileIn, BangDiem bangDiem[], int& so_luong)
{
	fileIn >> so_luong;
	for (int i = 0; i < so_luong; i++)
	{
		fileIn >> bangDiem[i].TrangThai;
		char c;
		fileIn >> c;
		fileIn.getline(bangDiem[i].ten_nguoi_choi, 40, ',');
		fileIn >> bangDiem[i].diem;
	}
}

void XuatFileBangDiem(ofstream& fileOut, BangDiem bangDiem[], int so_luong)
{
	fileOut << so_luong << endl;
	for (int i = 0; i < so_luong; i++)
	{
		fileOut << bangDiem[i].TrangThai << ",";
		fileOut << bangDiem[i].ten_nguoi_choi << ",";
		fileOut << bangDiem[i].diem << "\n";
	}
}

bool KiemTraTop5(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem)
{
	int i;
	for (i = 0; i < so_luong; i++)
	{
		if (bangDiem[i].diem < diem)
		{
			return true;
		}
	}
	return false;
}


void XapSepLaiBangDiem(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem)
{
	int i;
	int flag = 0; // Kh�ng n?m trong top 5 ng??i ch?i cao nh?t
	for (i = 0; i < so_luong; i++)
	{
		if (bangDiem[i].diem < diem)
		{
			flag = 1; // N?m trong top 5 ng??i ch?i cao nh?t
			break;
		}
	}
	if (flag)
	{
		if (so_luong < 5)
		{
			so_luong++;
		}
		for (int j = so_luong - 1; j > i; j--)
		{
			bangDiem[j] = bangDiem[j - 1];
			bangDiem[j].TrangThai++;
		}
		strcpy_s(bangDiem[i].ten_nguoi_choi, 40, ten_nguoi_choi);
		bangDiem[i].diem = diem;
	}
	else if (so_luong < 5)
	{
		bangDiem[so_luong].TrangThai = so_luong + 1;
		strcpy_s(bangDiem[so_luong].ten_nguoi_choi, 40, ten_nguoi_choi);
		bangDiem[so_luong].diem = diem;
		so_luong++;
	}
}

void GiaoDienBangDiem(int x, int y, int ChieuDai, int ChieuRong, BangDiem bangDiem[], int so_luong)
{
	int khoang_cach = 20;

	TextColor(202);
	gotoXY(x + 16, y + khoang_cach + 0 * 4 - 1); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 0 * 4); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 0 * 4 + 1); cout << "                                                                   ";
	
	TextColor(206);
	gotoXY(x + 19, y + khoang_cach + 0 * 4); cout << 0 + 1;
	gotoXY(x + 30, y + khoang_cach + 0 * 4); cout << bangDiem[0].ten_nguoi_choi;
	gotoXY(x + 59, y + khoang_cach + 0 * 4); cout << bangDiem[0].diem;
	gotoXY(x + 74, y + khoang_cach + 0 * 4); cout << "N/A";

	TextColor(238);
	gotoXY(x + 16, y + khoang_cach + 1 * 4 - 1); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 1 * 4); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 1 * 4 + 1); cout << "                                                                   ";

	TextColor(228);
	gotoXY(x + 19, y + khoang_cach + 1 * 4); cout << 1 + 1;
	gotoXY(x + 30, y + khoang_cach + 1 * 4); cout << bangDiem[1].ten_nguoi_choi;
	gotoXY(x + 59, y + khoang_cach + 1 * 4); cout << bangDiem[1].diem;
	gotoXY(x + 74, y + khoang_cach + 1 * 4); cout << "N/A";

	TextColor(221);
	gotoXY(x + 16, y + khoang_cach + 2 * 4 - 1); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 2 * 4); cout << "                                                                   ";
	gotoXY(x + 16, y + khoang_cach + 2 * 4 + 1); cout << "                                                                   ";

	TextColor(222);
	gotoXY(x + 19, y + khoang_cach + 2 * 4); cout << 2 + 1;
	gotoXY(x + 30, y + khoang_cach + 2 * 4); cout << bangDiem[2].ten_nguoi_choi;
	gotoXY(x + 59, y + khoang_cach + 2 * 4); cout << bangDiem[2].diem;
	gotoXY(x + 74, y + khoang_cach + 2 * 4); cout << "N/A";


	TextColor(240);
	for (int i = 3; i < 5; i++)
	{
		gotoXY(x + 19, y + khoang_cach + 3 + i * 3); cout << i + 1;
		gotoXY(x + 30, y + khoang_cach + 3 + i * 3); cout << bangDiem[i].ten_nguoi_choi;
		gotoXY(x + 59, y + khoang_cach + 3 + i * 3); cout << bangDiem[i].diem;
		gotoXY(x + 74, y + khoang_cach + 3 + i * 3); cout << "N/A";
	}
}


void LuuDanhSachNguoiChoiDiemCaoNhat(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem)
{
	if (ten_nguoi_choi == NULL)
	{
		TextColor(240);
		gotoXY(40, 21); cout << "WOW! YOU GOT THE HIGH SCORE";

		gotoXY(42, 22);
		cout << "PLEASE GIVE US YOUR NAME";

		TextColor(244);
		gotoXY(42, 24); cout << char(5);

		TextColor(240);
		gotoXY(43, 24);
		cout << "INPUT: ";

		ten_nguoi_choi = new char[50];
		cin.getline(ten_nguoi_choi, 50);
	}

	XapSepLaiBangDiem(bangDiem, so_luong, ten_nguoi_choi, diem);
	ofstream fileOut;
	fileOut.open("bangdiem.txt", ios::out);
	XuatFileBangDiem(fileOut, bangDiem, so_luong);
	fileOut.close();
}