﻿#include <iostream>
#include "c_mylib.h"
#include "c_snake.h"
#include "c_menu.h"
#include "c_music.h"
#include "c_MapMode1.h"
#include "c_Map1Mode2.h"
#include "c_Map2Mode2.h"
#include "c_Map2Mode3.h"
#include "c_Map3Mode2.h"
#include "c_Map3Mode3.h"
#include "c_Map4Mode2.h"
#include "c_Map4Mode3.h"
#include "c_Map5Mode2.h"
#include "c_Map5Mode3.h"
#include "c_Map1Mode3.h"
#include "c_MapMode4.h"
#include "c_scoreboard.h"
#include "c_savegame.h"
#include <conio.h>
#include <string>
#include <thread>
#include <Windows.h>
#pragma comment(lib, "winmm.lib")
using namespace std;

void PlayGameMode1(char* TenNguoiChoi, ToaDo ran[], int& BodyRan, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int choice, int& exit, int mode)
{
	ManMode1(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong,
		man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, exit, mode);
	system("cls");
	if (man == 0)
	{
		man = 1;
		choice = -1;
		BodyRan = 1;
		KichThuocVatCan = 0;
		huong = 4;
		diem = 0;
		KhoiTaoRan(ran);
	}
}

int PlayGameMode2(char* TenNguoiChoi, ToaDo ran[], int& BodyRan, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int choice, int mode)
{
	bool isWin = false;
	bool isStop = false;
	if (man == 1)
	{
		Man1Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong,
			man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
		system("cls");
	}
	if (man == 3)
	{
		Man2Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong,
			diem,  SPEED, huong, man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
		system("cls");
	}
	if (man == 4)
	{
		Man3Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong,
			diem,  SPEED, huong, man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
		system("cls");
	}
	if (man == 6)
	{
		Man4Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong,
			diem, SPEED, huong, man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
		system("cls");
	}
	if (man == 5)
	{
		Man5Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong,
			diem, SPEED, huong, man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
		system("cls");
	}
	if (man == 2)
	{
		system("cls");
		isWin = true;
		playMusicGame(soundIG, isWin);
		playWinMusicGame(soundIG, isStop);
		int res = MenuWinning(soundIG, soundEF, keyboard, keyboardP2, diem, TenNguoiChoi, data, nData, nguoiChoi, TrangThai, mode);
		if (res == 1)
		{
			playWinMusicGame(soundIG, true);
			man = 1;
			BodyRan = 1;
			KichThuocVatCan = 0;
			huong = 4;
			diem = 0;
			KhoiTaoRan(ran);
			Man1Mode2(TenNguoiChoi, ran, BodyRan, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong,
				man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, keyboard, keyboardP2, mode);
			system("cls");
		}
		if (res == -1)
		{
			return -1;
		}
	}
	if (man == 0)
	{
		man = 1;
		choice = 1;
		BodyRan = 1;
		KichThuocVatCan = 0;
		huong = 4;
		diem = 0;
		KhoiTaoRan(ran);
	}
	return 0;
}

int PlayGameMode3(char* TenNguoiChoi, char* TenNguoiChoi2, ToaDo ran1[], ToaDo ran2[], int& BodyRan1, int& BodyRan2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong1, int& huong2, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboardP1, MoveKeyBoard& keyboardP2, int choice, int mode)
{
	bool isWin = false;
	bool isStop = false;
	if (man == 1)
	{
		Man1Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2,
			man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
		system("cls");
	}
	if (man == 2)
	{
		Man2Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat, KichThuocVatCan,
			data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
		system("cls");
	}
	if (man == 3)
	{
		Man3Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat, KichThuocVatCan,
			data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
		system("cls");
	}
	if (man == 4)
	{
		Man4Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat, KichThuocVatCan,
			data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
		system("cls");
	}
	if (man == 5)
	{
		Man5Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat, KichThuocVatCan,
			data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
		system("cls");
	}
	if (man == 6)
	{
		system("cls");
		isWin = true;
		playMusicGame(soundIG, isWin);
		playWinMusicGame(soundIG, isStop);
		int res = MenuWinning(soundIG, soundEF, keyboardP1, keyboardP2, diem, TenNguoiChoi, data, nData, nguoiChoi, TrangThai, mode);
		if (res == 1)
		{
			playWinMusicGame(soundIG, true);
			man = 1;
			BodyRan1 = 1;
			BodyRan2 = 1;
			KichThuocVatCan = 0;
			huong1 = 4;
			huong2 = 4;
			diem = 0;
			KhoiTaoRan(ran1);
			KhoiTaoRan(ran2);
			Man1Mode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2,
				man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
			system("cls");
		}
		if (res == -1)
		{
			return -1;
		}
	}
	if (man == 0)
	{
		man = 1;
		choice = -1;
		BodyRan1 = 1;
		BodyRan2 = 1;
		KichThuocVatCan = 0;
		huong1 = 4;
		huong2 = 4;
		diem = 0;
		KhoiTaoRan(ran1);
		KhoiTaoRan(ran2);
	}
}

void PlayGameMode4(char* TenNguoiChoi1, char* TenNguoiChoi2, ToaDo ran1[], ToaDo ran2[], int& BodyRan1, int& BodyRan2, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& diem2, int& SPEED, int& huong1, int& huong2, int& man, ToaDo ChuongNgaiVat[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboardP1, MoveKeyBoard& keyboardP2, int choice, int mode)
{
	ManMode4(TenNguoiChoi1, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, diem2, SPEED, huong1, huong2,
		man, ChuongNgaiVat, KichThuocVatCan, data, nData, nguoiChoi1, nguoiChoi2, TrangThai, soundIG, soundEF, keyboardP1, keyboardP2, mode);
	system("cls");
	if (man == 0)
	{
		man = 1;
		choice = -1;
		KichThuocVatCan = 0;
		BodyRan1 = 1;
		BodyRan2 = 1;
		huong1 = 4;
		huong2 = 4;
		diem = 0;
		KhoiTaoRan(ran1);
		KhoiTaoRan(ran2);
	}
}

int main()
{
	FixConsoleWindow();
	FontSize(8, 16);
	resizeConsole(890, 840);
	SetConsoleTitle(L"HUNTING SNAKE - NHOM 01 - KTLT 22CLCA");
	printIntro();
	int soundBG = 1;
	int soundEF = 1;
	int soundIG = 1;
	MoveKeyBoard DefaultKeyP1 = { 'a', 'd', 'w', 's' };
	MoveKeyBoard DefaultKeyP2 = { 'j', 'l', 'i', 'k' };
	while (true)
	{
		playMusicMainMenu(soundBG);
		srand(unsigned(time(NULL)));
		int x = 4;
		int y = 2;
		int VungDiChuyen = 98;
		int VungBangDiem = 98;
		int ChieuRong = 44;

		char* TenNguoiChoi = NULL;
		char* TenNguoiChoi2 = NULL;

		ToaDo ran1[100];//Khai báo mảng tọa độ con rắn
		ToaDo ran2[100]; //Khai báo mảng tọa độ con rắn 2
		int BodyRan1 = 1;//Khai báo biến chứa số đốt con rắn
		int BodyRan2 = 1;

		KhoiTaoRan(ran1);
		KhoiTaoRan2(ran2);

		ToaDo* ChuongNgaiVat;
		ChuongNgaiVat = new ToaDo[200];
		int KichThuocVatCan = 0;

		int TrangThai = -1;
		int man = 1;
		int diem = 0;
		int diem2 = 0;
		int SPEED = 150;
		int huong1 = 4;
		int huong2 = 4;

		NguoiChoi nguoiChoi{};
		NguoiChoi nguoiChoi2{};
		nguoiChoi.TenNguoiChoi = NULL;
		nguoiChoi2.TenNguoiChoi = NULL;
		NguoiChoi* danhSachNguoiChoi = NULL;
		NguoiChoi** danhSachNguoiChoi2 = NULL;

		string data[100];
		int nData = 0;

		int choice = -1;
		int SelectMode = 0;
		int exit = 0;
		while (true)
		{
			system("cls");
			if (choice == -1)
			{
				resizeConsole(890, 840);
				system("cls");
				choice = MainMenu(soundBG, soundIG, soundEF);
			}
			if (choice == 1)
			{
				system("cls");
				SelectMode = MenuSelectModeGame(soundBG, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2);
				if (SelectMode == 1)
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode1(TenNguoiChoi, ran1, BodyRan1, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, exit, SelectMode);
				}
				if (SelectMode == 2)
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					choice = PlayGameMode2(TenNguoiChoi, ran1, BodyRan1, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, man, ChuongNgaiVat,
											KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
				if (SelectMode == 3)
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					choice = PlayGameMode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
				if (SelectMode == 4)
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode4(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, diem2, SPEED, huong1, huong2, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
				if (SelectMode == 5) 
				{
					system("cls");
					int choice = LeaderBoard(soundBG, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2);
					choice = -1;
					break;
				}
				if (SelectMode == 0) //Return to the Main Menu
				{
					choice = -1;
					break;
				}
			}
			else if (choice == 2)
			{
				system("cls");
				int res = LoadGame(TenNguoiChoi, TenNguoiChoi2, ran1, BodyRan1, ran2, BodyRan2, diem, diem2, SPEED, huong1, huong2, soundEF, man, ChuongNgaiVat,
					KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, DefaultKeyP1, DefaultKeyP2, danhSachNguoiChoi, danhSachNguoiChoi2);
				if (res == 1) //Mở game ở chế độ 1
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode1(TenNguoiChoi, ran1, BodyRan1, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, exit, SelectMode);
				}
				if (res == 2) //Mở game ở chế độ 2
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode2(TenNguoiChoi, ran1, BodyRan1, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
				if (res == 3) //Mở game ở chế độ 3
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode3(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, SPEED, huong1, huong2, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
				if (res == 4) //Mở game ở chế độ 3
				{
					system("cls");
					soundBG = 0;
					playMusicMainMenu(soundBG);
					PlayGameMode4(TenNguoiChoi, TenNguoiChoi2, ran1, ran2, BodyRan1, BodyRan2, x, y, VungDiChuyen, VungBangDiem, ChieuRong, diem, diem2, SPEED, huong1, huong2, man, ChuongNgaiVat,
						KichThuocVatCan, data, nData, nguoiChoi, nguoiChoi2, TrangThai, soundIG, soundEF, DefaultKeyP1, DefaultKeyP2, choice, SelectMode);
				}
			}
			else if (choice == 3)
			{
				MenuConfig(x, y, VungDiChuyen, ChieuRong, DefaultKeyP1, DefaultKeyP2, soundBG, soundEF);
				break;
			}
			else if (choice == 4)
			{
				system("cls");
				int getExitSign = About(soundIG, soundEF, DefaultKeyP1, DefaultKeyP2);
				if (getExitSign == 0)
				{
					choice = -1;
				}
			}
			else if (choice == 5)
			{
				exit = 1;
				break;
			}
		}
		delete[] ChuongNgaiVat;
		if (nguoiChoi.TenNguoiChoi != NULL)
		{
			delete[] nguoiChoi.TenNguoiChoi;
		}
		if (nguoiChoi2.TenNguoiChoi != NULL)
		{
			delete[] nguoiChoi2.TenNguoiChoi;
		}
		if (danhSachNguoiChoi != NULL)
		{
			delete[] danhSachNguoiChoi;
		}
		if (danhSachNguoiChoi2 != NULL) {
			for (int i = 0; i < nData; i++) {
				delete[] danhSachNguoiChoi2[i];
			}
			delete[] danhSachNguoiChoi2;
		}

		if (exit == 1)
		{
			system("cls");
			return 1;
		}
	}
	return 0;
}