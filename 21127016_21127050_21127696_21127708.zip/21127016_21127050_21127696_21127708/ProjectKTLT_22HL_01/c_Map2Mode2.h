#pragma once
#pragma comment(lib, "winmm.lib")
#include "c_savegame.h"

//T?o v?t c?n m�n 2
void TaoVatCanMan2Mode2(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo VatCan[], int& KichThuocVatCan);

//Tao qua
void FoodRound2(QUA& food, ToaDo VatCan[], int KichThuocVatCan, ToaDo ran[], int ran_dot, ToaDo CongWin[], int cong_win_so_o);

//An qua
void AnQua2(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& SPEED, int& diem, int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime);
//Ki?m tra thua do ??ng v?t c?n m�n 1 
bool KiemTraThuaVatCan2(ToaDo ran[], ToaDo VatCan[], int KichThuocVatCan);

//Ki?m tra thua m�n 1
bool KiemTraThuaMan2(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan);

void Man2Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode);