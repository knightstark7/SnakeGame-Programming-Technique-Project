#pragma once
#include <sstream> // stringstream
#include <iomanip> // put_time
#include <string>  // string
#include <iostream>
#include <fstream>
using namespace std;

struct BangDiem
{
	int TrangThai;
	char ten_nguoi_choi[40];
	int diem;
};


void DocFileBangDiem(ifstream& fileIn, BangDiem bangDiem[], int& so_luong);
void XuatFileBangDiem(ofstream& fileOut, BangDiem bangDiem[], int so_luong);
void XapSepLaiBangDiem(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem);
void GiaoDienBangDiem(int x, int y, int ChieuDai, int ChieuRong, BangDiem bangDiem[], int so_luong);
void LuuDanhSachNguoiChoiDiemCaoNhat(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem);
bool KiemTraTop5(BangDiem bangDiem[], int& so_luong, char* ten_nguoi_choi, int diem);