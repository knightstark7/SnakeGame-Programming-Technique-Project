﻿#include "c_Map2Mode2.h"
#include "c_mylib.h"
#include "c_savegame.h"
#include "c_scoreboard.h"
#include <iostream>
#include "c_menu.h"
#include "c_snake.h"
#include "c_music.h"
#include <Windows.h>

using namespace std;

#define LEN 1;
#define XUONG 2;
#define TRAI 3;
#define PHAI 4;
#define TUONG_TREN 3
#define TUONG_DUOI 35
#define TUONG_TRAI 3
#define TUONG_PHAI 110
/*
int x, int y truyền tọa độ (x, y) của góc trên cùng bên trái của vùng di chuyển của con rắn
int VungDiChuyen truyền độ dài của vùng di chuyển của con rắn
int ChieuRong truyền độ rộng của vùng di chuyển của con rắn
ToaDo VatCan[] truyền mảng chứa tọa độ của các ô vật cản
int& KichThuocVatCan truyền biến chứa tổng số lượng ô vật cản
*/
//Tạo vật cản màn 2

void TaoChuongNgaiVatMan2(int x, int y, int VungDiChuyen, int ChieuRong, ToaDo VatCan[], int& KichThuocVatCan)
{
	for (int i = x + 9; i <= x + VungDiChuyen - 10; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 12;
		KichThuocVatCan++;
	}

	for (int i = x + 20; i <= x + VungDiChuyen - 21; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 29;
		KichThuocVatCan++;
	}

	for (int i = y + 10; i <= y + ChieuRong - 17; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 51;
		KichThuocVatCan++;
	}

	for (int i = x + 9; i <= x + VungDiChuyen - 10; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 38;
		KichThuocVatCan++;
	}

	for (int i = x + 9; i <= x + VungDiChuyen - 70; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 22;
		KichThuocVatCan++;
	}

	for (int i = x + VungDiChuyen - 30; i <= x + VungDiChuyen - 10; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].x = i;
		VatCan[KichThuocVatCan].y = 22;
		KichThuocVatCan++;
	}

	for (int i = y + 20; i <= y + ChieuRong - 9; i++)
	{
		//Lưu tọa độ thanh vật cản nằm ngang phía trên
		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 13;
		KichThuocVatCan++;

		VatCan[KichThuocVatCan].y = i;
		VatCan[KichThuocVatCan].x = 92;
		KichThuocVatCan++;
	}
}

//Tao qua
void FoodRound2(QUA& food, ToaDo VatCan[], int KichThuocVatCan, ToaDo ran[], int ran_dot, ToaDo CongWin[], int cong_win_so_o)
{
	if (food.count < 5)
	{
		do
		{
			TaoQuaThuong(food);
		} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
		VeQuaThuong(food);
	}
	else if (food.count == 5)
	{
		do
		{
			TaoQuaDacBiet(food);
		} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
		VeQuaDacBiet(food);
	}
}

//An qua
void AnQua2(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& SPEED, int& diem,   int x, int y, int ChieuRong, ToaDo VatCan[], int KichThuocVatCan, ToaDo CongWin[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose, double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime)
{
	int diemtmp = 0;

	bool ThayDiem = false;

	if (isLose == true)
	{
		diemtmp = 0;
	}

	if (food.checkqua == true) {
		auto currentTime = std::chrono::high_resolution_clock::now();
		chrono::duration<double> duration = currentTime - startTime;
		elapsedTime = duration.count();
	}

	if (food.count < 5 && KiemTraAnQua(ran, food) == true)  // +1 point , +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(food);

		ran_dot++;
		diem += 100;
		SPEED -= 2;
		food.count++;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}

		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
	}
	else if (food.count == 5 && ran[0].x == food.SpecialFood.x && ran[0].y == food.SpecialFood.y && food.checkqua == true) // +10 points, +1 dot
	{
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", NULL, SND_ASYNC);
		}

		XoaQua(food);
		ran_dot++;
		diem += 500;
		SPEED -= 2;
		food.count = 0;

		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
	}
	else if (KiemTraAnQua(ran, A) == true) {
		if (soundBG == 1)
		{
			PlaySound(L"EatingFood.wav", 0, SND_ASYNC);
		}

		XoaQua(A);
		A.checkqua = false;
		A.NormalFood.x = A.NormalFood.y = 10000;
		ran_dot++;
		diem += 100;
		SPEED -= 2;
		ThayDiem = CapNhatDiem(diemtmp, diem);
		if (ThayDiem == true)
		{
			VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
			ThayDiem = false;
		}
		if (food.count != 5)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}

	}
	else if (food.count == 5 && elapsedTime >= 10 && food.checkqua == true) {
		XoaQua(food);
		elapsedTime = 0.0;
		food.count = 0;
		if (food.count < 5 && A.checkqua == false)
		{
			do
			{
				TaoQuaThuong(food);
			} while (!KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.NormalFood.x, food.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(food);
		}
		else if (food.count == 5)
		{
			do
			{
				TaoQuaDacBiet(food);
			} while (!KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(food.SpecialFood.x, food.SpecialFood.y, CongWin, cong_win_so_o));
			VeQuaDacBiet(food);
			startTime = chrono::high_resolution_clock::now();
			food.checkqua = true;

			do
			{
				TaoQuaThuong(A);
			} while ((A.NormalFood.x == food.SpecialFood.x && A.NormalFood.y == food.SpecialFood.y) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, VatCan, KichThuocVatCan) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, ran, ran_dot) || !KiemTraToaDoQuaKhaThi(A.NormalFood.x, A.NormalFood.y, CongWin, cong_win_so_o));
			VeQuaThuong(A);
			A.checkqua = true;
		}
	}
}


//Ki?m tra thua do ??ng v?t c?n màn 1
bool KiemTraThuaVatCan2(ToaDo ran[], ToaDo VatCan[], int KichThuocVatCan)
{
	for (int i = 0; i < KichThuocVatCan; i++)
	{
		if (ran[0].x == VatCan[i].x && ran[0].y == VatCan[i].y)
		{
			return true;
		}
	}
	return false;
}

//Ki?m tra thua màn 2
bool KiemTraThuaMan2(ToaDo ran[], int ran_dot, ToaDo VatCan[], int KichThuocVatCan)
{
	if (RanChamThan(ran, ran_dot))
	{
		return true;
	}
	if (RanChamTuong(ran))
	{
		return true;
	}
	if (KiemTraThuaVatCan2(ran, VatCan, KichThuocVatCan))
	{
		return true;
	}
	return false;
}

void Man2Mode2(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen, int VungBangDiem, int ChieuRong, int& diem,   int& SPEED, int& huong, int& man, ToaDo VatCan[], int KichThuocVatCan,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int mode)
{
	int temp = SPEED;
	TaoChuongNgaiVatMan2(x, y, VungDiChuyen, ChieuRong, VatCan, KichThuocVatCan);
	VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm v? màn 1
	SPEED = temp;

	QUA food;
	QUA A;
	food.count = 0;//Số lượng quả
	A.checkqua = false;

	bool checkPause = false;
	int ran_dot_Tam = ran_dot;
	int diemTam = diem;
	ToaDo ranTam[100];
	for (int i = 0; i < 100; i++)  ranTam[i] = ran[i];
	int huongTemp = huong;
	bool isLose = false;

	VeRan(ran, ran_dot);
	VeDiem(x, y, ChieuRong, diem, checkPause, isLose);

	ToaDo CongWin[7];
	int cong_win_so_o = 0; //s? ô t?o thành 1 c?ng win

	FoodRound2(food, VatCan, KichThuocVatCan, ran, ran_dot, CongWin, cong_win_so_o);
	bool win = KiemTraDieuKienThang(diem, 20 * man);
	chrono::time_point<std::chrono::high_resolution_clock> startTime;
	double elapsedTime = 0.0;
	int option;
	while (1)
	{
		int huongTam = huong;
		noCursorType();//Xóa con tr?(d?u nháy)
		BatSuKienMode2(huong, checkPause, keyboard);//Nh?n phím
		ToaDo dot_cuoi_cu = DiChuyen(ran, huong, ran_dot);//Di chuy?n r?n d?a trên nút ???c nh?n trên bàn phím
		HienThiRan(ran, dot_cuoi_cu, ran_dot);//Hi?n th? thân r?n m?i sau khi di chuy?n

		if (huong == -1)
		{
			int temp_1 = TrangThai;
			huong = huongTam;
			LuuGame(ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, KichThuocVatCan, VatCan, data, nData, nguoiChoi, TrangThai, mode);
			system("cls");
			man = 0;
			break;
		}

		Sleep(SPEED);//T?c ?? r?n=100
		if (!win)
			AnQua2(ran, food, A, ran_dot, SPEED, diem,  x, y, ChieuRong, VatCan, KichThuocVatCan, CongWin, cong_win_so_o, soundEF, checkPause, isLose, elapsedTime, startTime);//Ki?m tra ?n qu?
		if (KiemTraThuaMan2(ran, ran_dot, VatCan, KichThuocVatCan) || (win && RanChamCongWin(ran, CongWin, cong_win_so_o)))//Hàm ki?m tra thua
		{
			isLose = true;
			playMusicGame(soundIG, isLose);
			playLoseSound(soundIG, isLose);
			system("cls");
			XoaFileText(data, nData, TrangThai);
			int choice = MenuGameOver(soundIG, soundEF, keyboard, keyboardP2, diem, ten_nguoi_choi, data, nData, nguoiChoi, TrangThai, 2);
			if (choice == 1)
			{
				system("cls");
				isLose = false;
				playLoseSound(soundIG, isLose);
				playMusicGame(soundIG, isLose);
				SPEED = temp;
				diem = 0;
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				food.count = 0;
				ran_dot = ran_dot_Tam;
				for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
				huong = huongTemp;
				TaoQuaThuong(food);
				VeQuaThuong(food);
			}
			if (choice == 2)
			{
				man = 0;
				break;
			}
		}
		if (checkPause == true)
		{
			int pause = MenuPause(checkPause, soundIG, soundEF);
			if (pause == 1)
			{
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			if (pause == 2)
			{
				option = MenuOption(x, y, VungDiChuyen, ChieuRong, checkPause, keyboard, keyboardP2, soundIG, soundEF, ten_nguoi_choi, diem, ran_dot, ran, SPEED, huong, man, 0, VatCan,
					data, nData, nguoiChoi, TrangThai, mode);
				if (option == 1)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					if (food.count < 6)
					{
						VeQuaThuong(food);
					}
					else
					{
						gotoXY(food.SpecialFood.x, food.SpecialFood.y);
						TextColor(241);
						cout << char(5);
					}
				}
				if (option == 2)
				{
					system("cls");
					VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
					VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
					diem = diemTam;
					SPEED = temp;
					food.count = 0;
					ran_dot = ran_dot_Tam;
					for (int i = 0; i < 100; i++)  ran[i] = ranTam[i];
					huong = huongTemp;
					TaoQuaThuong(food);//T?o qu? ??u tiên
					VeQuaThuong(food);
				}
				if (option == 5)
				{
					system("cls");
					exit(0);
				}
			}
			if (pause == 3)
			{
				HuongDanChoi(x, y, VungDiChuyen, ChieuRong, keyboard, keyboardP2);
				system("cls");
				VeManChoi(x, y, VungDiChuyen, VungBangDiem, ChieuRong, VatCan, KichThuocVatCan, man);//Hàm vẽ màn 1
				VeDiem(x, y, ChieuRong, diem, checkPause, isLose);
				if (food.count < 6)
				{
					VeQuaThuong(food);
				}
				else
				{
					gotoXY(food.SpecialFood.x, food.SpecialFood.y);
					TextColor(241);
					cout << char(5);
				}
			}
			checkPause = false;
		}
		win = KiemTraDieuKienThang(diem, 800); //?n qu? xong thì ki?m tra l?i xem ?i?m ?ã ?? ?? qua màn
		if (win)
		{
			XoaQua(food);
			char huong_vao_cong[10] = "len";
			TaoCongWin(51, 6, CongWin, cong_win_so_o, huong_vao_cong);
			VeCongWin(CongWin, cong_win_so_o);
			if (RanQuaMan(ran, CongWin))
			{
				if (soundEF == 1)
				{
					PlaySound(L"EnterEffect.wav", NULL, SND_ASYNC);
				}
				man++;
				break;
			}
		}
		playMusicGame(soundIG, isLose);
	}
}