#pragma once
#include <fstream>
#include <iostream>
#include "c_snake.h"
using namespace std;

void LuuManChoi(string* data, int& nData, NguoiChoi nguoiChoi, int TrangThai);
NguoiChoi* XuatDanhSachNguoiChoi(ifstream& fileIn, string* data, int nData, int& nNguoiChoi);
NguoiChoi** XuatDanhSachNguoiChoi2(ifstream& fileIn, string* data, int nData, int& nNguoiChoi);

void GiaoDienLoadGame(int x, int y, NguoiChoi danhSachNguoiChoi[], int nNguoiChoi);

int logic_load_game(int x, int y, NguoiChoi* danhSachNguoiChoi, int nNguoiChoi, MoveKeyBoard keyboardP1, int soundEF);
int logic_load_game2(int x, int y, NguoiChoi** danhSachNguoiChoi, int nNguoiChoi, MoveKeyBoard keyboardP1, int soundEF);

char* ChuyenSoThanhChu(int a);
bool KiemTraTenFileHopLe(string* data, int nData, string str);

void LoadLaiGame(char*& ten_nguoi_choi, int& diem, int& ran_dot, ToaDo ran[], int& SPEED,
	int& huong, int& man, int& vat_can_so_o, ToaDo vat_can[], NguoiChoi* danhSachNguoiChoi, int nguoiChoiThuI);

void LoadLaiGame2(char*& ten_nguoi_choi1, char*& ten_nguoi_choi2, int& diem, int& diem2, int& ran_dot1, int& ran_dot2, ToaDo ran1[], ToaDo ran2[],
	int& SPEED, int& huong1, int& huong2, int& man, int& vat_can_so_o, ToaDo vat_can[], NguoiChoi** danhSachNguoiChoi, int nguoiChoiThuI);


void LuuNhieuMangVao1Mang(ToaDo vat_can_dong[], int& vat_can_dong_so_o, ToaDo vat_di_chuyen_1_1[],
	ToaDo vat_di_chuyen_1_2[], ToaDo vat_di_chuyen_2_1[], ToaDo vat_di_chuyen_2_2[], int vat_di_chuyen_so_o);

void Tach1MangVaoNhieuMang(ToaDo vat_can_dong[], int& vat_can_dong_so_o, ToaDo vat_di_chuyen_1_1[],
	ToaDo vat_di_chuyen_1_2[], ToaDo vat_di_chuyen_2_1[], ToaDo vat_di_chuyen_2_2[], int vat_di_chuyen_so_o);

void LuuGame(char* ten_nguoi_choi, int diem, int ran_dot, ToaDo* ran, int SPEED, int huong, int man, 
	int vat_can_dong_so_o, ToaDo* vat_can_dong, string* data, int nData, NguoiChoi& nguoiChoi, int TrangThai, int mode);

void LuuGame2(char* ten_nguoi_choi1, char* ten_nguoi_choi2, int diem1, int diem2, int ran_dot1, ToaDo* ran1, int ran_dot2, ToaDo* ran2, int SPEED, int huong1, int huong2, int man,
	int vat_can_dong_so_o, ToaDo* vat_can_dong, string* data, int nData, NguoiChoi& nguoiChoi1, NguoiChoi& nguoiChoi2, int TrangThai, int mode);

void XoaFileText(string* data, int& nData, int TrangThai);
