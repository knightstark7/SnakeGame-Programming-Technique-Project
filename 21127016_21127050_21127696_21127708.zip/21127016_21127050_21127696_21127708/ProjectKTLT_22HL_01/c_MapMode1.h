#pragma once
#pragma comment(lib, "winmm.lib")
#include <cstdlib>
#include "c_snake.h"

void AnQuaMode1(ToaDo ran[], QUA& food, QUA& A, int& ran_dot, int& temp1, bool& TrungDoc, int& SPEED, int& huong, int& diem, int x, int y, int ChieuRong, ToaDo vat_can[], int so_o_vat_can, ToaDo cong_win[], int cong_win_so_o, int soundBG, bool checkPause, bool isLose,
	double& elapsedTime, chrono::time_point<std::chrono::high_resolution_clock>& startTime, double& elapsedTime1,
	chrono::time_point<std::chrono::high_resolution_clock>& startTime1, double& elapsedTime2, chrono::time_point<std::chrono::high_resolution_clock>& startTime2, double& elapsedTime3, chrono::time_point<std::chrono::high_resolution_clock>& startTime3);

bool KiemTraThuaMan1(ToaDo ran[], int ran_dot, ToaDo vat_can[], int so_o_vat_can);

void ManMode1(char* ten_nguoi_choi, ToaDo ran[], int& ran_dot, int x, int y, int VungDiChuyen,
	int VungBangDiem, int ChieuRong, int& diem, int& SPEED, int& huong, int& man, ToaDo vat_can[], int vat_can_so_o,
	string* data, int& nData, NguoiChoi& nguoiChoi, int TrangThai, int& soundIG, int& soundEF, MoveKeyBoard& keyboard, MoveKeyBoard& keyboardP2, int& exitgame, int mode);